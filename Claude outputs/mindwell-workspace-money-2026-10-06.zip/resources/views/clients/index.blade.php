@extends('layouts.app')
@section('title', $viewer === 'admin' ? 'Clients' : 'My clients')
@section('content')
{{-- Added 2026-10-06 (roadmap 71) — shared by Therapist\ClientController (own clients
     only) and Admin\ClientController (everyone). See App\Services\ClientRecords. --}}
@php $S = \App\Support\Screeners::class; @endphp

<div class="dash-head">
    <h1>{{ $viewer === 'admin' ? 'Clients' : 'My clients' }}</h1>
    <span style="font-size:12.5px;color:var(--ink-500);">{{ $rows->count() }} {{ $rows->count() === 1 ? 'client' : 'clients' }}</span>
</div>

<form method="GET" action="{{ route($searchRoute) }}" class="card" style="display:flex;gap:10px;align-items:center;padding:12px 14px;margin-bottom:16px;">
    <input class="mw-field" type="search" name="q" value="{{ $search }}" placeholder="Search by name or client ID (e.g. 0007)" style="flex:1;" autocomplete="off">
    <button type="submit" class="btn primary sm">Search</button>
    @if ($search !== '')
        <a href="{{ route($searchRoute) }}" class="btn ghost sm">Clear</a>
    @endif
</form>

<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Client</th>
                <th>Age</th>
                <th>Main concern</th>
                <th>Last session</th>
                <th>Next session</th>
                <th>Scores</th>
                <th style="padding-right:16px;">Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($rows as $row)
                <tr style="cursor:pointer;" onclick="window.location='{{ route($showRoute, $row['profile']) }}'">
                    <td style="padding-left:16px;">
                        <a href="{{ route($showRoute, $row['profile']) }}" style="font-weight:700;color:var(--ink-900);text-decoration:none;">{{ $row['name'] }}</a>
                        <div style="font-size:11.5px;color:var(--ink-300);">{{ $row['label'] ?? '—' }}{{ $row['gender'] ? ' · '.$row['gender'] : '' }}</div>
                    </td>
                    <td>{{ $row['age'] ?? '—' }}</td>
                    <td style="max-width:220px;font-size:12.5px;color:var(--ink-700);">{{ $row['concern'] ? \Illuminate\Support\Str::limit($row['concern'], 60) : '—' }}</td>
                    <td style="white-space:nowrap;font-size:12.5px;">{{ $row['last_at']?->format('j M Y') ?? '—' }}</td>
                    <td style="white-space:nowrap;font-size:12.5px;">
                        @if ($row['next_at'])
                            {{ $row['next_at']->format('j M, g:i A') }}
                            @if ($row['next_status'] === 'pending_approval')
                                <div style="font-size:11px;color:var(--ink-300);">awaiting approval</div>
                            @endif
                        @else
                            —
                        @endif
                    </td>
                    <td style="font-size:12px;color:var(--ink-700);white-space:nowrap;">
                        @if ($row['phq9'] !== null)
                            PHQ-9 {{ $row['phq9'] }} · GAD-7 {{ $row['gad7'] }}
                            <div style="font-size:11px;color:var(--ink-300);">{{ $S::band('phq9', $row['phq9']) }} / {{ $S::band('gad7', $row['gad7']) }}</div>
                        @else
                            —
                        @endif
                    </td>
                    <td style="padding-right:16px;"><span class="pill {{ $row['status'][0] }}">{{ $row['status'][1] }}</span></td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" style="padding:20px 16px;color:var(--ink-500);">
                        @if ($search !== '')
                            No clients match "{{ $search }}".
                        @elseif ($viewer === 'admin')
                            No clients yet.
                        @else
                            No clients yet. Clients appear here once a session with you has been booked.
                        @endif
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

<p style="font-size:11px;color:var(--ink-300);margin-top:12px;">
    {{ $viewer === 'admin'
        ? 'Every client. Opening a client file is recorded in the audit log.'
        : 'Only clients you have a session with appear here. Journal entries and mood stay private unless the client shares them.' }}
</p>
@endsection
