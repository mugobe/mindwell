@extends('layouts.app')
@section('title', 'Dashboard')
@section('content')

@if (auth()->user()->role === 'admin')
    @php
        $crisisCount = \App\Models\IntakeAssessment::where('risk_level', 'crisis')->count();
        $highRiskCount = \App\Models\IntakeAssessment::whereIn('risk_level', ['crisis', 'high'])->count();
        $openFlagCount = \App\Models\CrisisFlag::where('status', 'open')->count();
        $waitingCount = \App\Models\TherapySession::where('status', 'routing')->count();
        $pendingReferralCount = \App\Models\TherapySession::where('closure_outcome', 'refer_to_specialist')->whereNull('referral_facility_id')->count();
        $pendingApprovalCount = \App\Models\TherapySession::where('status', 'pending_approval')->count();
    @endphp
    <div class="dash-head">
        <h1>Platform overview</h1>
        <span class="pill teal">Welcome back, {{ auth()->user()->name }}</span>
    </div>
    @php
        $icStyle = 'width:13px;height:13px;margin-right:5px;vertical-align:-2px;';
    @endphp
    <div class="stat-row">
        <div class="stat-tile">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><circle cx="9" cy="8" r="3"/><path d="M2.5 19c1.2-3 3.6-4.6 6.5-4.6s5.3 1.6 6.5 4.6"/><path d="M16 8.2a2.6 2.6 0 110-5 2.6 2.6 0 010 5z"/><path d="M15 14.8c2.4.4 4.2 1.8 5.2 4.2"/></svg>Total users</div>
            <div class="value">{{ \App\Models\User::count() }}</div>
        </div>
        <div class="stat-tile">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2"/><path d="M9 2h6"/></svg>Pending credentialing</div>
            <div class="value">{{ \App\Models\TherapistProfile::where('credentials_verified', false)->count() }}</div>
        </div>
        <div class="stat-tile">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><path d="M12 3l7 3v5c0 4.5-3 8-7 9-4-1-7-4.5-7-9V6l7-3z"/><path d="M9 12.5l2 2 4-4.5"/></svg>Verified therapists</div>
            <div class="value">{{ \App\Models\TherapistProfile::where('credentials_verified', true)->count() }}</div>
        </div>
        <div class="stat-tile" style="{{ $highRiskCount > 0 ? 'border-color:var(--danger);' : '' }}">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><path d="M12 3.5l9 15.5H3l9-15.5z"/><path d="M12 10v4"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/></svg>High-risk / crisis intakes</div>
            <div class="value" style="{{ $highRiskCount > 0 ? 'color:var(--danger);' : '' }}">{{ $highRiskCount }}</div>
        </div>
        <div class="stat-tile" style="{{ $openFlagCount > 0 ? 'border-color:var(--danger);' : '' }}">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><path d="M5 3v18"/><path d="M5 4h11l-2.5 3.5L16 11H5"/></svg>Open crisis flags</div>
            <div class="value" style="{{ $openFlagCount > 0 ? 'color:var(--danger);' : '' }}">{{ $openFlagCount }}</div>
        </div>
        <div class="stat-tile">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><path d="M4 7c3 0 3 10 6 10s3-10 6-10 3 10 6 10"/><circle cx="4" cy="7" r="1.2" fill="currentColor" stroke="none"/><circle cx="16" cy="17" r="1.2" fill="currentColor" stroke="none"/></svg>Waiting for routing</div>
            <div class="value">{{ $waitingCount }}</div>
        </div>
        <div class="stat-tile" style="{{ $pendingReferralCount > 0 ? 'border-color:var(--danger);' : '' }}">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><path d="M13 5l7 7-7 7"/><path d="M4 12h16"/></svg>Awaiting referral</div>
            <div class="value" style="{{ $pendingReferralCount > 0 ? 'color:var(--danger);' : '' }}">{{ $pendingReferralCount }}</div>
        </div>
        <div class="stat-tile" style="{{ $pendingApprovalCount > 0 ? 'border-color:var(--danger);' : '' }}">
            <div class="label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="{{ $icStyle }}"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>Bookings awaiting approval</div>
            <div class="value" style="{{ $pendingApprovalCount > 0 ? 'color:var(--danger);' : '' }}">{{ $pendingApprovalCount }}</div>
        </div>
    </div>
    <div class="card">
        <div class="section-title">Quick links</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <a href="{{ route('admin.users.index') }}" class="btn ghost sm">All users</a>
            <a href="{{ route('admin.therapists.index') }}" class="btn ghost sm">Therapist approvals</a>
            <a href="{{ route('admin.intake.index') }}" class="btn ghost sm">Intake reviews</a>
            <a href="{{ route('admin.crisis.index') }}" class="btn ghost sm">Crisis flags</a>
            <a href="{{ route('admin.session-routing.index') }}" class="btn ghost sm">Session routing</a>
            <a href="{{ route('admin.closed-sessions.index') }}" class="btn ghost sm">Session reports</a>
            <a href="{{ route('admin.referrals.index') }}" class="btn ghost sm">Referrals</a>
            <a href="{{ route('admin.facilities.index') }}" class="btn ghost sm">Facilities</a>
            <a href="{{ route('admin.client-subscriptions.index') }}" class="btn ghost sm">Client subscriptions</a>
            <a href="{{ route('admin.employers.index') }}" class="btn ghost sm">Employers</a>
            <a href="{{ route('admin.plans.index') }}" class="btn ghost sm">Subscription plans</a>
            <a href="{{ route('admin.audit.index') }}" class="btn ghost sm">Audit log</a>
        </div>
    </div>

@elseif (auth()->user()->role === 'therapist')
    @php $profile = auth()->user()->therapistProfile; @endphp

    @if (! $profile || ! $profile->credentials_verified)
        <div class="card" style="text-align:center;padding:48px 24px;">
            <div style="font-size:32px;margin-bottom:12px;">⏳</div>
            <h1 style="font-size:19px;font-weight:800;margin-bottom:8px;color:var(--ink-900);">
                Your application is under review
            </h1>
            <p style="font-size:13.5px;color:var(--ink-500);max-width:380px;margin:0 auto 14px;">
                Our credentialing team is verifying your license
                @if ($profile) ({{ $profile->license_number }}, {{ $profile->license_state }}) @endif
                — you'll get access to your therapist portal as soon as you're approved.
            </p>
            <span class="pill warn">Pending review</span>
        </div>
    @else
        {{-- Therapist dashboard (rebuilt 2026-10-06, roadmap 72 — Dr. Ntabade's THERAPIST
             DRAFT: today's overview, today's sessions with Join, quick actions).
             Numbers come from App\Services\TherapistOverview. --}}
        @php
            $mwOverview = new \App\Services\TherapistOverview($profile->id, auth()->user());
            $mwCounts = $mwOverview->counts();
            $mwToday = $mwOverview->today();
            $mwSoon = $mwOverview->upcoming(7)->reject(fn ($s) => $s->scheduled_at->isToday())->take(5);
            $mwHour = (int) now()->format('G');
            $mwGreeting = $mwHour < 12 ? 'Good morning' : ($mwHour < 17 ? 'Good afternoon' : 'Good evening');
            $mwFirstName = trim(explode(' ', auth()->user()->name)[0] ?? '');
        @endphp
        <div class="dash-head">
            <h1>{{ $mwGreeting }}, {{ $mwFirstName }}</h1>
            <span style="font-size:12.5px;color:var(--ink-500);">{{ now()->format('l, j F') }}</span>
        </div>

        <div class="section-title">Today's overview</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:20px;">
            @foreach ([
                ["Today's appointments", $mwCounts['today'], route('therapist.sessions.index')],
                ['New clients', $mwCounts['new_clients'], route('therapist.clients.index')],
                ['Unread messages', $mwCounts['unread_messages'], route('messages.index')],
                ['Check-ins due', $mwCounts['check_ins_due'], route('therapist.clients.index')],
                ['Follow-ups', $mwCounts['follow_ups'], route('therapist.sessions.index')],
                ['To close out', $mwCounts['to_close'], route('therapist.sessions.index')],
            ] as [$mwLabel, $mwValue, $mwLink])
                <a href="{{ $mwLink }}" class="card" style="display:block;text-decoration:none;padding:14px 16px;">
                    <div style="font-size:24px;font-weight:800;color:{{ $mwLabel === 'To close out' && $mwValue > 0 ? 'var(--coral-500, #e8825e)' : 'var(--ink-900)' }};">{{ $mwValue }}</div>
                    <div style="font-size:12px;color:var(--ink-500);font-weight:600;">{{ $mwLabel }}</div>
                </a>
            @endforeach
        </div>

        <div class="section-title">Today's sessions</div>
        <div class="card" style="padding:0;margin-bottom:20px;">
            @forelse ($mwToday as $mwS)
                @php
                    $mwClient = $mwS->clientProfile?->user;
                    $mwKind = $mwS->routing_method === 'therapist_scheduled' ? 'Follow-up session' : ($mwOverview->isFirstWith($mwS) ? 'First session' : 'Session');
                @endphp
                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;border-top:{{ $loop->first ? 'none' : '1px solid rgba(0,0,0,.06)' }};flex-wrap:wrap;">
                    <div style="display:flex;align-items:center;gap:14px;">
                        <div style="font-size:15px;font-weight:800;color:var(--ink-900);width:72px;">{{ $mwS->scheduled_at->format('g:i A') }}</div>
                        <div>
                            <div style="font-weight:700;color:var(--ink-900);">{{ $mwClient?->name ?? 'Client' }} <span style="font-weight:500;color:var(--ink-300);font-size:12px;">{{ $mwClient?->clientLabel() }}</span></div>
                            <div style="font-size:12px;color:var(--ink-500);">{{ $mwKind }} · {{ $mwS->duration_minutes ?: config('mindwell.session_duration_minutes') }} min · Video</div>
                        </div>
                    </div>
                    <div style="display:flex;gap:8px;">
                        <a href="{{ route('therapist.clients.show', $mwS->client_profile_id) }}" class="btn ghost sm">View client</a>
                        @if ($mwS->status === 'scheduled')
                            <a href="{{ route('sessions.room', $mwS) }}" class="btn coral sm">Join session</a>
                        @else
                            <span class="pill success">Closed</span>
                        @endif
                    </div>
                </div>
            @empty
                <div style="padding:18px 16px;font-size:13px;color:var(--ink-500);">No sessions today.</div>
            @endforelse
        </div>

        @if ($mwSoon->isNotEmpty())
            <div class="section-title">Coming up this week</div>
            <div class="card" style="padding:0;margin-bottom:20px;">
                @foreach ($mwSoon as $mwS)
                    <div style="display:flex;justify-content:space-between;gap:12px;padding:11px 16px;border-top:{{ $loop->first ? 'none' : '1px solid rgba(0,0,0,.06)' }};font-size:13px;">
                        <span><strong>{{ $mwS->scheduled_at->format('D j M, g:i A') }}</strong> — {{ $mwS->clientProfile?->user?->name ?? 'Client' }}</span>
                        <a href="{{ route('therapist.clients.show', $mwS->client_profile_id) }}" style="color:var(--teal-600, #2f6f66);font-weight:700;">View client</a>
                    </div>
                @endforeach
            </div>
        @endif

        <div class="section-title">Quick actions</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <a href="{{ route('therapist.clients.index') }}" class="btn ghost sm">My clients</a>
            <a href="{{ route('therapist.sessions.index') }}" class="btn ghost sm">Appointments</a>
            <a href="{{ route('messages.index') }}" class="btn ghost sm">Messages</a>
            <a href="{{ route('therapist.reports.index') }}" class="btn ghost sm">Session notes</a>
            <a href="{{ route('therapist.stats') }}" class="btn ghost sm">My stats</a>
            <a href="{{ route('therapist.availability.index') }}" class="btn ghost sm">Availability</a>
            <a href="{{ route('therapist.profile.edit') }}" class="btn ghost sm">My profile</a>
        </div>
    @endif
@else
    @php
        $clientProfile = auth()->user()->clientProfile;
        $latestIntake = $clientProfile?->intakeAssessments()->latest()->first();
        $latestSession = $clientProfile
            ? \App\Models\TherapySession::where('client_profile_id', $clientProfile->id)->latest()->first()
            : null;
        $lastCompletedSession = $clientProfile
            ? \App\Models\TherapySession::where('client_profile_id', $clientProfile->id)->where('status', 'completed')->with('therapistProfile.user')->latest()->first()
            : null;
        $inProgress = $latestSession && in_array($latestSession->status, ['pending_payment', 'routing', 'pending_approval', 'scheduled']);

        // Phase 0 (2026-10-05), from Dr. Ntabade's CLIENT DRAFT: next session card with
        // a Join button, and "How are you feeling today?" right on the dashboard.
        $mwNext = $clientProfile
            ? \App\Models\TherapySession::where('client_profile_id', $clientProfile->id)
                ->where('status', 'scheduled')
                ->whereNotNull('scheduled_at')
                ->where('scheduled_at', '>=', now()->subMinutes((int) config('mindwell.session_duration_minutes', 70) + (int) config('mindwell.video_join_late_minutes', 30)))
                ->with('therapistProfile.user')
                ->orderBy('scheduled_at')
                ->first()
            : null;
        if ($mwNext && $latestSession && $latestSession->status === 'scheduled') {
            $inProgress = false; // the next-session card below covers it
        }
        $mwMoodToday = $clientProfile
            ? \App\Models\JournalEntry::where('client_profile_id', $clientProfile->id)
                ->where('kind', 'daily')->whereNotNull('mood')
                ->where('created_at', '>=', now()->startOfDay())
                ->latest()->value('mood')
            : null;
    @endphp

    {{-- Warmer, more colorful client dashboard (2026-09-27 design pass, flagship page —
         reference: Google Meet's home screen). Illustrations via partials.mw-illustration,
         pastel tones via the --mw-* variables defined in layouts/app.blade.php. Admin and
         therapist dashboards above are untouched. --}}
    <div style="background:#fff;border:1px solid var(--mw-teal-tint);border-radius:16px;padding:14px 18px;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
        <span style="flex-shrink:0;width:34px;height:34px;border-radius:50%;background:var(--mw-teal-tint);display:flex;align-items:center;justify-content:center;">
            <svg viewBox="0 0 24 24" fill="none" stroke="var(--teal-600,#2f6f66)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:17px;height:17px;"><path d="M12 3l7 3v5c0 4.5-3 8-7 9-4-1-7-4.5-7-9V6l7-3z"/><path d="M9 12.5l2 2 4-4.5"/></svg>
        </span>
        <div>
            <div style="font-size:13px;font-weight:700;color:var(--ink-900);">Your privacy comes first</div>
            <div style="font-size:12px;color:var(--ink-500);">Sessions and reports are confidential — only you and your therapist ever see them.</div>
        </div>
    </div>

    @if ($mwNext)
        @php
            $mwJoinFrom = $mwNext->scheduled_at->copy()->subMinutes((int) config('mindwell.video_join_early_minutes', 10));
            $mwCanJoin = now()->gte($mwJoinFrom);
        @endphp
        <div class="card" style="margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;border-left:4px solid var(--teal-600, #2f6f66);">
            <div>
                <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">Your next session</div>
                <div style="font-size:17px;font-weight:800;color:var(--ink-900);margin-top:4px;">{{ $mwNext->scheduled_at->format('l, j F') }} · {{ $mwNext->scheduled_at->format('g:i A') }}</div>
                <div style="font-size:13px;color:var(--ink-500);margin-top:2px;">
                    With {{ $mwNext->therapistProfile?->user?->name ?? 'your therapist' }} · Video session · {{ $mwNext->duration_minutes ?: config('mindwell.session_duration_minutes') }} minutes
                </div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                <a href="{{ route('sessions.room', $mwNext) }}" class="btn {{ $mwCanJoin ? 'coral' : 'ghost' }}" style="border-radius:999px;padding:10px 22px;">
                    {{ $mwCanJoin ? 'Join session' : 'Session room' }}
                </a>
                @unless ($mwCanJoin)
                    <span style="font-size:11.5px;color:var(--ink-500);">You can join from {{ $mwJoinFrom->format('g:i A') }}{{ $mwJoinFrom->isToday() ? '' : ' on '.$mwJoinFrom->format('D j M') }}</span>
                @endunless
            </div>
        </div>
    @endif

    @if ($latestIntake)
        <div class="card" style="margin-bottom:20px;padding:16px 18px;">
            @if ($mwMoodToday)
                <div style="font-size:13px;color:var(--ink-700);">
                    Today you said you're feeling <strong>{{ strtolower(\App\Models\JournalEntry::MOODS[$mwMoodToday] ?? '') }}</strong>.
                    <a href="{{ route('journal.index') }}" style="color:var(--teal-600, #2f6f66);font-weight:700;">Add a note in your journal →</a>
                </div>
            @else
                <form method="POST" action="{{ route('journal.store') }}" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    @csrf
                    <input type="hidden" name="return" value="dashboard">
                    <span style="font-size:14px;font-weight:800;color:var(--ink-900);margin-right:4px;">How are you feeling today?</span>
                    @foreach (\App\Models\JournalEntry::MOODS as $mwMoodValue => $mwMoodLabel)
                        <button type="submit" name="mood" value="{{ $mwMoodValue }}" class="btn ghost sm" style="border-radius:999px;">{{ $mwMoodLabel }}</button>
                    @endforeach
                </form>
            @endif
        </div>
    @endif

    {{-- Progress check-in invitation (added 2026-10-03) — see App\Models\CheckIn. --}}
    @php $mwCheckIn = \App\Models\CheckIn::statusFor($clientProfile); @endphp
    @if ($mwCheckIn['due'])
        <div style="background:var(--mw-coral-tint, #FCE1D3);border-radius:16px;padding:16px 18px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;">
            <div>
                <div style="font-size:14px;font-weight:800;color:var(--ink-900);">Time for your check-in</div>
                <div style="font-size:12.5px;color:var(--ink-700);">About 3 minutes. It helps you and your therapist see how things are changing.</div>
            </div>
            <a href="{{ route('progress.check-in') }}" class="btn coral" style="border-radius:999px;padding:9px 22px;">Start check-in</a>
        </div>
    @endif

    {{-- "How was your session?" (added 2026-10-04) — see App\Models\SessionRating. --}}
    @php $mwToRate = \App\Models\SessionRating::pendingFor($clientProfile?->id); @endphp
    @if ($mwToRate)
        <div style="background:#fff;border:1px solid var(--mw-gold, #F6E1A8);border-radius:16px;padding:14px 18px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;">
            <div>
                <div style="font-size:14px;font-weight:800;color:var(--ink-900);"><span style="color:#e8a33d;">★</span> How was your session with {{ $mwToRate->therapistProfile?->user?->name ?? 'your therapist' }}?</div>
                <div style="font-size:12.5px;color:var(--ink-500);">{{ $mwToRate->scheduled_at->format('l, M j') }} · takes a few seconds</div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
                <a href="{{ route('sessions.rate', $mwToRate) }}" class="btn primary sm" style="border-radius:999px;padding-left:18px;padding-right:18px;">Rate it</a>
                <form method="POST" action="{{ route('sessions.rate.store', $mwToRate) }}">
                    @csrf
                    <input type="hidden" name="skip" value="1">
                    <button type="submit" class="btn ghost sm" style="border-radius:999px;">Not now</button>
                </form>
            </div>
        </div>
    @endif

    @if (! $latestIntake)
        <div class="card" style="text-align:center;padding:44px 24px;">
            @include('partials.mw-illustration', ['variant' => 'sprout'])
            <h1 style="font-size:19px;font-weight:800;margin:14px 0 8px;color:var(--ink-900);">
                Welcome, {{ auth()->user()->name }}
            </h1>
            <p style="font-size:13.5px;color:var(--ink-500);max-width:360px;margin:0 auto 18px;">
                Let's start with a quick assessment so we can match you with the right therapist.
            </p>
            <a href="{{ route('intake.show') }}" class="btn coral" style="display:inline-block;width:auto;border-radius:999px;padding:11px 26px;">Start intake assessment</a>
            <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:20px;">
                <span style="font-size:11px;font-weight:600;color:var(--teal-600,#2f6f66);background:var(--mw-teal-tint);padding:5px 12px;border-radius:999px;">Private &amp; confidential</span>
                <span style="font-size:11px;font-weight:600;color:#8a5a2a;background:var(--mw-gold);padding:5px 12px;border-radius:999px;">Licensed therapists</span>
                <span style="font-size:11px;font-weight:600;color:#a14b3a;background:var(--mw-coral-tint);padding:5px 12px;border-radius:999px;">Book anytime</span>
            </div>
        </div>
    @elseif ($inProgress)
        <div class="card" style="text-align:center;padding:44px 24px;">
            @include('partials.mw-illustration', ['variant' => 'hourglass'])
            <h1 style="font-size:19px;font-weight:800;margin:14px 0 8px;color:var(--ink-900);">
                You have a session in progress
            </h1>
            <p style="font-size:13.5px;color:var(--ink-500);max-width:360px;margin:0 auto 18px;">
                @switch($latestSession->status)
                    @case('pending_payment') Pick up where you left off to confirm it. @break
                    @case('routing') You're in the lobby, waiting to be connected. @break
                    @case('pending_approval') Just waiting on our team to confirm it. @break
                    @case('scheduled') You're all matched — see the details. @break
                @endswitch
            </p>
            <a href="{{ route(match($latestSession->status) {
                'pending_payment' => 'sessions.checkout',
                'routing' => 'sessions.lobby',
                'pending_approval' => 'sessions.pending-approval',
                'scheduled' => 'sessions.connected',
            }, $latestSession) }}" class="btn coral" style="display:inline-block;width:auto;border-radius:999px;padding:11px 26px;">Continue</a>
        </div>
    @elseif ($lastCompletedSession)
        <div class="card" style="text-align:center;padding:40px 24px;">
            @include('partials.mw-illustration', ['variant' => 'again'])
            <h1 style="font-size:19px;font-weight:800;margin:14px 0 8px;color:var(--ink-900);">
                Welcome back, {{ auth()->user()->name }}
            </h1>
            <p style="font-size:13.5px;color:var(--ink-500);max-width:380px;margin:0 auto 18px;">
                Ready for another session with {{ $lastCompletedSession->therapistProfile?->user?->name ?? 'your therapist' }}?
            </p>
            <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                @if ($lastCompletedSession->therapistProfile)
                    <a href="{{ route('therapists.book', $lastCompletedSession->therapistProfile) }}" class="btn coral" style="border-radius:999px;padding:10px 22px;">Book with them again</a>
                @endif
                <a href="{{ route('therapists.browse') }}" class="btn ghost" style="border-radius:999px;padding:10px 22px;">Browse other therapists</a>
            </div>
            <p style="margin-top:16px;">
                <a href="{{ route('sessions.history') }}" style="font-size:12.5px;color:var(--ink-500);">View your session history</a>
            </p>
        </div>
    @else
        <div class="card" style="text-align:center;padding:44px 24px;">
            @include('partials.mw-illustration', ['variant' => 'compass'])
            <h1 style="font-size:19px;font-weight:800;margin:14px 0 8px;color:var(--ink-900);">
                Intake complete
            </h1>
            <p style="font-size:13.5px;color:var(--ink-500);max-width:360px;margin:0 auto 18px;">
                Messaging will show up here as it gets built. You can already see your session history below.
            </p>
            <a href="{{ route('therapists.browse') }}" class="btn ghost" style="display:inline-block;width:auto;border-radius:999px;padding:11px 26px;">Browse therapists</a>
            <p style="margin-top:16px;">
                <a href="{{ route('sessions.history') }}" style="font-size:12.5px;color:var(--ink-500);">View your session history</a>
            </p>
        </div>
    @endif
@endif

@endsection
