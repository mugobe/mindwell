@extends('layouts.app')
@section('title', 'My stats')
@section('content')
{{-- Added 2026-10-06 (roadmap 79) — see App\Services\TherapistOverview for definitions. --}}
@php
    $tiles = [
        ['Active clients', $counts['active_clients'], 'Upcoming session or seen in the last 60 days', route('therapist.clients.index')],
        ['Sessions completed', $counts['completed_total'], $counts['completed_30'].' in the last 30 days', route('therapist.reports.index')],
        ['Upcoming sessions', $counts['upcoming'], $counts['pending_approval'].' more awaiting admin approval', route('therapist.sessions.index')],
        ['Missed', $counts['missed'], 'Client never joined the video room', route('therapist.sessions.index')],
        ['To close out', $counts['to_close'], 'Finished, report not written yet', route('therapist.sessions.index')],
        ['Referrals', $counts['referrals'], 'Sessions closed with "Refer out"', null],
        ['Follow-ups', $counts['follow_ups'], 'Upcoming sessions you scheduled', route('therapist.sessions.index')],
        ['Check-ins due', $counts['check_ins_due'], 'Active clients due a 2-weekly check-in', route('therapist.clients.index')],
    ];
    $max = max(1, collect($monthly)->max('count'));
@endphp

<div class="dash-head">
    <h1>My stats</h1>
    @if ($counts['rating'])
        <span style="font-size:13px;color:var(--ink-700);"><span style="color:#e8a33d;">★</span> {{ number_format($counts['rating']['average'], 1) }} / 5 from {{ $counts['rating']['count'] }} ratings</span>
    @endif
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:18px;">
    @foreach ($tiles as [$label, $value, $hint, $link])
        @if ($link)<a href="{{ $link }}" class="card" style="text-decoration:none;display:block;">@else<div class="card">@endif
            <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">{{ $label }}</div>
            <div style="font-size:26px;font-weight:800;color:{{ $label === 'Missed' && $value > 0 ? 'var(--danger, #c0392b)' : 'var(--ink-900)' }};margin-top:4px;">{{ $value }}</div>
            <div style="font-size:12px;color:var(--ink-500);">{{ $hint }}</div>
        @if ($link)</a>@else</div>@endif
    @endforeach
</div>

<div class="card">
    <div class="section-title">Sessions completed per month</div>
    <div style="display:flex;align-items:flex-end;gap:14px;height:150px;border-bottom:1px solid rgba(0,0,0,.12);padding:0 4px;" role="img" aria-label="Sessions completed per month for the last six months">
        @foreach ($monthly as $m)
            <div style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;" title="{{ $m['label'] }}: {{ $m['count'] }} sessions">
                @if ($m['count'] > 0)
                    <span style="font-size:11px;font-weight:700;color:var(--ink-700);margin-bottom:4px;">{{ $m['count'] }}</span>
                    <span style="width:100%;max-width:44px;height:{{ round($m['count'] / $max * 120, 1) }}px;background:#139080;border-radius:4px 4px 0 0;"></span>
                @endif
            </div>
        @endforeach
    </div>
    <div style="display:flex;gap:14px;padding:6px 4px 0;">
        @foreach ($monthly as $m)<span style="flex:1;text-align:center;font-size:11.5px;color:var(--ink-500);">{{ $m['label'] }}</span>@endforeach
    </div>
</div>
@endsection
