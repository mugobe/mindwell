@extends('layouts.app')
@section('title', 'Users')
@section('content')

<div class="dash-head">
    <h1>All users</h1>
    <a href="{{ route('admin.therapists.index') }}" class="btn ghost sm">Therapist approvals</a>
</div>

@if (session('temp_password'))
    @php $mwTemp = session('temp_password'); @endphp
    {{-- Shown ONCE (flash). Added 2026-10-04 — see UserController::temporaryPassword(). --}}
    <div class="card" style="margin-bottom:18px;border:2px solid var(--mw-gold, #F6E1A8);">
        <div style="font-size:14px;font-weight:800;color:var(--ink-900);">Temporary password for {{ $mwTemp['name'] }}</div>
        <div style="font-size:12.5px;color:var(--ink-500);margin:4px 0 12px;">
            Give this to them in person or by phone — not by email or SMS. It's shown only this once. They'll choose their own
            password when they log in with it ({{ $mwTemp['email'] }}).
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
            <code id="mw-temp-pw" style="font-size:22px;font-weight:800;letter-spacing:.08em;background:#f5f2ea;padding:8px 14px;border-radius:10px;">{{ $mwTemp['password'] }}</code>
            <button type="button" class="btn ghost sm" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('mw-temp-pw').textContent).then(() => { this.textContent = 'Copied'; })">Copy</button>
        </div>
    </div>
@endif

<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Joined</th>
                <th style="padding-right:16px;"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($users as $user)
            <tr>
                <td style="padding-left:16px;display:flex;align-items:center;gap:10px;">
                    <div class="avatar" style="width:30px;height:30px;font-size:11px;">{{ collect(explode(' ', $user->name))->map(fn($p) => $p[0] ?? '')->join('') }}</div>
                    {{ $user->name }}
                </td>
                <td>{{ $user->email }}</td>
                <td>
                    <span class="pill {{ $user->role === 'admin' ? 'teal' : ($user->role === 'therapist' ? 'warn' : 'success') }}">
                        {{ ucfirst($user->role) }}
                    </span>
                </td>
                <td>
                    <span class="pill {{ $user->status === 'active' ? 'success' : ($user->status === 'suspended' ? 'danger' : 'warn') }}">
                        {{ ucfirst($user->status) }}
                    </span>
                </td>
                <td>{{ $user->created_at->format('M j, Y') }}</td>
                <td style="padding-right:16px;text-align:right;white-space:nowrap;">
                    @if ($user->role === 'client' && $user->clientProfile)
                        <a href="{{ route('admin.clients.show', $user->clientProfile) }}" class="btn ghost sm" style="margin-right:6px;">Client file</a>
                    @endif
                    @if ($user->id !== auth()->id())
                        {{-- Password help (added 2026-10-04). --}}
                        <form method="POST" action="{{ route('admin.users.send-reset', $user) }}" style="display:inline;">
                            @csrf
                            <button type="submit" class="btn ghost sm" title="Email them a link to choose a new password">Send reset link</button>
                        </form>
                        @php $mwTempConfirm = 'Set a temporary password for '.$user->name.'? Their current password will stop working, and you will need to give them the new one yourself.'; @endphp
                        <form method="POST" action="{{ route('admin.users.temporary-password', $user) }}" style="display:inline;" onsubmit="return confirm({{ json_encode($mwTempConfirm) }});">
                            @csrf
                            <button type="submit" class="btn ghost sm" title="For someone who can't get to their email">Temp password</button>
                        </form>
                        @if ($user->status === 'suspended')
                            <form method="POST" action="{{ route('admin.users.activate', $user) }}" style="display:inline;">
                                @csrf
                                <button type="submit" class="btn ghost sm">Reactivate</button>
                            </form>
                        @else
                            <form method="POST" action="{{ route('admin.users.suspend', $user) }}" style="display:inline;">
                                @csrf
                                <button type="submit" class="btn ghost sm" style="color:var(--danger);border-color:var(--danger);">Suspend</button>
                            </form>
                        @endif
                    @else
                        <span style="font-size:11px;color:var(--ink-300);">You</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="padding:16px;color:var(--ink-500);">No users yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div style="margin-top:16px;">{{ $users->links() }}</div>
@endsection
