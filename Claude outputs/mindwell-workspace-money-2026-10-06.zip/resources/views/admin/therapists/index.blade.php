@extends('layouts.app')
@section('title', 'Therapist Approvals')
@section('content')

<div class="dash-head">
    <h1>Therapist credentialing</h1>
    <div style="display:flex;gap:10px;align-items:center;">
        <span class="pill warn">{{ $pending->count() }} pending review</span>
        <a href="{{ route('admin.therapists.create') }}" class="btn primary sm">+ Add therapist</a>
    </div>
</div>

<div class="section-title">Pending approval ({{ $pending->count() }})</div>
<div class="card" style="padding:0;margin-bottom:24px;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Name</th>
                <th>License</th>
                <th>State</th>
                <th style="padding-right:16px;"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($pending as $therapist)
            <tr>
                <td style="padding-left:16px;">{{ $therapist->user->name }}</td>
                <td>{{ $therapist->license_number }}</td>
                <td>{{ $therapist->license_state }}</td>
                <td style="padding-right:16px;text-align:right;">
                    <div style="display:inline-flex;gap:8px;">
                        <form method="POST" action="{{ route('admin.therapists.approve', $therapist) }}">
                            @csrf
                            <button type="submit" class="btn primary sm">Approve</button>
                        </form>
                        <form method="POST" action="{{ route('admin.therapists.reject', $therapist) }}">
                            @csrf
                            <button type="submit" class="btn ghost sm" style="color:var(--danger);border-color:var(--danger);">Reject</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" style="padding:16px;color:var(--ink-500);">No pending applications.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

@if ($licenseChanges->isNotEmpty())
    {{-- Added 2026-10-06: licence changes therapists asked for from their profile. --}}
    <div class="section-title">Licence changes waiting for approval ({{ $licenseChanges->count() }})</div>
    <div class="card" style="padding:0;margin-bottom:24px;">
        <table class="mw-table">
            <thead><tr><th style="padding-left:16px;">Therapist</th><th>Current</th><th>Requested</th><th>Asked on</th><th style="padding-right:16px;"></th></tr></thead>
            <tbody>
                @foreach ($licenseChanges as $therapist)
                    <tr>
                        <td style="padding-left:16px;">{{ $therapist->user->name }}</td>
                        <td>{{ $therapist->license_number }} · {{ $therapist->license_state }}</td>
                        <td style="font-weight:700;">{{ $therapist->pending_license_number }} · {{ $therapist->pending_license_state }}</td>
                        <td style="font-size:12.5px;">{{ \Illuminate\Support\Carbon::parse($therapist->license_change_requested_at)->format('j M Y') }}</td>
                        <td style="padding-right:16px;text-align:right;white-space:nowrap;">
                            <form method="POST" action="{{ route('admin.therapists.license.approve', $therapist) }}" style="display:inline;">@csrf<button type="submit" class="btn primary sm">Approve</button></form>
                            <form method="POST" action="{{ route('admin.therapists.license.reject', $therapist) }}" style="display:inline;">@csrf<button type="submit" class="btn ghost sm">Reject</button></form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endif

<div class="section-title">Verified therapists ({{ $verified->count() }})</div>
<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Name</th>
                <th>License</th>
                <th>State</th>
                <th style="padding-right:16px;">Rate</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($verified as $therapist)
            <tr>
                <td style="padding-left:16px;">{{ $therapist->user->name }}</td>
                <td>{{ $therapist->license_number }}</td>
                <td>{{ $therapist->license_state }}</td>
                <td style="padding-right:16px;">{{ $therapist->hourly_rate ? config('flutterwave.currency', 'UGX').' '.number_format((float) $therapist->hourly_rate, 0) : '—' }}</td>
            </tr>
            @empty
            <tr><td colspan="4" style="padding:16px;color:var(--ink-500);">None yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
