@extends('layouts.app')
@section('title', 'Client Subscriptions')
@section('content')

<div class="dash-head">
    <h1>Client subscriptions</h1>
</div>

<div class="card" style="margin-bottom:24px;">
    <div class="section-title">Grant a subscription</div>
    <p style="font-size:12px;color:var(--ink-500);margin-bottom:14px;">
        Clients can subscribe and renew themselves from My plan. Use this for a plan paid some other way (e.g. cash).
    </p>
    <form method="POST" action="{{ route('admin.client-subscriptions.store') }}" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;">
        @csrf
        <div>
            <label class="mw-label" for="user_id">Client</label>
            <select class="mw-field" id="user_id" name="user_id" required style="width:220px;">
                <option value="">Choose…</option>
                @foreach ($clients as $client)
                    <option value="{{ $client->id }}">{{ $client->name }} ({{ $client->email }})</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="mw-label" for="subscription_plan_id">Plan</label>
            <select class="mw-field" id="subscription_plan_id" name="subscription_plan_id" required style="width:200px;">
                <option value="">Choose…</option>
                @foreach ($plans as $plan)
                    <option value="{{ $plan->id }}">{{ $plan->name }} ({{ $plan->sessions_included }} sessions / {{ $plan->billing_interval }})</option>
                @endforeach
            </select>
        </div>
        {{-- 2026-10-06 (roadmap 23): free, or paid in cash (creates a payment + receipt). --}}
        <div>
            <label class="mw-label" for="payment_type">Payment</label>
            <select class="mw-field" id="payment_type" name="payment_type" style="width:170px;" onchange="document.getElementById('mw-cash-wrap').style.display = this.value === 'cash' ? 'block' : 'none'">
                <option value="complimentary" {{ old('payment_type') !== 'cash' ? 'selected' : '' }}>Complimentary</option>
                <option value="cash" {{ old('payment_type') === 'cash' ? 'selected' : '' }}>Paid in cash</option>
            </select>
        </div>
        <div id="mw-cash-wrap" style="display:{{ old('payment_type') === 'cash' ? 'block' : 'none' }};">
            <label class="mw-label" for="cash_amount">Amount ({{ config('flutterwave.currency', 'UGX') }})</label>
            <input class="mw-field" type="number" min="0" step="1" id="cash_amount" name="cash_amount" value="{{ old('cash_amount') }}" style="width:140px;">
        </div>
        <button type="submit" class="btn primary sm" style="height:41px;">Grant</button>
    </form>
    @error('cash_amount')<div class="mw-error">{{ $message }}</div>@enderror
    @error('user_id')<div class="mw-error">{{ $message }}</div>@enderror
    @error('subscription_plan_id')<div class="mw-error">{{ $message }}</div>@enderror
</div>

<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Client</th>
                <th>Plan</th>
                <th>Credits remaining</th>
                <th>Period</th>
                <th style="padding-right:16px;">Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($subscriptions as $sub)
            <tr>
                <td style="padding-left:16px;">{{ $sub->clientProfile?->user?->name ?? '—' }}</td>
                <td>{{ $sub->subscriptionPlan?->name ?? '—' }}</td>
                <td>{{ $sub->sessions_remaining }}</td>
                <td style="font-size:12px;color:var(--ink-500);">{{ $sub->current_period_start->format('M j') }} → renews {{ $sub->current_period_end->format('M j, Y') }}</td>
                <td style="padding-right:16px;">
                    @php
                        // Renewal-aware status (2026-10-01) — see ClientSubscription::phase().
                        [$subPillClass, $subPillLabel] = match ($sub->phase()) {
                            \App\Models\ClientSubscription::PHASE_ACTIVE => ['success', 'Active'],
                            \App\Models\ClientSubscription::PHASE_ENDING_SOON => ['warn', 'Renews soon'],
                            \App\Models\ClientSubscription::PHASE_RENEWED, \App\Models\ClientSubscription::PHASE_ROLL_DUE => ['teal', 'Renewed ahead'],
                            \App\Models\ClientSubscription::PHASE_GRACE => ['warn', 'Grace period'],
                            \App\Models\ClientSubscription::PHASE_EXPIRE_DUE => ['danger', 'Lapsing'],
                            default => ['danger', ucfirst($sub->status)],
                        };
                    @endphp
                    <span class="pill {{ $subPillClass }}">{{ $subPillLabel }}</span>
                    @if ($sub->canRenew() && in_array($sub->phase(), [\App\Models\ClientSubscription::PHASE_ACTIVE, \App\Models\ClientSubscription::PHASE_ENDING_SOON, \App\Models\ClientSubscription::PHASE_GRACE], true))
                        {{-- Cash renewal (2026-10-06, roadmap 23). --}}
                        <details style="margin-top:6px;">
                            <summary style="font-size:12px;color:var(--teal-600, #2f6f66);font-weight:700;cursor:pointer;">Record cash renewal</summary>
                            <form method="POST" action="{{ route('admin.client-subscriptions.renew-cash', $sub) }}" style="display:flex;gap:6px;align-items:center;margin-top:6px;" onsubmit="return confirm('Record a cash renewal for this plan? A receipt will be emailed to the client.');">
                                @csrf
                                <input class="mw-field" type="number" min="0" step="1" name="cash_amount" value="{{ (int) $sub->subscriptionPlan?->price }}" style="width:110px;padding:6px 8px;" aria-label="Cash amount">
                                <button type="submit" class="btn primary sm">Save</button>
                            </form>
                        </details>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="5" style="padding:16px;color:var(--ink-500);">No subscriptions granted yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
