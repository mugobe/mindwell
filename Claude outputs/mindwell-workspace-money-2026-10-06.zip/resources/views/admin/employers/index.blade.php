@extends('layouts.app')
@section('title', 'Employers')
@section('content')

<div class="dash-head">
    <h1>Employer accounts</h1>
    <a href="{{ route('admin.employers.create') }}" class="btn primary sm">+ Add employer</a>
</div>

{{-- Contracts ending within 30 days (2026-10-06, roadmap 27). Admins are also emailed. --}}
@php $mwEnding = $employers->filter(fn ($e) => $e->isEndingSoon()); @endphp
@if ($mwEnding->isNotEmpty())
    <div class="mw-alert" style="background:var(--mw-gold, #F6E1A8);color:#6b4a12;margin-bottom:14px;">
        <strong>Contracts ending soon:</strong>
        @foreach ($mwEnding as $e)
            <a href="{{ route('admin.employers.show', $e) }}" style="color:inherit;font-weight:700;">{{ $e->company_name }}</a> ({{ $e->contract_renewal_date->format('j M') }}){{ $loop->last ? '' : ',' }}
        @endforeach
        — contact them about renewing, then update the renewal date.
    </div>
@endif

<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Company</th>
                <th>Contact</th>
                <th>Seats</th>
                <th>Status</th>
                <th>Renews</th>
                <th style="padding-right:16px;"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($employers as $employer)
            <tr>
                <td style="padding-left:16px;">{{ $employer->company_name }}</td>
                <td style="font-size:12px;color:var(--ink-500);">
                    {{ $employer->contact_name ?? '—' }}
                    @if ($employer->contact_email)
                        <div>{{ $employer->contact_email }}</div>
                    @endif
                </td>
                <td>{{ $employer->activeSeatsCount() }} / {{ $employer->seats_count }} used</td>
                <td>
                    <span class="pill {{ $employer->status === 'active' ? 'success' : 'danger' }}">
                        {{ ucfirst($employer->status) }}
                    </span>
                </td>
                <td>
                    {{ $employer->contract_renewal_date?->format('M j, Y') ?? '—' }}
                    @if ($employer->isEndingSoon())<span class="pill warn" style="margin-left:4px;">Ending soon</span>@endif
                </td>
                <td style="padding-right:16px;text-align:right;">
                    <a href="{{ route('admin.employers.show', $employer) }}" class="btn ghost sm">View seats</a>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="padding:16px;color:var(--ink-500);">No employer accounts yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
