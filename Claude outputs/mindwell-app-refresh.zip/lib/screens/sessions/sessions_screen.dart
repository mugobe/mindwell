import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/reload_on_change.dart';
import '../intake/intake_screen.dart';
import '../therapists/therapists_screen.dart';
import 'session_flow.dart';

/// Sessions tab — upcoming (incl. waiting for payment / matching / confirmation) and
/// past, from GET sessions. "Book" opens the therapist list.
class SessionsScreen extends StatefulWidget {
  const SessionsScreen({super.key});

  @override
  State<SessionsScreen> createState() => _SessionsScreenState();
}

class _SessionsScreenState extends State<SessionsScreen> with ReloadOnChange<SessionsScreen> {
  List<Map<String, dynamic>>? _upcoming;
  List<Map<String, dynamic>> _past = const [];
  ApiException? _error;

  @override
  void initState() {
    super.initState();
    reload();
  }

  @override
  Future<void> reload() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('sessions')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _upcoming = ((data['upcoming'] as List?) ?? const []).cast<Map<String, dynamic>>();
        _past = ((data['past'] as List?) ?? const []).cast<Map<String, dynamic>>();
      });
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  void _book() => Navigator.push(context, MaterialPageRoute(builder: (_) => const TherapistsScreen()));

  Future<void> _open(Map<String, dynamic> s) async {
    await openSession(context, s);
    if (mounted) reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your sessions'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Mw.orange, shape: const StadiumBorder(), visualDensity: VisualDensity.compact),
              onPressed: _book,
              icon: const Icon(Icons.add_rounded, size: 18),
              label: const Text('Book', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
      body: _error != null && _upcoming == null
          ? ErrorView(message: _error!.message, onRetry: reload)
          : _upcoming == null
              ? const LoadingView()
              : RefreshIndicator(onRefresh: reload, child: _list()),
    );
  }

  Widget _list() {
    final upcoming = _upcoming!;
    if (upcoming.isEmpty && _past.isEmpty) {
      return ListView(
        children: [
          EmptyState(
            icon: Icons.event_note_rounded,
            title: 'No sessions yet',
            text: 'Answer a few short questions and we will match you with a therapist, or choose one yourself.',
            actions: [
              ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IntakeScreen())),
                child: const Text('Get matched'),
              ),
              OutlinedButton(onPressed: _book, child: const Text('Choose a therapist')),
            ],
          ),
        ],
      );
    }

    // Past sessions grouped by month ("October 2026"), newest first (2026-11-01 refresh).
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    final groups = <String, List<Map<String, dynamic>>>{};
    for (final s in _past) {
      final at = parseDate(s['scheduled_at']);
      final key = at == null ? 'Earlier' : '${months[at.month - 1]} ${at.year}';
      groups.putIfAbsent(key, () => []).add(s);
    }

    var n = 0;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        const _Heading('Coming up'),
        if (upcoming.isEmpty)
          MwFadeIn(
            index: n++,
            child: MwCard(
              child: Row(
                children: [
                  const Expanded(child: Text('Nothing booked right now.', style: TextStyle(color: Mw.ink500))),
                  TextButton(onPressed: _book, child: const Text('Book a session')),
                ],
              ),
            ),
          ),
        for (final s in upcoming) MwFadeIn(index: n++, child: _UpcomingCard(session: s, onTap: () => _open(s))),
        if (groups.isNotEmpty) ...[
          const SizedBox(height: 10),
          const _Heading('Past sessions'),
          for (final e in groups.entries)
            MwFadeIn(
              index: n++,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 6, 4, 8),
                    child: Text(e.key, style: const TextStyle(color: Mw.ink500, fontWeight: FontWeight.w800, fontSize: 13)),
                  ),
                  MwCard(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Column(
                      children: [
                        for (final (i, s) in e.value.indexed) ...[
                          if (i > 0) const Divider(height: 1),
                          _PastRow(session: s, onTap: () => _open(s)),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ],
    );
  }
}

class _Heading extends StatelessWidget {
  const _Heading(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 6, 2, 12),
        child: Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900)),
      );
}

/// Upcoming booking: date block, time and therapist, status pill.
class _UpcomingCard extends StatelessWidget {
  const _UpcomingCard({required this.session, required this.onTap});

  final Map<String, dynamic> session;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final s = session;
    final t = s['therapist'] as Map<String, dynamic>?;
    final at = parseDate(s['scheduled_at']);
    final name = t != null ? '${t['name']}' : null;
    final booked = s['status'] == 'scheduled';

    final title = at != null ? '${fmtTime(at)}${name != null ? ' with $name' : ''}' : (name != null ? 'With $name' : 'Time to be set');
    final sub = [
      if (at != null) fmtRelativeDay(at),
      if (name == null && (s['next_step'] == 'lobby' || s['next_step'] == 'checkout')) 'Therapist to be matched',
      modeLine(s),
    ].join(', ');

    return MwCard(
      onTap: onTap,
      child: Row(
        children: [
          MwDateBlock(at: at, soft: !booked),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900, height: 1.25)),
                const SizedBox(height: 3),
                Text(sub, style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                const SizedBox(height: 8),
                Pill.forStatus(s['status'] as String?, '${s['status_label'] ?? ''}'),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
        ],
      ),
    );
  }
}

/// One past session inside a month group.
class _PastRow extends StatelessWidget {
  const _PastRow({required this.session, required this.onTap});

  final Map<String, dynamic> session;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final s = session;
    final t = s['therapist'] as Map<String, dynamic>?;
    final at = parseDate(s['scheduled_at']);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            MwDateBlock(at: at, soft: true, compact: true),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t != null ? '${t['name']}' : 'No therapist assigned',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5, color: Mw.ink900)),
                  const SizedBox(height: 2),
                  Text([if (at != null) fmtTime(at), modeLine(s)].join(', '), style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
                ],
              ),
            ),
            Pill.forStatus(s['status'] as String?, '${s['status_label'] ?? ''}'),
          ],
        ),
      ),
    );
  }
}
