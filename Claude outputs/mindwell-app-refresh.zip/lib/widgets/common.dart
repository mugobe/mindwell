import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../theme.dart';
import '../utils/crc32.dart';
import '../utils/format.dart';

/// White rounded card with the website's hairline edge.
/// White rounded card (2026-11-01 refresh: 20px corners, soft shadow instead of a grey
/// border, and a small press-in when it can be tapped).
class MwCard extends StatefulWidget {
  const MwCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.color, this.borderColor, this.onTap, this.margin = const EdgeInsets.only(bottom: 14)});

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;
  final Color? color;
  final Color? borderColor;
  final VoidCallback? onTap;

  @override
  State<MwCard> createState() => _MwCardState();
}

class _MwCardState extends State<MwCard> {
  bool _down = false;

  void _press(bool v) {
    if (widget.onTap != null && _down != v) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(20);
    return Padding(
      padding: widget.margin,
      child: AnimatedScale(
        scale: _down ? .98 : 1,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: radius,
            boxShadow: widget.color == null || widget.color == Colors.white ? Mw.cardShadow : null,
          ),
          child: Material(
            color: widget.color ?? Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: radius,
              side: widget.borderColor != null ? BorderSide(color: widget.borderColor!) : BorderSide.none,
            ),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: widget.onTap,
              onHighlightChanged: _press,
              child: Padding(padding: widget.padding, child: widget.child),
            ),
          ),
        ),
      ),
    );
  }
}

/// Fades and lifts its child in when it first appears. Give each item in a list a
/// growing [index] for a gentle one-after-another effect. Skipped when the phone asks
/// for reduced motion.
class MwFadeIn extends StatelessWidget {
  const MwFadeIn({super.key, required this.child, this.index = 0});

  final Widget child;
  final int index;

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return child;
    final delay = (index.clamp(0, 6)) * 60;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 420 + delay),
      curve: Interval(delay / (420 + delay), 1, curve: Curves.easeOutCubic),
      child: child,
      builder: (context, t, child) => Opacity(
        opacity: t,
        child: Transform.translate(offset: Offset(0, (1 - t) * 14), child: child),
      ),
    );
  }
}

/// Date block ("NOV / 3 / Tue"). Navy for booked sessions, soft blue for others;
/// [compact] drops the month for list rows (2026-11-01 refresh, same as the website).
class MwDateBlock extends StatelessWidget {
  const MwDateBlock({super.key, required this.at, this.soft = false, this.compact = false});

  final DateTime? at;
  final bool soft;
  final bool compact;

  static const _months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  static const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  @override
  Widget build(BuildContext context) {
    final a = at;
    final fg = soft ? Mw.teal : Colors.white;
    final fgSoft = soft ? Mw.teal.withValues(alpha: .7) : Colors.white70;
    return Container(
      width: compact ? 46 : 64,
      height: compact ? 50 : 72,
      decoration: BoxDecoration(
        color: soft ? Mw.tealTint : Mw.teal,
        borderRadius: BorderRadius.circular(compact ? 13 : 16),
        boxShadow: soft ? null : const [BoxShadow(color: Color(0x40034C8F), blurRadius: 16, offset: Offset(0, 6))],
      ),
      child: a == null
          ? Icon(Icons.hourglass_top_rounded, color: fg, size: 22)
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (!compact)
                  Text(_months[a.month - 1], style: TextStyle(color: fgSoft, fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                Text('${a.day}', style: TextStyle(color: fg, fontSize: compact ? 17 : 26, height: 1.1, fontWeight: FontWeight.w800)),
                Text(_days[a.weekday - 1], style: TextStyle(color: fgSoft, fontSize: 10.5, fontWeight: FontWeight.w700)),
              ],
            ),
    );
  }
}

/// Mood face (1 = very low … 5 = great), drawn to match the website's faces.
class MwFace extends StatelessWidget {
  const MwFace({super.key, required this.mood, this.size = 36});

  final int mood;
  final double size;

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size.square(size), painter: _FacePainter(mood, Mw.moodFaces[mood] ?? Mw.ink300));
}

class _FacePainter extends CustomPainter {
  _FacePainter(this.mood, this.color);

  final int mood;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 24;
    canvas.scale(s);
    final c = const Offset(12, 12);
    canvas.drawCircle(c, 10.5, Paint()..color = color.withValues(alpha: .18));
    canvas.drawCircle(c, 10.5, Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5);
    final dot = Paint()..color = color;
    canvas.drawCircle(const Offset(9, 10), 1.2, dot);
    canvas.drawCircle(const Offset(15, 10), 1.2, dot);
    final mouth = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    final p = Path();
    switch (mood) {
      case 1:
        p..moveTo(8.5, 16.5)..quadraticBezierTo(12, 13.2, 15.5, 16.5);
      case 2:
        p..moveTo(9, 16)..quadraticBezierTo(12, 14.2, 15, 16);
      case 3:
        p..moveTo(9, 15.5)..lineTo(15, 15.5);
      case 4:
        p..moveTo(9, 14.5)..quadraticBezierTo(12, 16.8, 15, 14.5);
      default:
        p..moveTo(8.5, 14)..quadraticBezierTo(12, 18.4, 15.5, 14);
    }
    canvas.drawPath(p, mouth);
  }

  @override
  bool shouldRepaint(_FacePainter old) => old.mood != mood || old.color != color;
}

/// Coloured initials bubble — same colour per name as the website.
class Avatar extends StatelessWidget {
  const Avatar({super.key, required this.name, this.size = 40, this.photoUrl});

  final String name;
  final double size;
  final String? photoUrl;

  @override
  Widget build(BuildContext context) {
    final color = Mw.avatars[crc32(name.trim()) % Mw.avatars.length];
    final bubble = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      child: Text(
        initials(name),
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: size * 0.36, letterSpacing: .3),
      ),
    );
    if (photoUrl == null || photoUrl!.isEmpty) return bubble;
    return ClipOval(
      child: Image.network(
        photoUrl!,
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => bubble,
      ),
    );
  }
}

/// The app's wordmark: orange dot + "Mindwell".
class MwLogo extends StatelessWidget {
  const MwLogo({super.key, this.color = Mw.ink900, this.size = 26});

  /// White = on the teal welcome screen (white mark + white name). Anything else
  /// shows the full-colour logo from the brand files (2026-11-01).
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    if (color == Colors.white) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset('assets/images/mindwell_mark_white.png', height: size * 1.5),
          SizedBox(width: size * .35),
          Text('Mindwell', style: TextStyle(fontSize: size, fontWeight: FontWeight.w900, color: color, letterSpacing: -.3)),
        ],
      );
    }
    return Image.asset(
      'assets/images/mindwell_logo_horizontal.png',
      height: size * 1.45,
      semanticLabel: 'Mindwell',
    );
  }
}

class PrimaryButton extends StatelessWidget {
  const PrimaryButton({super.key, required this.label, required this.onPressed, this.busy = false, this.color});

  final String label;
  final VoidCallback? onPressed;
  final bool busy;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: color == null ? null : ElevatedButton.styleFrom(backgroundColor: color),
        onPressed: busy ? null : onPressed,
        child: busy
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
            : Text(label),
      ),
    );
  }
}

/// Red/teal message box used for form-level errors and notices.
/// Kind of [MwBanner]: picks the icon and its colour. The surface stays the same
/// neutral grey for every kind, like Google Meet's notices (2026-11-01, Collins:
/// "instead of such overlays lets make some of them feel the way google handles them").
enum MwBannerKind { info, success, error, warning, privacy, event, star, person, chat }

/// Google-style notice: light grey rounded surface, coloured icon, bold title,
/// plain text and optional pill buttons on the right (or below on narrow screens).
class MwBanner extends StatelessWidget {
  const MwBanner({
    super.key,
    this.title,
    this.text,
    this.kind = MwBannerKind.info,
    this.actions = const [],
    this.margin = const EdgeInsets.only(bottom: 14),
  });

  final String? title;
  final String? text;
  final MwBannerKind kind;
  final List<Widget> actions;
  final EdgeInsetsGeometry margin;

  static const surface = Color(0xFFEEF3F6);
  static const ink = Color(0xFF1F2933);
  static const body = Color(0xFF4A5560);

  (IconData, Color) get _icon => switch (kind) {
        MwBannerKind.info => (Icons.info_outline_rounded, Mw.teal),
        MwBannerKind.success => (Icons.check_circle_rounded, const Color(0xFF1E7D4F)),
        MwBannerKind.error => (Icons.error_rounded, const Color(0xFFB3261E)),
        MwBannerKind.warning => (Icons.warning_amber_rounded, const Color(0xFFB06000)),
        MwBannerKind.privacy => (Icons.verified_user_rounded, Mw.teal),
        MwBannerKind.event => (Icons.event_rounded, Mw.teal),
        MwBannerKind.star => (Icons.star_rounded, const Color(0xFFE3A12F)),
        MwBannerKind.person => (Icons.person_rounded, const Color(0xFFB06000)),
        MwBannerKind.chat => (Icons.chat_bubble_outline_rounded, Mw.teal),
      };

  @override
  Widget build(BuildContext context) {
    final (icon, color) = _icon;
    final words = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title != null)
          Text(title!, style: const TextStyle(color: ink, fontWeight: FontWeight.w700, fontSize: 14.5)),
        if (title != null && text != null) const SizedBox(height: 2),
        if (text != null) Text(text!, style: const TextStyle(color: body, fontSize: 13.5, height: 1.4)),
      ],
    );
    return Container(
      width: double.infinity,
      margin: margin,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(padding: const EdgeInsets.only(top: 1), child: Icon(icon, color: color, size: 22)),
              const SizedBox(width: 14),
              Expanded(child: words),
            ],
          ),
          if (actions.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 10, left: 36),
              child: Wrap(spacing: 8, runSpacing: 8, children: actions),
            ),
        ],
      ),
    );
  }
}

/// Outlined (or filled) pill button used inside [MwBanner], like Meet's "Learn more".
class MwPillButton extends StatelessWidget {
  const MwPillButton({super.key, required this.label, required this.onPressed, this.filled = false, this.icon});

  final String label;
  final VoidCallback? onPressed;
  final bool filled;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final shape = const StadiumBorder();
    const pad = EdgeInsets.symmetric(horizontal: 18, vertical: 8);
    const textStyle = TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5);
    final child = icon == null
        ? Text(label)
        : Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 17), const SizedBox(width: 6), Text(label)]);
    if (filled) {
      return FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: Mw.teal, foregroundColor: Colors.white, shape: shape, padding: pad,
          minimumSize: const Size(0, 36), textStyle: textStyle, tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
        child: child,
      );
    }
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: Mw.teal, shape: shape, padding: pad, side: const BorderSide(color: Color(0xFF7A8590)),
        minimumSize: const Size(0, 36), textStyle: textStyle, tapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
      child: child,
    );
  }
}

/// Short one-line message (form errors, "saved" confirmations). Now drawn as an [MwBanner].
class NoticeBox extends StatelessWidget {
  const NoticeBox({super.key, required this.text, this.error = true});

  final String text;
  final bool error;

  @override
  Widget build(BuildContext context) =>
      MwBanner(text: text, kind: error ? MwBannerKind.error : MwBannerKind.success);
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});

  @override
  Widget build(BuildContext context) => const Center(child: CircularProgressIndicator());
}

class ErrorView extends StatelessWidget {
  const ErrorView({super.key, required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 46, color: Mw.ink300),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Mw.ink700, fontSize: 14.5)),
            const SizedBox(height: 16),
            OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 6, 2, 10),
      child: Text(text.toUpperCase(),
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Mw.ink500, letterSpacing: .6)),
    );
  }
}

void showSnack(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: error ? Mw.danger : Mw.ink900,
      behavior: SnackBarBehavior.floating,
    ));
}

/// For screens that arrive in the next app stage.
void comingSoon(BuildContext context, String what) {
  showSnack(context, '$what is coming in the next app update.');
}

Future<void> openLink(BuildContext context, String? url) async {
  if (url == null || url.isEmpty) return;
  final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  if (!ok && context.mounted) showSnack(context, "Couldn't open that link.", error: true);
}

Future<void> callNumber(BuildContext context, String dial) async {
  final ok = await launchUrl(Uri(scheme: 'tel', path: dial));
  if (!ok && context.mounted) showSnack(context, 'Call $dial from your phone.', error: true);
}

/// Small rounded label, e.g. a session's status.
class Pill extends StatelessWidget {
  const Pill(this.text, {super.key, this.color = Mw.teal, this.background = Mw.tealTint});

  final String text;
  final Color color;
  final Color background;

  /// Colours for a session status, matching the website's pills.
  factory Pill.forStatus(String? status, String label) {
    switch (status) {
      case 'scheduled':
        return Pill(label);
      case 'completed':
        return Pill(label, color: Mw.ink500, background: Mw.canvas);
      case 'cancelled':
        return Pill(label, color: Mw.danger, background: Mw.dangerTint);
      default:
        return Pill(label, color: Mw.orangeText, background: Mw.orangeTint);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(999)),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
    );
  }
}

/// Icon + title + text, centred — for empty lists and "all done" screens.
class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, this.text, this.actions = const []});

  final IconData icon;
  final String title;
  final String? text;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 36),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: const BoxDecoration(color: Mw.tealTint, shape: BoxShape.circle),
            child: Icon(icon, color: Mw.teal, size: 30),
          ),
          const SizedBox(height: 14),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Mw.ink900)),
          if (text != null) ...[
            const SizedBox(height: 6),
            Text(text!, textAlign: TextAlign.center, style: const TextStyle(color: Mw.ink500, height: 1.45)),
          ],
          if (actions.isNotEmpty) ...[
            const SizedBox(height: 18),
            ...actions.map((a) => Padding(padding: const EdgeInsets.only(bottom: 10), child: a)),
          ],
        ],
      ),
    );
  }
}

/// Yes/no dialog. Returns true only when the person taps [yes].
Future<bool> confirmDialog(BuildContext context, {required String title, String? body, String yes = 'Yes', String no = 'Cancel', bool danger = false}) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: body == null ? null : Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(no)),
        TextButton(
          style: danger ? TextButton.styleFrom(foregroundColor: Mw.danger) : null,
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(yes),
        ),
      ],
    ),
  );
  return ok == true;
}
