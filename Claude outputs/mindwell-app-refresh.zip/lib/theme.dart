import 'package:flutter/material.dart';

/// Brand colours, matched to the logo on 2026-11-01 (same as the website's client side).
/// The old names (teal, orange…) are kept so every screen follows without edits:
/// "teal" is now the logo navy and "orange" the logo orange.
class Mw {
  static const teal = Color(0xFF034C8F); // logo navy (primary)
  static const tealDark = Color(0xFF022F5C);
  static const tealLight = Color(0xFF2A7BC8);
  static const tealTint = Color(0xFFE6EFF9);
  static const orange = Color(0xFFEE7800); // logo orange
  static const orangeTint = Color(0xFFFFF1E0);
  static const orangeText = Color(0xFF8A4A00);
  static const green = Color(0xFF00A87C); // logo green
  static const greenTint = Color(0xFFDDF5EC);
  static const purple = Color(0xFF7A4CC2);
  static const purpleTint = Color(0xFFF1E8FB);
  static const canvas = Color(0xFFF4F7FB);
  static const ink900 = Color(0xFF151B26);
  static const ink700 = Color(0xFF333D4C);
  static const ink500 = Color(0xFF5B6472);
  static const ink300 = Color(0xFF8B93A1);
  static const line = Color(0xFFE3E8EF);
  static const danger = Color(0xFFC62828);
  static const dangerTint = Color(0xFFFDECEC);
  static const gold = Color(0xFFE3A12F);

  static const font = 'PlusJakartaSans';

  /// Name-bubble colours (navy, green, orange, purple, blue).
  static const avatars = [
    Color(0xFF034C8F),
    Color(0xFF00A87C),
    Color(0xFFEE7800),
    Color(0xFF7A4CC2),
    Color(0xFF2A7BC8),
  ];

  /// Mood colours from the journal (1 = very low … 5 = great).
  static const moods = {
    1: Color(0xFFF4A8AA),
    2: Color(0xFFF8C99E),
    3: Color(0xFFF2DD95),
    4: Color(0xFFA8DEC4),
    5: Color(0xFF6FCDA9),
  };

  /// Strong mood colours for the face icons (same as the website).
  static const moodFaces = {
    1: Color(0xFFE5484D),
    2: Color(0xFFF2994A),
    3: Color(0xFFE3B341),
    4: Color(0xFF3FB984),
    5: Color(0xFF0E9F6E),
  };

  static const navGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF022F5C), Color(0xFF034C8F), Color(0xFF0B5FB0)],
  );

  /// Soft greeting background (navy → green → orange tints), as on the website home.
  static const heroGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFEAF2FC), Color(0xFFEEF8F4), Color(0xFFFFF4E6)],
    stops: [0, .55, 1],
  );

  static const cardShadow = [
    BoxShadow(color: Color(0x0D032850), blurRadius: 2, offset: Offset(0, 1)),
    BoxShadow(color: Color(0x0D032850), blurRadius: 0, spreadRadius: 1),
  ];
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: Mw.teal,
    primary: Mw.teal,
    secondary: Mw.orange,
    surface: Colors.white,
    error: Mw.danger,
  );

  final inputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: const BorderSide(color: Mw.line),
  );

  return ThemeData(
    useMaterial3: true,
    fontFamily: Mw.font,
    colorScheme: scheme,
    // Smooth page changes: fade-forward on Android, the normal slide on iPhone.
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: FadeForwardsPageTransitionsBuilder(),
      TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
    }),
    scaffoldBackgroundColor: Mw.canvas,
    appBarTheme: const AppBarTheme(
      backgroundColor: Mw.canvas,
      foregroundColor: Mw.ink900,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(fontFamily: Mw.font, fontSize: 19, fontWeight: FontWeight.w800, color: Mw.ink900),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: inputBorder,
      enabledBorder: inputBorder,
      focusedBorder: inputBorder.copyWith(borderSide: const BorderSide(color: Mw.teal, width: 1.6)),
      errorBorder: inputBorder.copyWith(borderSide: const BorderSide(color: Mw.danger)),
      labelStyle: const TextStyle(color: Mw.ink500),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: Mw.teal,
        foregroundColor: Colors.white,
        minimumSize: const Size(64, 50),
        shape: const StadiumBorder(),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
        elevation: 0,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: Mw.teal,
        minimumSize: const Size(64, 46),
        shape: const StadiumBorder(),
        side: const BorderSide(color: Mw.teal, width: 1.4),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: Mw.teal,
        textStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: Mw.tealTint,
      elevation: 0,
      height: 70,
      labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
            fontFamily: Mw.font,
            fontSize: 12,
            fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600,
            color: states.contains(WidgetState.selected) ? Mw.teal : Mw.ink500,
          )),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    dividerColor: Mw.line,
  );
}
