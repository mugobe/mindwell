<?php

/*
 * Which payment service starts NEW Mobile Money payments (2026-11-02):
 *
 *   PAYMENT_GATEWAY=flutterwave   (default, what the site used until now)
 *   PAYMENT_GATEWAY=marzpay
 *
 * Each payment remembers the service it was started with (payment_transactions.gateway),
 * so switching never strands a payment that is already waiting: it is still checked
 * with the service that started it.
 */

return [

    'gateway' => env('PAYMENT_GATEWAY', 'flutterwave'),

    // The "Simulate approval / failure" buttons on the waiting page and in the app
    // (2026-11-03). They let a payment be marked paid WITHOUT any money moving, so they
    // are OFF unless this is true, and even then only on local/staging with a sandbox.
    'test_mode' => (bool) env('PAYMENT_TEST_MODE', false),

];
