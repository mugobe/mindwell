<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Number the completed sessions that were closed before session numbers existed
 * (2026-10-06, roadmap 73). Per client, in date order: 1, 2, 3… Only fills blanks —
 * a number already set is never changed. Safe to run more than once.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('therapy_sessions') || ! Schema::hasColumn('therapy_sessions', 'session_number')) {
            return;
        }

        $clientIds = DB::table('therapy_sessions')
            ->where('status', 'completed')
            ->whereNull('session_number')
            ->distinct()
            ->pluck('client_profile_id');

        foreach ($clientIds as $clientId) {
            $rows = DB::table('therapy_sessions')
                ->where('client_profile_id', $clientId)
                ->where('status', 'completed')
                ->orderByRaw('COALESCE(scheduled_at, closed_at, created_at)')
                ->orderBy('created_at')
                ->get(['id', 'session_number']);

            $n = 0;
            foreach ($rows as $row) {
                $n++;
                if ($row->session_number === null) {
                    DB::table('therapy_sessions')->where('id', $row->id)->update(['session_number' => $n]);
                }
            }
        }
    }

    public function down(): void
    {
        // Nothing to undo — numbers are harmless to keep.
    }
};
