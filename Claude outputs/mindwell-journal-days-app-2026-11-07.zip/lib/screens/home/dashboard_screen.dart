import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/rate_sheet.dart';
import '../../widgets/reload_on_change.dart';
import '../intake/about_you_screen.dart';
import '../intake/intake_screen.dart';
import '../more/my_details_screen.dart';
import '../progress/check_in_screen.dart';
import '../progress/progress_screen.dart';
import '../sessions/session_detail_screen.dart';
import '../sessions/session_flow.dart';
import '../therapists/therapists_screen.dart';
import '../urgent_help_screen.dart';
import '../video/room_screen.dart';

/// Home — the same cards as the website dashboard, from GET /dashboard.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.onOpenTab});

  /// Switch bottom tab (1 Sessions, 2 Messages, 3 Journal, 4 More).
  final void Function(int index) onOpenTab;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with ReloadOnChange<DashboardScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Future<void> reload() => _load();

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = _data == null;
      _error = null;
    });
    try {
      final data = await context.read<AppState>().api.get('dashboard');
      if (mounted) setState(() => _data = data as Map<String, dynamic>);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveMood(int mood) async {
    try {
      final res = await context.read<AppState>().api.post('journal', {'mood': mood});
      if (!mounted) return;
      // 2026-11-07: one mood per day; the server says if today's mood was changed instead.
      final action = res is Map ? res['action'] : null;
      showSnack(context, action == null || action == 'mood_saved'
          ? 'Thank you for checking in. It is saved in your journal.'
          : '${res['message']}');
      context.read<AppState>().dataChanged(); // Home and the Journal tab both reload
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  Future<void> _aboutNotNow() async {
    try {
      await context.read<AppState>().api.post('about-you/not-now');
      if (mounted) _load();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final d = _data;

    return Scaffold(
      appBar: AppBar(
        title: const MwLogo(size: 22),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton.icon(
              style: TextButton.styleFrom(foregroundColor: Mw.danger, backgroundColor: Mw.dangerTint, shape: const StadiumBorder()),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen())),
              icon: const Icon(Icons.favorite_rounded, size: 16),
              label: const Text('Get help now'),
            ),
          ),
        ],
      ),
      body: _loading
          ? const LoadingView()
          : (_error != null && d == null)
              ? ErrorView(message: _error!.message, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                    children: [
                      MwFadeIn(child: _hero(d, '${d?['greeting_name'] ?? state.firstName}')),
                      const SizedBox(height: 16),
                      if (d != null)
                        for (final (i, card) in _cards(d).indexed) MwFadeIn(index: i + 1, child: card),
                    ],
                  ),
                ),
    );
  }

  /// Greeting with one clear next step for where the client is right now (2026-11-01,
  /// same idea as the website home).
  Widget _hero(Map<String, dynamic>? d, String name) {
    String text;
    Widget? action;
    String? hint;

    if (d == null) {
      text = 'Welcome to Mindwell.';
    } else if (d['intake_done'] != true) {
      text = 'Start with a short assessment so we can match you with the right therapist.';
      action = PrimaryButton(label: 'Start my assessment', color: Mw.orange, onPressed: () => _open(const IntakeScreen()));
      hint = 'About 5 minutes. Private and confidential.';
    } else if (d['next_session'] is Map) {
      final next = d['next_session'] as Map<String, dynamic>;
      final at = parseDate(next['scheduled_at']);
      final who = '${(next['therapist'] as Map?)?['name'] ?? 'your therapist'}';
      final join = next['join'] as Map<String, dynamic>?;
      final canJoin = next['mode'] != 'in_person' && join?['state'] == 'open';
      text = at != null
          ? 'Your next session with $who is ${_dayWord(at)} at ${fmtTime(at)}.'
          : 'Your next session with $who is booked.';
      action = canJoin
          ? PrimaryButton(label: 'Join session', color: Mw.orange, onPressed: () => _open(RoomScreen(sessionId: '${next['id']}')))
          : PrimaryButton(label: 'See session details', onPressed: () => _open(SessionDetailScreen(sessionId: '${next['id']}')));
    } else if (d['in_progress'] is Map) {
      final s = d['in_progress'] as Map<String, dynamic>;
      text = switch (s['next_step']) {
        'checkout' => 'You have a session waiting for payment. Pick up where you left off to confirm it.',
        'lobby' => 'We are finding the right therapist for you.',
        'awaiting_approval' => 'Your booking is with our team. We will confirm it soon.',
        _ => 'You have a session in progress.',
      };
      action = PrimaryButton(
        label: 'Continue',
        color: Mw.orange,
        onPressed: () async {
          await openSession(context, s);
          if (mounted) _load();
        },
      );
    } else {
      text = 'Ready for your next session? Choose a therapist and a time that suits you.';
      action = PrimaryButton(label: 'Book a session', color: Mw.orange, onPressed: () => _open(const TherapistsScreen()));
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      decoration: BoxDecoration(gradient: Mw.heroGradient, borderRadius: BorderRadius.circular(24)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(fmtDayLong(DateTime.now()),
                        style: TextStyle(color: Mw.teal.withValues(alpha: .75), fontSize: 13, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text('${greeting()}, $name',
                        style: const TextStyle(fontSize: 25, height: 1.15, fontWeight: FontWeight.w800, color: Mw.tealDark, letterSpacing: -.4)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const _Sprout(size: 74),
            ],
          ),
          const SizedBox(height: 8),
          Text(text, style: const TextStyle(color: Mw.ink700, fontSize: 14.5, height: 1.45)),
          if (action != null) ...[
            const SizedBox(height: 14),
            action,
          ],
          if (hint != null) ...[
            const SizedBox(height: 8),
            Text(hint, style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
          ],
        ],
      ),
    );
  }

  String _dayWord(DateTime d) {
    final now = DateTime.now();
    final day = DateTime(d.year, d.month, d.day);
    final today = DateTime(now.year, now.month, now.day);
    final diff = day.difference(today).inDays;
    if (diff == 0) return 'today';
    if (diff == 1) return 'tomorrow';
    return 'on ${fmtDayLong(d)}';
  }

  List<Widget> _cards(Map<String, dynamic> d) {
    final cards = <Widget>[];

    if (d['next_session'] is Map) {
      final next = d['next_session'] as Map<String, dynamic>;
      cards.add(_NextSessionCard(
        session: next,
        onOpen: () => _open(SessionDetailScreen(sessionId: '${next['id']}')),
        onJoin: () => _open(RoomScreen(sessionId: '${next['id']}')),
      ));
    }

    final checkIn = d['check_in'] as Map<String, dynamic>?;
    if (checkIn?['due'] == true) {
      cards.add(MwBanner(
        kind: MwBannerKind.event,
        title: 'Time for your check-in',
        text: 'It takes about 3 minutes and helps you and your therapist see how things are changing.',
        actions: [MwPillButton(label: 'Start check-in', filled: true, onPressed: () => _open(const CheckInScreen()))],
      ));
    }

    // From AppState (refreshed every 30s and after reading a chat), not the dashboard
    // answer, so the card clears as soon as the messages are read.
    final unread = context.read<AppState>().unreadMessages;
    if (unread > 0) {
      cards.add(MwCard(
        onTap: () => widget.onOpenTab(2),
        child: Row(
          children: [
            const Icon(Icons.chat_bubble_rounded, color: Mw.orange),
            const SizedBox(width: 12),
            Expanded(
              child: Text(unread == 1 ? 'You have a new message' : 'You have $unread new messages',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900)),
            ),
            const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
          ],
        ),
      ));
    }

    if (d['rate_session'] is Map) {
      cards.add(_RateCard(rate: d['rate_session'] as Map<String, dynamic>, onDone: _load));
    }

    if (d['about_you_prompt'] == true) {
      cards.add(MwBanner(
        kind: MwBannerKind.chat,
        title: 'Tell your therapist a bit about you',
        text: 'What brings you here and what you hope for. It takes a couple of minutes and every question is optional.',
        actions: [
          MwPillButton(label: 'Start', filled: true, onPressed: () => _open(const AboutYouScreen())),
          MwPillButton(label: 'Not now', onPressed: _aboutNotNow),
        ],
      ));
    }

    if (d['emergency_contact_missing'] == true) {
      cards.add(MwBanner(
        kind: MwBannerKind.person,
        title: 'Add an emergency contact',
        text: 'Someone we can call if we are ever worried about your safety. Only your care team can see it.',
        actions: [MwPillButton(label: 'Add contact', onPressed: () => _open(const MyDetailsScreen()))],
      ));
    }

    if (d['intake_done'] == true) cards.add(_MoodCard(moodToday: d['mood_today'] as int?, onPick: _saveMood, onJournal: () => widget.onOpenTab(3)));

    cards.add(_QuickLinks(
      onBook: () => _open(const TherapistsScreen()),
      onMessages: () => widget.onOpenTab(2),
      onJournal: () => widget.onOpenTab(3),
      onProgress: () => _open(const ProgressScreen()),
    ));

    final coverage = d['coverage'] as Map<String, dynamic>?;
    if (coverage != null) {
      cards.add(MwCard(
        child: Row(
          children: [
            Icon(coverage['type'] == 'employer' ? Icons.business_rounded : Icons.workspace_premium_outlined, color: Mw.teal),
            const SizedBox(width: 12),
            Expanded(child: Text('${coverage['label']}', style: const TextStyle(fontWeight: FontWeight.w700, color: Mw.ink900))),
          ],
        ),
      ));
    }

    cards.add(const MwBanner(
      kind: MwBannerKind.privacy,
      title: 'Your privacy comes first',
      text: 'Your sessions and reports are confidential. Only you and your therapist can see them.',
    ));

    return cards;
  }
}

class _NextSessionCard extends StatelessWidget {
  const _NextSessionCard({required this.session, required this.onOpen, required this.onJoin});

  final Map<String, dynamic> session;
  final VoidCallback onOpen;
  final VoidCallback onJoin;

  @override
  Widget build(BuildContext context) {
    final therapist = session['therapist'] as Map<String, dynamic>?;
    final name = '${therapist?['name'] ?? 'Your therapist'}';
    final at = parseDate(session['scheduled_at']);
    final inPerson = session['mode'] == 'in_person';
    final join = session['join'] as Map<String, dynamic>?;
    final opensAt = parseDate(join?['opens_at']);

    String status;
    var canJoin = false;
    if (inPerson) {
      status = ((session['location'] as Map?)?['text'] as String?) ?? 'Our team will confirm the place.';
    } else if (join?['state'] == 'open') {
      canJoin = true;
      status = join?['therapist_in_room'] == true ? '$name is in the room. Join now.' : 'Your room is open.';
    } else if (join?['state'] == 'too_early' && opensAt != null) {
      status = 'You can join from ${fmtTime(opensAt)}${join?['therapist_in_room'] == true ? ', or now because $name is ready' : ''}.';
    } else {
      status = 'Video session';
    }

    String when = 'Next session';
    if (at != null) {
      final now = DateTime.now();
      final days = DateTime(at.year, at.month, at.day).difference(DateTime(now.year, now.month, now.day)).inDays;
      when = days <= 0 ? 'Next session, today' : (days == 1 ? 'Next session, tomorrow' : 'Next session, in $days days');
    }

    return MwCard(
      onTap: onOpen,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              MwDateBlock(at: at),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(when.toUpperCase(),
                        style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: Mw.green, letterSpacing: .5)),
                    const SizedBox(height: 4),
                    Text(at != null ? '${fmtTime(at)} with $name' : 'Time to be confirmed',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900, height: 1.25)),
                    const SizedBox(height: 3),
                    Text('${inPerson ? 'In person' : 'Video session'}, ${session['duration_minutes'] ?? 70} minutes',
                        style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              if (canJoin) const _LiveDot(),
              Expanded(
                child: Text(status,
                    style: TextStyle(color: canJoin ? Mw.green : Mw.ink700, fontWeight: canJoin ? FontWeight.w800 : FontWeight.w500, fontSize: 13.5)),
              ),
            ],
          ),
          if (canJoin) ...[
            const SizedBox(height: 12),
            PrimaryButton(label: 'Join session', color: Mw.orange, onPressed: onJoin),
          ],
        ],
      ),
    );
  }
}

/// Small green dot that pulses while a room is open.
class _LiveDot extends StatefulWidget {
  const _LiveDot();

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final still = MediaQuery.of(context).disableAnimations;
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => Container(
          width: 9,
          height: 9,
          decoration: BoxDecoration(
            color: Mw.green,
            shape: BoxShape.circle,
            boxShadow: still
                ? null
                : [BoxShadow(color: Mw.green.withValues(alpha: .45 * (1 - _c.value)), spreadRadius: 9 * _c.value)],
          ),
        ),
      ),
    );
  }
}

class _MoodCard extends StatelessWidget {
  const _MoodCard({required this.moodToday, required this.onPick, required this.onJournal});

  final int? moodToday;
  final void Function(int) onPick;
  final VoidCallback onJournal;

  static const _labels = {1: 'Very low', 2: 'Low', 3: 'Okay', 4: 'Good', 5: 'Great'};

  @override
  Widget build(BuildContext context) {
    final picked = moodToday;
    return MwCard(
      onTap: picked != null ? onJournal : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('How are you feeling today?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900)),
          const SizedBox(height: 3),
          Text(
            picked != null
                ? 'You said ${(_labels[picked] ?? '').toLowerCase()}. Tap to open your journal.'
                : 'Tap one. It is saved privately in your journal.',
            style: const TextStyle(color: Mw.ink500, fontSize: 13),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              for (final e in _labels.entries)
                Expanded(
                  child: _MoodButton(
                    mood: e.key,
                    label: e.value,
                    selected: picked == e.key,
                    faded: picked != null && picked != e.key,
                    onTap: picked == null ? () => onPick(e.key) : null,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MoodButton extends StatefulWidget {
  const _MoodButton({required this.mood, required this.label, required this.selected, required this.faded, this.onTap});

  final int mood;
  final String label;
  final bool selected;
  final bool faded;
  final VoidCallback? onTap;

  @override
  State<_MoodButton> createState() => _MoodButtonState();
}

class _MoodButtonState extends State<_MoodButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: widget.faded ? .35 : 1,
      duration: const Duration(milliseconds: 250),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: widget.onTap,
        onHighlightChanged: (v) => setState(() => _down = v),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: widget.selected ? Mw.tealTint : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            children: [
              AnimatedScale(
                scale: _down ? 1.18 : (widget.selected ? 1.08 : 1),
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutBack,
                child: MwFace(mood: widget.mood, size: 36),
              ),
              const SizedBox(height: 6),
              Text(widget.label,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: widget.selected ? Mw.ink900 : Mw.ink500)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Four shortcut tiles, as on the website home.
class _QuickLinks extends StatelessWidget {
  const _QuickLinks({required this.onBook, required this.onMessages, required this.onJournal, required this.onProgress});

  final VoidCallback onBook;
  final VoidCallback onMessages;
  final VoidCallback onJournal;
  final VoidCallback onProgress;

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, Color bg, Color fg, String label, VoidCallback onTap) => Expanded(
          child: Material(
            color: const Color(0xFFF7F9FC),
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(11)),
                      child: Icon(icon, color: fg, size: 20),
                    ),
                    const SizedBox(height: 10),
                    Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: Mw.ink900, height: 1.25)),
                  ],
                ),
              ),
            ),
          ),
        );

    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Quick links', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900)),
          const SizedBox(height: 12),
          Row(children: [
            tile(Icons.event_available_rounded, const Color(0xFFFFEBD6), const Color(0xFFC25E00), 'Book a session', onBook),
            const SizedBox(width: 10),
            tile(Icons.chat_bubble_outline_rounded, Mw.tealTint, Mw.teal, 'Message my therapist', onMessages),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            tile(Icons.menu_book_rounded, Mw.greenTint, Mw.green, 'Write in my journal', onJournal),
            const SizedBox(width: 10),
            tile(Icons.insights_rounded, Mw.purpleTint, Mw.purple, 'See my progress', onProgress),
          ]),
        ],
      ),
    );
  }
}

/// The swaying plant from the website greeting (navy stem, green and orange leaves).
class _Sprout extends StatefulWidget {
  const _Sprout({this.size = 74});

  final double size;

  @override
  State<_Sprout> createState() => _SproutState();
}

class _SproutState extends State<_Sprout> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 5))..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final still = MediaQuery.of(context).disableAnimations;
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(painter: _SproutPainter(still ? .5 : Curves.easeInOut.transform(_c.value))),
      ),
    );
  }
}

class _SproutPainter extends CustomPainter {
  _SproutPainter(this.t);

  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 100;
    canvas.scale(s);
    canvas.drawCircle(const Offset(42, 58), 34, Paint()..color = const Color(0xFFD7E6F7));
    canvas.drawCircle(const Offset(74, 40), 22, Paint()..color = const Color(0xFFCDEFE2));
    canvas.drawCircle(Offset(86, 12 + 3 * t), 6, Paint()..color = const Color(0xFFFFD29E));

    // Sway around the base of the stem.
    canvas.save();
    canvas.translate(50, 94);
    canvas.rotate((t - .5) * .07);
    canvas.translate(-50, -94);
    final stem = Paint()
      ..color = Mw.teal
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(Path()..moveTo(50, 94)..cubicTo(50, 74, 49, 58, 52, 40), stem);
    Path leaf(Offset a, Offset c1, Offset tip, Offset c2) => Path()
      ..moveTo(a.dx, a.dy)
      ..quadraticBezierTo(c1.dx, c1.dy, tip.dx, tip.dy)
      ..quadraticBezierTo(c2.dx, c2.dy, a.dx, a.dy);
    canvas.drawPath(leaf(const Offset(51, 70), const Offset(34, 72), const Offset(28, 54), const Offset(46, 52)), Paint()..color = const Color(0xFF00B888));
    canvas.drawPath(leaf(const Offset(51, 60), const Offset(70, 58), const Offset(74, 40), const Offset(56, 42)), Paint()..color = const Color(0xFF34C79E));
    canvas.drawPath(leaf(const Offset(52, 42), const Offset(42, 30), const Offset(54, 16), const Offset(62, 30)), Paint()..color = const Color(0xFFF88000));
    canvas.restore();
    canvas.drawLine(const Offset(34, 95), const Offset(66, 95),
        Paint()
          ..color = Mw.teal.withValues(alpha: .25)
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round);
  }

  @override
  bool shouldRepaint(_SproutPainter old) => old.t != t;
}

class _RateCard extends StatelessWidget {
  const _RateCard({required this.rate, required this.onDone});

  final Map<String, dynamic> rate;
  final VoidCallback onDone;

  Future<void> _skip(BuildContext context) async {
    try {
      await context.read<AppState>().api.post('sessions/${rate['session_id']}/rating', {'skip': true});
      onDone();
    } on ApiException catch (e) {
      if (context.mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final at = parseDate(rate['scheduled_at']);
    return MwBanner(
      kind: MwBannerKind.star,
      title: 'How was your session with ${rate['therapist_name']}?',
      text: at != null ? '${fmtDayLong(at)}. It only takes a few seconds.' : 'It only takes a few seconds.',
      actions: [
        MwPillButton(
          label: 'Rate it',
          filled: true,
          onPressed: () async {
            final sent = await showRateSheet(context, sessionId: '${rate['session_id']}', therapistName: '${rate['therapist_name']}');
            if (sent) onDone();
          },
        ),
        MwPillButton(label: 'Not now', onPressed: () => _skip(context)),
      ],
    );
  }
}
