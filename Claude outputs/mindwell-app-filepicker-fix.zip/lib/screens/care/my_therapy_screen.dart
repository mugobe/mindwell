import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/reload_on_change.dart';
import '../messages/chat_screen.dart';
import '../progress/progress_screen.dart';
import '../sessions/session_flow.dart';
import '../therapists/therapists_screen.dart';
import 'homework_screen.dart';
import 'resources_screen.dart';

/// My therapy (GET my-therapy), 2026-11-07: the client's therapist and next session,
/// goals (they move the progress), homework (they answer it) and resources the therapist
/// sent. Same as the website's My therapy page.
class MyTherapyScreen extends StatefulWidget {
  const MyTherapyScreen({super.key});

  @override
  State<MyTherapyScreen> createState() => _MyTherapyScreenState();
}

class _MyTherapyScreenState extends State<MyTherapyScreen> with ReloadOnChange<MyTherapyScreen> {
  Map<String, dynamic>? _d;
  ApiException? _error;

  @override
  void initState() {
    super.initState();
    reload();
  }

  @override
  Future<void> reload() async {
    try {
      final d = (await context.read<AppState>().api.get('my-therapy')) as Map<String, dynamic>;
      if (mounted) {
        setState(() {
          _d = d;
          _error = null;
        });
      }
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  Future<void> _progress(Map<String, dynamic> g) async {
    var value = ((g['progress'] as num?) ?? 0).toDouble();
    final note = TextEditingController();
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(18, 18, 18, 18 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${g['title']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900)),
              const SizedBox(height: 10),
              Text('How far along are you? ${value.round()}%', style: const TextStyle(fontWeight: FontWeight.w700, color: Mw.ink700)),
              Slider(value: value, min: 0, max: 100, divisions: 10, label: '${value.round()}%', activeColor: Mw.green, onChanged: (v) => setSheet(() => value = v)),
              TextField(controller: note, maxLength: 1000, minLines: 2, maxLines: 4, decoration: const InputDecoration(hintText: 'What helped, or what got in the way? (optional)', counterText: '')),
              const SizedBox(height: 12),
              PrimaryButton(label: 'Save', onPressed: () => Navigator.pop(ctx, true)),
            ],
          ),
        ),
      ),
    );
    if (saved != true || !mounted) return;
    try {
      final res = await context.read<AppState>().api.post('goals/${g['id']}/progress', {'progress': value.round(), 'note': note.text.trim()});
      if (!mounted) return;
      showSnack(context, res is Map && res['message'] is String ? res['message'] as String : 'Saved.');
      reload();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _d;
    return Scaffold(
      appBar: AppBar(title: const Text('My therapy')),
      body: _error != null && d == null
          ? ErrorView(message: _error!.message, onRetry: reload)
          : d == null
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: reload,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                    children: [
                      _hero(d),
                      _goals(((d['goals'] as List?) ?? const []).cast<Map<String, dynamic>>()),
                      _homework(((d['homework'] as List?) ?? const []).cast<Map<String, dynamic>>()),
                      const SectionTitle('From your therapist'),
                      ...() {
                        final shared = ((d['shared_resources'] as List?) ?? const []).cast<Map<String, dynamic>>();
                        if (shared.isEmpty) {
                          return [const MwCard(child: Text('Nothing yet. Your therapist can send you reads, worksheets and audio here.', style: TextStyle(color: Mw.ink500)))];
                        }
                        return [
                          for (final s in shared)
                            ResourceTile(
                              resource: (s['resource'] as Map).cast<String, dynamic>(),
                              subtitle: (s['note'] ?? '').toString().isNotEmpty ? '"${s['note']}"' : null,
                              isNew: s['opened'] != true,
                            ),
                        ];
                      }(),
                      Row(children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ResourcesScreen())),
                            icon: const Icon(Icons.menu_book_rounded),
                            label: const Text('All resources'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProgressScreen())),
                            icon: const Icon(Icons.insights_rounded),
                            label: const Text('My progress'),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),
    );
  }

  Widget _hero(Map<String, dynamic> d) {
    final t = (d['therapist'] as Map?)?.cast<String, dynamic>();
    final next = (d['next_session'] as Map?)?.cast<String, dynamic>();
    final at = parseDate(next?['scheduled_at']);
    final done = (d['completed_sessions'] as num?)?.toInt() ?? 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(gradient: Mw.heroGradient, borderRadius: BorderRadius.circular(22)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Avatar(name: '${t?['name'] ?? '?'}', size: 56, photoUrl: t?['photo_url'] as String?),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t == null ? 'GETTING STARTED' : 'YOUR THERAPIST', style: const TextStyle(color: Mw.green, fontWeight: FontWeight.w800, fontSize: 11.5, letterSpacing: .6)),
                    Text('${t?['name'] ?? 'No therapist yet'}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Mw.tealDark)),
                    Text(
                      at != null
                          ? 'Next session ${fmtRelativeDay(at).toLowerCase() == 'today' || fmtRelativeDay(at).toLowerCase() == 'tomorrow' ? fmtRelativeDay(at).toLowerCase() : fmtDay(at)} at ${fmtTime(at)}'
                          : (t != null ? 'No session booked. $done ${done == 1 ? 'session' : 'sessions'} so far.' : 'Book your first session to meet a therapist.'),
                      style: const TextStyle(color: Mw.ink700, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            if (next != null)
              MwPillButton(label: 'Open session', filled: true, onPressed: () => Navigator.push(context, sessionRoute(next)))
            else
              MwPillButton(label: 'Book a session', filled: true, onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TherapistsScreen()))),
            if (t != null)
              MwPillButton(label: 'Message', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(therapist: t)))),
          ]),
        ],
      ),
    );
  }

  Widget _goals(List<Map<String, dynamic>> goals) {
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Expanded(child: Text('Goals', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900))),
            Text('${goals.where((g) => g['status'] == 'achieved').length} of ${goals.length} achieved', style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
          ]),
          const SizedBox(height: 6),
          if (goals.isEmpty)
            const Text('No goals yet. You and your therapist will set some together in a session.', style: TextStyle(color: Mw.ink500, fontSize: 13)),
          for (final g in goals)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(child: Text('${g['title']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5, color: Mw.ink900))),
                    Pill('${g['status_label']}',
                        color: g['status'] == 'achieved' ? Mw.green : (g['status'] == 'active' ? Mw.teal : Mw.ink500),
                        background: g['status'] == 'achieved' ? Mw.greenTint : (g['status'] == 'active' ? Mw.tealTint : Mw.canvas)),
                  ]),
                  if ((g['details'] ?? '').toString().isNotEmpty)
                    Padding(padding: const EdgeInsets.only(top: 3), child: Text('${g['details']}', style: const TextStyle(color: Mw.ink700, fontSize: 13))),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: LinearProgressIndicator(value: (((g['progress'] as num?) ?? 0) / 100).toDouble(), minHeight: 10, backgroundColor: const Color(0xFFEDF1F6), color: Mw.green),
                  ),
                  const SizedBox(height: 4),
                  Row(children: [
                    Expanded(child: Text('${g['progress'] ?? 0}% of the way', style: const TextStyle(color: Mw.ink500, fontSize: 12))),
                    if (g['status'] == 'active')
                      TextButton(onPressed: () => _progress(g), child: const Text('Update my progress')),
                  ]),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _homework(List<Map<String, dynamic>> items) {
    final open = items.where((h) => h['status'] != 'done').length;
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Expanded(child: Text('Homework', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900))),
            Text(open > 0 ? '$open to do' : 'All done', style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
          ]),
          const SizedBox(height: 4),
          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('Nothing to do right now. When your therapist gives you something to try between sessions, it will appear here.', style: TextStyle(color: Mw.ink500, fontSize: 13)),
            ),
          for (final h in items)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(color: h['status'] == 'done' ? Mw.greenTint : Mw.orangeTint, borderRadius: BorderRadius.circular(11)),
                child: Icon(h['status'] == 'done' ? Icons.check_rounded : Icons.assignment_outlined, color: h['status'] == 'done' ? Mw.green : const Color(0xFFC25E00), size: 20),
              ),
              title: Text('${h['title']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: Mw.ink900)),
              subtitle: Text(
                h['status'] == 'done'
                    ? (h['reviewed'] == true ? 'Sent · reviewed' : 'Sent · waiting for your therapist')
                    : (h['overdue'] == true ? 'Past due' : (h['due_on'] != null ? 'Due ${fmtDay(DateTime.parse('${h['due_on']}'))}' : 'No due date')),
                style: TextStyle(color: h['overdue'] == true ? Mw.danger : Mw.ink500, fontSize: 12.5),
              ),
              trailing: const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
              onTap: () async {
                final sent = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => HomeworkScreen(homeworkId: '${h['id']}')));
                if (sent == true) reload();
              },
            ),
        ],
      ),
    );
  }
}
