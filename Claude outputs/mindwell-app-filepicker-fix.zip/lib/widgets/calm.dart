import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../theme.dart';
import 'common.dart';

/// The calm waiting look (2026-11-06), the same as the website's lobby and video waiting
/// room: the home page's soft panel with the swaying plant, circles that breathe
/// (4 s in, 6 s out), a "Breathe in / out" cue, and a few leaves drifting down.
/// Everything stands still when the phone asks for reduced motion.
class MwCalmHero extends StatefulWidget {
  const MwCalmHero({super.key, required this.child, this.leaves = true, this.breath = true});

  final Widget child;
  final bool leaves;
  final bool breath;

  @override
  State<MwCalmHero> createState() => _MwCalmHeroState();
}

class _MwCalmHeroState extends State<MwCalmHero> with SingleTickerProviderStateMixin {
  final _time = ValueNotifier<double>(1);
  final _cue = ValueNotifier<String>('Breathe in');
  Ticker? _ticker;
  bool _still = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _ticker ??= createTicker((elapsed) {
      final t = elapsed.inMicroseconds / 1e6;
      _time.value = t;
      final cue = (t % 10) / 10 < .4 ? 'Breathe in' : 'Breathe out';
      if (_cue.value != cue) _cue.value = cue;
    });
    _still = MediaQuery.of(context).disableAnimations;
    if (_still) {
      if (_ticker!.isActive) _ticker!.stop();
      _time.value = 1;
      _cue.value = 'Breathe slowly';
    } else if (!_ticker!.isActive) {
      _ticker!.start();
    }
  }

  @override
  void dispose() {
    _ticker?.dispose();
    _time.dispose();
    _cue.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(gradient: Mw.heroGradient, borderRadius: BorderRadius.circular(24)),
      child: Stack(
        children: [
          if (widget.leaves && !_still)
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              height: 190,
              child: IgnorePointer(child: CustomPaint(painter: _LeavesPainter(_time))),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: SizedBox(
                    width: 170,
                    height: 132,
                    child: ExcludeSemantics(child: CustomPaint(painter: _PlantPainter(_time, still: _still))),
                  ),
                ),
                if (widget.breath)
                  Center(
                    child: ValueListenableBuilder<String>(
                      valueListenable: _cue,
                      builder: (_, cue, __) => Text(cue, style: const TextStyle(color: Mw.teal, fontWeight: FontWeight.w700, fontSize: 13)),
                    ),
                  ),
                const SizedBox(height: 10),
                widget.child,
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Small green capital-letter label used above hero titles ("FINDING YOUR THERAPIST").
class MwKicker extends StatelessWidget {
  const MwKicker(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) => Text(
        text.toUpperCase(),
        style: const TextStyle(color: Mw.green, fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: .7),
      );
}

double _breath(double t) {
  final p = (t % 10) / 10;
  return p < .4 ? Curves.easeInOut.transform(p / .4) : 1 - Curves.easeInOut.transform((p - .4) / .6);
}

class _PlantPainter extends CustomPainter {
  _PlantPainter(this.time, {required this.still}) : super(repaint: time);

  final ValueNotifier<double> time;
  final bool still;

  static Paint _fill(int c) => Paint()..color = Color(c);
  static Paint _stroke(int c, double w) => Paint()
    ..color = Color(c)
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;

  @override
  void paint(Canvas canvas, Size size) {
    final t = still ? 1.0 : time.value;
    canvas.save();
    canvas.scale(size.width / 220, size.height / 170);

    final b1 = still ? .5 : _breath(t), b2 = still ? .5 : _breath(t + 1.5);
    canvas.drawOval(Rect.fromCenter(center: const Offset(96, 96), width: 148 * (.86 + .22 * b1), height: 120 * (.86 + .22 * b1)), _fill(0xFFD7E6F7));
    canvas.drawOval(Rect.fromCenter(center: const Offset(150, 74), width: 88 * (.86 + .22 * b2), height: 76 * (.86 + .22 * b2)), _fill(0xFFCDEFE2));
    canvas.drawCircle(const Offset(186, 24), 12, _fill(0xFFFFD29E));

    // Sway ±2° every 5 s around the foot of the stem.
    final sway = still ? 0.0 : math.sin(t / 5 * 2 * math.pi) * 2 * math.pi / 180;
    canvas.save();
    canvas.translate(110, 150);
    canvas.rotate(sway);
    canvas.translate(-110, -150);
    canvas.drawPath(Path()..moveTo(110, 152)..cubicTo(110, 120, 108, 98, 112, 70), _stroke(0xFF034C8F, 3.5));
    final l1 = Path()..moveTo(111, 104)..cubicTo(92, 104, 76, 94, 72, 74)..cubicTo(92, 72, 106, 84, 111, 104)..close();
    final l2 = Path()..moveTo(111, 88)..cubicTo(128, 86, 142, 74, 144, 54)..cubicTo(124, 54, 112, 68, 111, 88)..close();
    final l3 = Path()..moveTo(112, 70)..cubicTo(104, 58, 104, 44, 114, 34)..cubicTo(122, 46, 120, 60, 112, 70)..close();
    canvas.drawPath(l1, _fill(0xFF00B888));
    canvas.drawPath(l1, _stroke(0xFF00A87C, 2));
    canvas.drawPath(l2, _fill(0xFF34C79E));
    canvas.drawPath(l2, _stroke(0xFF00A87C, 2));
    canvas.drawPath(l3, _fill(0xFFF88000));
    canvas.drawPath(l3, _stroke(0xFFE07200, 2));
    canvas.restore();

    canvas.drawLine(const Offset(80, 154), const Offset(140, 154), _stroke(0x40034C8F, 3.5));
    canvas.restore();
  }

  @override
  bool shouldRepaint(_PlantPainter old) => old.still != still;
}

class _LeavesPainter extends CustomPainter {
  _LeavesPainter(this.time) : super(repaint: time);

  final ValueNotifier<double> time;

  static const _colours = [0xFF00B888, 0xFF34C79E, 0xFF00A87C, 0xFF34C79E, 0xFFF88000, 0xFF00B888, 0xFF7FD8BE];
  static final _leaf = Path()
    ..moveTo(4, 20)
    ..cubicTo(4, 10, 10, 4, 20, 4)
    ..cubicTo(20, 14, 14, 20, 4, 20)
    ..close();

  @override
  void paint(Canvas canvas, Size size) {
    final t = time.value;
    for (var i = 0; i < _colours.length; i++) {
      final dur = 13.0 + (i * 5) % 8;
      final p = ((t + i * 2.3) % dur) / dur;
      final s = 11.0 + (i * 7) % 9;
      final dir = i.isOdd ? -1.0 : 1.0;
      final x = size.width * (.04 + i * .135) + dir * 26 * math.sin(p * math.pi);
      final y = -30 + p * (size.height + 60);
      final alpha = p < .1 ? p / .1 * .8 : (p > .9 ? (1 - p) / .1 * .7 : .8);
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(dir * p * 5.2);
      canvas.scale(s / 24);
      canvas.translate(-12, -12);
      canvas.drawPath(_leaf, Paint()..color = Color(_colours[i]).withValues(alpha: alpha));
      canvas.drawLine(
        const Offset(5, 19),
        const Offset(15, 9),
        Paint()
          ..color = Colors.white.withValues(alpha: alpha * .6)
          ..strokeWidth = 1.2
          ..strokeCap = StrokeCap.round,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_LeavesPainter old) => false;
}

// ---- Connection check -------------------------------------------------------------------

enum NetQuality { checking, good, weak, off }

/// Judges the connection from how long our own status checks take (no extra data used):
/// the middle of the last three answers over 1.8 s is "weak", two failures in a row "off".
class MwNetWatch {
  final _times = <int>[];
  int _fails = 0;

  NetQuality get quality {
    if (_fails >= 2) return NetQuality.off;
    if (_times.isEmpty) return NetQuality.checking;
    final sorted = [..._times]..sort();
    return sorted[sorted.length ~/ 2] > 1800 ? NetQuality.weak : NetQuality.good;
  }

  /// Times [request] and records the result. Rethrows its errors.
  Future<T> time<T>(Future<T> Function() request, {bool Function(Object e)? isOffline}) async {
    final watch = Stopwatch()..start();
    try {
      final r = await request();
      _fails = 0;
      _times.add(watch.elapsedMilliseconds);
      if (_times.length > 3) _times.removeAt(0);
      return r;
    } catch (e) {
      if (isOffline == null || isOffline(e)) _fails++;
      rethrow;
    }
  }
}

/// The connection notice, in the app's Google-style banner.
class MwNetBanner extends StatelessWidget {
  const MwNetBanner({super.key, required this.quality, this.margin = EdgeInsets.zero});

  final NetQuality quality;
  final EdgeInsetsGeometry margin;

  @override
  Widget build(BuildContext context) {
    final (MwBannerKind kind, String title, String? text) = switch (quality) {
      NetQuality.checking => (MwBannerKind.info, 'Checking your connection…', null),
      NetQuality.good => (MwBannerKind.success, 'Your connection looks good', null),
      NetQuality.weak => (MwBannerKind.warning, 'Your connection is weak', 'Move to where your signal is strongest, or closer to your Wi-Fi. Pause any downloads.'),
      NetQuality.off => (MwBannerKind.error, "You're offline", "We'll keep your place. When you're back online, this screen carries on by itself."),
    };
    return MwBanner(kind: kind, title: title, text: text, margin: margin);
  }
}

// ---- Get-ready list and tips ------------------------------------------------------------

/// Tappable "get ready" items. Only for the client; nothing is saved.
class MwTickList extends StatefulWidget {
  const MwTickList({super.key, required this.items, this.onChanged});

  final List<String> items;
  final ValueChanged<int>? onChanged;

  @override
  State<MwTickList> createState() => _MwTickListState();
}

class _MwTickListState extends State<MwTickList> {
  final _on = <int>{};

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var i = 0; i < widget.items.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Semantics(
              button: true,
              checked: _on.contains(i),
              child: Material(
                color: _on.contains(i) ? Mw.greenTint : const Color(0xFFF7F9FC),
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () {
                    setState(() {
                      if (!_on.remove(i)) _on.add(i);
                    });
                    widget.onChanged?.call(_on.length);
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    child: Row(
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: _on.contains(i) ? const Color(0xFF00B888) : Colors.white,
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(color: _on.contains(i) ? const Color(0xFF00B888) : const Color(0xFFA3AFC0), width: 2),
                          ),
                          child: _on.contains(i) ? const Icon(Icons.check_rounded, size: 15, color: Colors.white) : null,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            widget.items[i],
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: _on.contains(i) ? Mw.ink900 : Mw.ink700),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// "While you wait": short practical tips (relax, connection, privacy), every 8 seconds.
class MwTipCard extends StatefulWidget {
  const MwTipCard({super.key});

  static const tips = [
    ('Relax', 'Take a slow breath in, and a longer breath out. There is no rush.'),
    ('Your connection', 'Stay where your signal is strongest. On Wi-Fi, sit close to the router.'),
    ('Privacy', 'Your session is private. Only you and your therapist will be there.'),
    ('Your connection', 'Pause downloads and close video apps so your call stays clear.'),
    ('Relax', 'Let your shoulders drop and rest your feet on the floor.'),
    ('Getting started', "You don't need to prepare anything. Start wherever feels easiest."),
    ('Your connection', 'Headphones help you hear clearly and keep the call private.'),
  ];

  @override
  State<MwTipCard> createState() => _MwTipCardState();
}

class _MwTipCardState extends State<MwTipCard> {
  int _i = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (mounted) setState(() => _i = (_i + 1) % MwTipCard.tips.length);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final (kind, text) = MwTipCard.tips[_i];
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const MwCardTitle('While you wait'),
          const SizedBox(height: 10),
          MwKicker(kind),
          const SizedBox(height: 6),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: SizedBox(
              key: ValueKey(_i),
              width: double.infinity,
              child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Mw.ink900, height: 1.45)),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              for (var d = 0; d < MwTipCard.tips.length; d++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.only(right: 5),
                  width: d == _i ? 16 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: d == _i ? Mw.teal : const Color(0x80A3AFC0),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              const Spacer(),
              TextButton(
                onPressed: () {
                  setState(() => _i = (_i + 1) % MwTipCard.tips.length);
                  _start();
                },
                child: const Text('Next tip'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Card heading, as on the website's cards (16, extra bold), with an optional right-hand note.
class MwCardTitle extends StatelessWidget {
  const MwCardTitle(this.text, {super.key, this.trailing});

  final String text;
  final String? trailing;

  @override
  Widget build(BuildContext context) => Row(
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Mw.ink900))),
          if (trailing != null)
            Text(trailing!, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: Mw.ink500, fontFeatures: [FontFeature.tabularFigures()])),
        ],
      );
}
