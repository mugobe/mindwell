import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import '../auth/change_password_screen.dart';
import '../intake/about_you_screen.dart';
import '../plans/employer_screen.dart';
import '../plans/payments_screen.dart';
import '../plans/plans_screen.dart';
import '../progress/progress_screen.dart';
import 'my_details_screen.dart';
import 'notifications_screen.dart';
import '../server_dialog.dart';
import '../urgent_help_screen.dart';

/// More: account, settings, plans and payments, help and legal, log out.
/// Stage 1: account header, change password, help, legal, server address, log out.
/// Stage 2: About you. Stage 3: My details, notifications, progress, plan, employer, payments.
class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  void _push(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final user = state.user ?? const {};
    final name = '${user['name'] ?? ''}';
    final legal = state.config?['legal'] as Map<String, dynamic>?;

    Widget tile(IconData icon, String title, VoidCallback onTap, {Color? color, Color? tint, String? subtitle}) => ListTile(
          leading: Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: tint ?? Mw.tealTint, borderRadius: BorderRadius.circular(11)),
            child: Icon(icon, color: color ?? Mw.teal, size: 20),
          ),
          title: Text(title, style: TextStyle(fontWeight: FontWeight.w700, color: color == Mw.danger ? Mw.danger : Mw.ink900)),
          subtitle: subtitle == null ? null : Text(subtitle),
          trailing: const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
          onTap: onTap,
        );

    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          MwFadeIn(
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(gradient: Mw.heroGradient, borderRadius: BorderRadius.circular(22)),
              child: Row(
                children: [
                  Avatar(name: name.isEmpty ? '?' : name, size: 56),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Mw.tealDark)),
                        const SizedBox(height: 2),
                        Text('${user['email'] ?? ''}', style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                        if (user['client_label'] != null)
                          Text('${user['client_label']}', style: const TextStyle(color: Mw.ink300, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SectionTitle('Account'),
          MwCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                tile(Icons.person_outline_rounded, 'My details', () => _push(context, const MyDetailsScreen())),
                tile(Icons.edit_note_rounded, 'About you', tint: Mw.orangeTint, color: Mw.orangeText,
                    () => _push(context, const AboutYouScreen()),
                    subtitle: 'What brings you here, goals, preferences'),
                tile(Icons.notifications_none_rounded, 'Notifications', () => _push(context, const NotificationsScreen())),
                tile(Icons.insights_rounded, 'My progress', () => _push(context, const ProgressScreen()), tint: Mw.purpleTint, color: Mw.purple),
                tile(Icons.lock_outline_rounded, 'Change password',
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChangePasswordScreen()))),
              ],
            ),
          ),
          const SectionTitle('Plans and payments'),
          MwCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                tile(Icons.workspace_premium_outlined, 'My plan', () => _push(context, const PlansScreen()), tint: Mw.greenTint, color: Mw.green),
                tile(Icons.business_outlined, 'Employer benefit', () => _push(context, const EmployerScreen())),
                tile(Icons.receipt_long_outlined, 'Payments and receipts', () => _push(context, const PaymentsScreen()), tint: Mw.orangeTint, color: Mw.orangeText),
              ],
            ),
          ),
          const SectionTitle('Help'),
          MwCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                tile(Icons.favorite_rounded, 'Get help now',
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen())), color: Mw.danger, tint: Mw.dangerTint),
                tile(Icons.description_outlined, 'Terms of Use', () => openLink(context, legal?['terms_url'] as String?)),
                tile(Icons.privacy_tip_outlined, 'Privacy Policy', () => openLink(context, legal?['privacy_url'] as String?)),
                if (kDebugMode) tile(Icons.dns_outlined, 'Server address', () => showServerDialog(context), subtitle: state.baseUrl),
              ],
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(foregroundColor: Mw.danger, side: const BorderSide(color: Mw.danger)),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Log out?'),
                  content: const Text('You will need your email and password to log in again.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Log out')),
                  ],
                ),
              );
              if (ok == true && context.mounted) context.read<AppState>().logout();
            },
            icon: const Icon(Icons.logout_rounded),
            label: const Text('Log out'),
          ),
          const SizedBox(height: 14),
          const Center(child: Text('Mindwell, version 1.0', style: TextStyle(color: Mw.ink300, fontSize: 12))),
        ],
      ),
    );
  }
}
