import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/reload_on_change.dart';
import '../progress/progress_screen.dart';
import 'journal_entry_screen.dart';

const Map<int, String> kMoodLabels = {1: 'Very low', 2: 'Low', 3: 'Okay', 4: 'Good', 5: 'Great'};

/// Journal tab (GET journal?page=) — daily mood + notes and notes from sessions. Private
/// unless an entry is shared with the therapist. Links to My progress.
class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> with ReloadOnChange<JournalScreen> {
  final List<Map<String, dynamic>> _entries = [];
  List<Map<String, dynamic>> _twoWeeks = const [];
  int _page = 0;
  bool _hasMore = false;
  bool _loading = false;
  bool _loadedOnce = false;
  ApiException? _error;

  @override
  void initState() {
    super.initState();
    reload();
  }

  @override
  Future<void> reload() => _fetch(reset: true);

  Future<void> _fetch({bool reset = false}) async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final next = reset ? 1 : _page + 1;
      final data = (await context.read<AppState>().api.get('journal', query: {'page': '$next'})) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        if (reset) _entries.clear();
        _entries.addAll(((data['entries'] as List?) ?? const []).cast<Map<String, dynamic>>());
        _twoWeeks = ((data['last_two_weeks'] as List?) ?? const []).cast<Map<String, dynamic>>();
        _page = next;
        _hasMore = data['has_more'] == true;
        _loadedOnce = true;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
      if (_loadedOnce) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _openEntry([Map<String, dynamic>? entry, int? mood]) async {
    final changed = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => JournalEntryScreen(entry: entry, initialMood: mood)));
    if (changed == true && mounted) context.read<AppState>().dataChanged();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My journal'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: TextButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProgressScreen())),
              icon: const Icon(Icons.insights_rounded),
              label: const Text('My progress'),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEntry(),
        backgroundColor: Mw.orange,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New entry'),
      ),
      body: !_loadedOnce && _error != null
          ? ErrorView(message: _error!.message, onRetry: reload)
          : !_loadedOnce
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: reload,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                    children: [
                      MwFadeIn(child: _checkInCard()),
                      MwFadeIn(index: 1, child: _moodStrip()),
                      const Padding(
                        padding: EdgeInsets.fromLTRB(2, 8, 2, 12),
                        child: Text('Your entries', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900)),
                      ),
                      if (_entries.isEmpty)
                        const EmptyState(
                          icon: Icons.book_outlined,
                          title: 'Your journal is empty',
                          text: 'Note how you feel each day. It only takes a moment and stays private unless you choose to share it.',
                        ),
                      for (final (i, e) in _entries.indexed) MwFadeIn(index: i + 2, child: _entryCard(e)),
                      if (_hasMore)
                        Center(
                          child: TextButton(onPressed: _loading ? null : () => _fetch(), child: Text(_loading ? 'Loading…' : 'Show older entries')),
                        ),
                    ],
                  ),
                ),
    );
  }

  Widget _checkInCard() => MwCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('How are you feeling today?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900)),
            const SizedBox(height: 3),
            const Text('Tap a face, then add a few words if you like.', style: TextStyle(color: Mw.ink500, fontSize: 13)),
            const SizedBox(height: 12),
            MwMoodPicker(onPick: (m) => _openEntry(null, m)),
          ],
        ),
      );

  Widget _moodStrip() {
    final byDate = {for (final d in _twoWeeks) '${d['date']}': (d['mood'] as num?)?.toInt()};
    final today = DateTime.now();
    final days = List.generate(14, (i) => DateTime(today.year, today.month, today.day).subtract(Duration(days: 13 - i)));
    String key(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    final logged = byDate.values.whereType<int>().toList();
    final still = MediaQuery.of(context).disableAnimations;

    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Your last two weeks', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900)),
          if (logged.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 3),
              child: Text('Your moods will show here as you check in.', style: TextStyle(color: Mw.ink500, fontSize: 13)),
            ),
          const SizedBox(height: 14),
          SizedBox(
            height: 96,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final (i, d) in days.indexed)
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TweenAnimationBuilder<double>(
                          tween: Tween(begin: still ? 1 : 0, end: 1),
                          duration: Duration(milliseconds: 500 + i * 30),
                          curve: Curves.easeOutCubic,
                          builder: (context, t, _) {
                            final m = byDate[key(d)];
                            return Container(
                              width: 12,
                              height: (m == null ? 6 : 14 + m * 12) * t,
                              decoration: BoxDecoration(
                                color: m == null ? Mw.line : Mw.moodFaces[m],
                                borderRadius: BorderRadius.circular(6),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 5),
                        Text(weekdayShort(d).substring(0, 1), style: const TextStyle(color: Mw.ink300, fontSize: 10.5, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          if (logged.isNotEmpty) ...[
            const Divider(height: 26),
            Row(
              children: [
                Text('${logged.length}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Mw.ink900)),
                const SizedBox(width: 6),
                Text(logged.length == 1 ? 'day checked in' : 'days checked in', style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                const Spacer(),
                MwFace(mood: (logged.reduce((a, b) => a + b) / logged.length).round().clamp(1, 5), size: 30),
                const SizedBox(width: 8),
                Text(MwMoodPicker.labels[(logged.reduce((a, b) => a + b) / logged.length).round().clamp(1, 5)] ?? '',
                    style: const TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900)),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _entryCard(Map<String, dynamic> e) {
    final at = parseDate(e['created_at']);
    final mood = (e['mood'] as num?)?.toInt();
    final session = e['session'] as Map?;
    final body = '${e['body'] ?? ''}'.trim();
    final shared = e['shared_with_therapist'] == true;

    return MwCard(
      onTap: () => _openEntry(e),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          mood != null
              ? MwFace(mood: mood, size: 40)
              : Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(color: Mw.tealTint, borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.videocam_outlined, color: Mw.teal, size: 21),
                ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  session != null
                      ? 'Notes from your session with ${session['therapist_name'] ?? 'your therapist'}'
                      : 'Feeling ${(e['mood_label'] ?? kMoodLabels[mood] ?? 'okay').toString().toLowerCase()}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: Mw.ink900),
                ),
                if (at != null) ...[
                  const SizedBox(height: 2),
                  Text('${fmtRelativeDay(at)} at ${fmtTime(at)}', style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
                ],
                if (body.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(body, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Mw.ink700, height: 1.45)),
                ],
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: shared ? Mw.greenTint : const Color(0xFFF0F3F7), borderRadius: BorderRadius.circular(999)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(shared ? Icons.people_alt_outlined : Icons.lock_outline_rounded, size: 14, color: shared ? Mw.green : Mw.ink500),
                      const SizedBox(width: 5),
                      Text(shared ? 'Shared with your therapist' : 'Private',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: shared ? Mw.green : Mw.ink500)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
