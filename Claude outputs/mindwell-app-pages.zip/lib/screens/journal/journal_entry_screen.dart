import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';

/// New journal entry (POST journal: mood + optional note + share), or an existing one
/// (PATCH journal/{id}: the note and the share switch — the mood of a saved day stays as
/// it was; DELETE to remove). Pops with true when something changed.
class JournalEntryScreen extends StatefulWidget {
  const JournalEntryScreen({super.key, this.entry, this.initialMood});

  final Map<String, dynamic>? entry;

  /// Face already tapped on the journal or home screen (new entries only).
  final int? initialMood;

  @override
  State<JournalEntryScreen> createState() => _JournalEntryScreenState();
}

class _JournalEntryScreenState extends State<JournalEntryScreen> {
  late final TextEditingController _body = TextEditingController(text: '${widget.entry?['body'] ?? ''}');
  late int? _mood = (widget.entry?['mood'] as num?)?.toInt() ?? widget.initialMood;
  late bool _shared = widget.entry?['shared_with_therapist'] == true;
  bool _busy = false;
  String? _error;

  bool get _isNew => widget.entry == null;

  @override
  void dispose() {
    _body.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_isNew && _mood == null) {
      setState(() => _error = 'Pick how you feel today.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final api = context.read<AppState>().api;
    try {
      if (_isNew) {
        await api.post('journal', {
          'mood': _mood,
          'body': _body.text.trim().isEmpty ? null : _body.text.trim(),
          'shared_with_therapist': _shared,
        });
      } else {
        await api.patch('journal/${widget.entry!['id']}', {
          'body': _body.text.trim().isEmpty ? null : _body.text.trim(),
          'shared_with_therapist': _shared,
        });
      }
      if (!mounted) return;
      Navigator.pop(context, true);
      showSnack(context, 'Saved to your journal.');
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.errors.isNotEmpty ? e.errors.values.first.first : e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    final ok = await confirmDialog(context, title: 'Delete this entry?', body: "This can't be undone.", yes: 'Delete', danger: true);
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    try {
      await context.read<AppState>().api.delete('journal/${widget.entry!['id']}');
      if (!mounted) return;
      Navigator.pop(context, true);
      showSnack(context, 'Entry deleted.');
    } on ApiException catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showSnack(context, e.message, error: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final at = parseDate(widget.entry?['created_at']);
    final session = widget.entry?['session'] as Map?;

    return Scaffold(
      appBar: AppBar(
        title: Text(_isNew ? 'New entry' : (at != null ? fmtDayLong(at) : 'Entry')),
        actions: [
          if (!_isNew)
            IconButton(onPressed: _busy ? null : _delete, icon: const Icon(Icons.delete_outline_rounded, color: Mw.danger), tooltip: 'Delete'),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          if (session != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text('Notes from your session with ${session['therapist_name'] ?? 'your therapist'}',
                  style: const TextStyle(color: Mw.ink500, fontWeight: FontWeight.w700)),
            ),
          if (_isNew || _mood != null) ...[
            Text(_isNew ? 'How are you feeling?' : 'How you felt',
                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Mw.ink900)),
            const SizedBox(height: 10),
            MwMoodPicker(selected: _mood, onPick: _isNew ? (m) => setState(() => _mood = m) : null),
            const SizedBox(height: 18),
          ],
          TextField(
            controller: _body,
            minLines: 6,
            maxLines: 14,
            maxLength: _isNew ? 5000 : 20000,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(hintText: 'What is on your mind? (optional)'),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _shared,
            onChanged: (v) => setState(() => _shared = v),
            title: const Text('Share with my therapist', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('When this is off, only you can read it.'),
          ),
          if (_error != null) NoticeBox(text: _error!),
          PrimaryButton(label: 'Save', busy: _busy, onPressed: _save),
        ],
      ),
    );
  }
}
