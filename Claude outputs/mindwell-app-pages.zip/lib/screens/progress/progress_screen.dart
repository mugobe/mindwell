import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import 'check_in_screen.dart';

/// My progress (GET progress). Same gentle wording as the website: plain words and the
/// direction since last time — never raw scores. The chart uses the API's 0–1 levels.
class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  bool _savingShare = false;

  static const _worryColor = Mw.orange; // same as the website chart

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('progress')) as Map<String, dynamic>;
      if (mounted) setState(() => _data = data);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  Future<void> _share(bool v) async {
    setState(() => _savingShare = true);
    try {
      final res = (await context.read<AppState>().api.put('progress/share-mood', {'share': v})) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _data = {...?_data, 'share_mood_with_therapist': res['share_mood_with_therapist'] == true});
      showSnack(context, '${res['message'] ?? 'Saved.'}');
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _savingShare = false);
    }
  }

  Future<void> _checkIn() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckInScreen()));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final d = _data;
    return Scaffold(
      appBar: AppBar(title: const Text('My progress')),
      body: _error != null && d == null
          ? ErrorView(message: _error!.message, onRetry: _load)
          : d == null
              ? const LoadingView()
              : RefreshIndicator(onRefresh: _load, child: _body(d)),
    );
  }

  Widget _body(Map<String, dynamic> d) {
    final points = ((d['points'] as List?) ?? const []).cast<Map<String, dynamic>>();
    final summary = d['summary'] as Map<String, dynamic>?;
    final checkIn = (d['check_in'] as Map?) ?? const {};

    var n = 0;
    Widget fade(Widget w) => MwFadeIn(index: n++, child: w);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        fade(_checkInCard(checkIn)),
        if (summary == null)
          const MwCard(
            child: Text('Your progress appears here after your first assessment and check-ins.',
                style: TextStyle(color: Mw.ink500, height: 1.4)),
          )
        else ...[
          fade(IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(child: _summaryTile('Low mood', summary['low_mood'] as Map?, Mw.teal)),
                const SizedBox(width: 10),
                Expanded(child: _summaryTile('Worry', summary['worry'] as Map?, _worryColor)),
              ],
            ),
          )),
          if (points.length >= 2)
            fade(MwCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('How things have changed', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900)),
                  const SizedBox(height: 2),
                  const Text('Lower is better.', style: TextStyle(color: Mw.ink500, fontSize: 12.5)),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 150,
                    width: double.infinity,
                    // The lines draw themselves in from left to right.
                    child: TweenAnimationBuilder<double>(
                      tween: Tween(begin: MediaQuery.of(context).disableAnimations ? 1 : 0, end: 1),
                      duration: const Duration(milliseconds: 900),
                      curve: Curves.easeOutCubic,
                      builder: (context, t, _) => CustomPaint(painter: _TrendPainter(points, t)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_pointDate(points.first), style: const TextStyle(color: Mw.ink300, fontSize: 11.5)),
                      Text(_pointDate(points.last), style: const TextStyle(color: Mw.ink300, fontSize: 11.5)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Row(
                    children: [
                      _Legend(color: Mw.teal, label: 'Low mood'),
                      SizedBox(width: 16),
                      _Legend(color: _worryColor, label: 'Worry'),
                    ],
                  ),
                ],
              ),
            )),
        ],
        fade(_moodCard(((d['moods'] as List?) ?? const []).cast<Map<String, dynamic>>())),
        MwCard(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: SwitchListTile(
            value: d['share_mood_with_therapist'] == true,
            onChanged: _savingShare ? null : _share,
            title: const Text('Let my therapist see my mood chart', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Only the coloured dots, never what you write.'),
          ),
        ),
      ],
    );
  }

  String _pointDate(Map<String, dynamic> p) {
    final at = parseDate(p['at']);
    return at == null ? '' : fmtDate(at);
  }

  Widget _checkInCard(Map checkIn) {
    final availableAt = parseDate(checkIn['available_at']);
    if (checkIn['eligible'] != true) return const SizedBox.shrink();

    if (checkIn['available'] == true) {
      return MwBanner(
        kind: MwBannerKind.event,
        title: checkIn['due'] == true ? 'Time for your check-in' : 'Your check-in is open',
        text: 'It takes about 3 minutes and helps you and your therapist see how things are changing.',
        actions: [MwPillButton(label: 'Start check-in', filled: true, onPressed: _checkIn)],
      );
    }

    return MwCard(
      child: Row(
        children: [
          const Icon(Icons.event_repeat_rounded, color: Mw.teal),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              availableAt != null ? 'Your next check-in opens on ${fmtDayLong(availableAt)}.' : 'Your next check-in opens soon.',
              style: const TextStyle(color: Mw.ink700, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryTile(String title, Map? s, Color color) {
    final dir = s?['since_last'];
    final (IconData icon, String text, Color bg, Color fg) = switch (dir) {
      'lower' => (Icons.south_rounded, 'Lower than last time', Mw.greenTint, Mw.green),
      'higher' => (Icons.north_rounded, 'A little higher', Mw.orangeTint, Mw.orangeText),
      'same' => (Icons.trending_flat_rounded, 'About the same', const Color(0xFFF0F3F7), Mw.ink500),
      _ => (Icons.flag_outlined, 'Your starting point', const Color(0xFFF0F3F7), Mw.ink500),
    };
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 9, height: 9, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
              const SizedBox(width: 7),
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Mw.ink500)),
            ],
          ),
          const SizedBox(height: 8),
          Text(_cap('${s?['now'] ?? 'Not yet'}'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Mw.ink900)),
          const Spacer(),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 13, color: fg),
                const SizedBox(width: 4),
                Flexible(child: Text(text, style: TextStyle(color: fg, fontSize: 11.5, fontWeight: FontWeight.w800))),
              ],
            ),
          ),
          if (s?['at_start'] != null) ...[
            const SizedBox(height: 6),
            Text('At the start: ${s!['at_start']}', style: const TextStyle(color: Mw.ink300, fontSize: 11.5)),
          ],
        ],
      ),
    );
  }

  Widget _moodCard(List<Map<String, dynamic>> moods) {
    if (moods.isEmpty) return const SizedBox.shrink();
    final recent = moods.length > 30 ? moods.sublist(moods.length - 30) : moods;
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Daily mood', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Mw.ink900)),
          const SizedBox(height: 2),
          Text('The last ${recent.length} ${recent.length == 1 ? 'day' : 'days'} you noted it. Higher is better.',
              style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
          const SizedBox(height: 14),
          SizedBox(
            height: 80,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final m in recent)
                  Expanded(
                    child: Tooltip(
                      message: '${m['date']}',
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 1.5),
                        height: 10.0 + 13 * (((m['mood'] as num?)?.toInt() ?? 1).clamp(1, 5)),
                        decoration: BoxDecoration(
                          color: Mw.moodFaces[(m['mood'] as num?)?.toInt()] ?? Mw.line,
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  String _cap(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}

class _Legend extends StatelessWidget {
  const _Legend({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 14, height: 3, color: color),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: Mw.ink500, fontSize: 12)),
        ],
      );
}

/// Two lines (low mood, worry) across the assessments; level 0 is at the bottom.
class _TrendPainter extends CustomPainter {
  _TrendPainter(this.points, [this.t = 1]);

  final List<Map<String, dynamic>> points;

  /// How much of each line is drawn (0 to 1), for the draw-in animation.
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = Mw.line
      ..strokeWidth = 1;
    for (var i = 0; i <= 2; i++) {
      final y = size.height * i / 2;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    _line(canvas, size, 'mood_level', Mw.teal);
    _line(canvas, size, 'worry_level', Mw.orange);
  }

  void _line(Canvas canvas, Size size, String key, Color color) {
    if (points.length < 2) return;
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.6
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final dot = Paint()..color = color;
    final path = Path();
    for (var i = 0; i < points.length; i++) {
      final level = ((points[i][key] as num?) ?? 0).toDouble().clamp(0.0, 1.0);
      final x = size.width * i / (points.length - 1);
      final y = size.height * (1 - level);
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
      if (x <= size.width * t + 0.5) canvas.drawCircle(Offset(x, y), 4, dot);
    }
    if (t >= 1) {
      canvas.drawPath(path, paint);
    } else {
      for (final m in path.computeMetrics()) {
        canvas.drawPath(m.extractPath(0, m.length * t), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TrendPainter old) => old.points != points || old.t != t;
}
