import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';

/// Payments & receipts (GET payments?page=). A receipt opens as a PDF in the phone's
/// browser through a 10-minute signed link (GET payments/{id}/receipt-link).
class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final List<Map<String, dynamic>> _items = [];
  int _page = 0;
  bool _hasMore = true;
  bool _loading = false;
  ApiException? _error;
  num _paidThisYear = 0;
  String _currency = 'UGX';
  String? _opening;

  @override
  void initState() {
    super.initState();
    _more(reset: true);
  }

  Future<void> _more({bool reset = false}) async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final next = reset ? 1 : _page + 1;
      final data = (await context.read<AppState>().api.get('payments', query: {'page': '$next'})) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        if (reset) _items.clear();
        _items.addAll(((data['payments'] as List?) ?? const []).cast<Map<String, dynamic>>());
        _page = next;
        _hasMore = data['has_more'] == true;
        _paidThisYear = (data['paid_this_year'] as num?) ?? 0;
        _currency = '${data['currency'] ?? 'UGX'}';
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
      if (_items.isNotEmpty) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _receipt(Map<String, dynamic> p) async {
    setState(() => _opening = '${p['id']}');
    try {
      final res = (await context.read<AppState>().api.get('payments/${p['id']}/receipt-link')) as Map<String, dynamic>;
      if (mounted) await openLink(context, res['url'] as String?);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _opening = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payments and receipts')),
      body: _error != null && _items.isEmpty
          ? ErrorView(message: _error!.message, onRetry: () => _more(reset: true))
          : _items.isEmpty && _loading
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: () => _more(reset: true),
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                    children: [
                      MwFadeIn(
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 18),
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFF022F5C), Color(0xFF034C8F), Color(0xFF0B5FB0)],
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('PAID IN ${DateTime.now().year}',
                                  style: const TextStyle(color: Colors.white70, fontSize: 11.5, fontWeight: FontWeight.w800, letterSpacing: .8)),
                              const SizedBox(height: 6),
                              Text(money(_paidThisYear, _currency),
                                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: -.4)),
                              const SizedBox(height: 6),
                              const Text('Tap a paid item to open its receipt.', style: TextStyle(color: Color(0xFFDCE8F5), fontSize: 12.5)),
                            ],
                          ),
                        ),
                      ),
                      if (_items.isEmpty)
                        const EmptyState(icon: Icons.receipt_long_outlined, title: 'No payments yet'),
                      for (final (i, p) in _items.indexed) MwFadeIn(index: i + 1, child: _tile(p)),
                      if (_hasMore && _items.isNotEmpty)
                        Center(
                          child: TextButton(
                            onPressed: _loading ? null : () => _more(),
                            child: Text(_loading ? 'Loading…' : 'Show more'),
                          ),
                        ),
                    ],
                  ),
                ),
    );
  }

  Widget _tile(Map<String, dynamic> p) {
    final at = parseDate(p['paid_at']) ?? parseDate(p['created_at']);
    final status = '${p['status']}';
    final ok = status == 'successful';
    final refunded = (p['refunded'] as num?) ?? 0;
    final pill = switch (status) {
      'successful' => refunded > 0 ? const Pill('Refunded', color: Mw.ink500, background: Mw.canvas) : const Pill('Paid'),
      'pending' => const Pill('Waiting', color: Mw.orangeText, background: Mw.orangeTint),
      _ => const Pill('Not completed', color: Mw.danger, background: Mw.dangerTint),
    };

    final (IconData icon, Color bg, Color fg) = switch (status) {
      'successful' => refunded > 0 ? (Icons.undo_rounded, Mw.orangeTint, Mw.orangeText) : (Icons.check_rounded, Mw.greenTint, Mw.green),
      'pending' => (Icons.schedule_rounded, Mw.orangeTint, Mw.orangeText),
      _ => (Icons.close_rounded, Mw.dangerTint, Mw.danger),
    };

    return MwCard(
      onTap: ok && p['has_receipt'] == true ? () => _receipt(p) : null,
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(13)),
            child: Icon(icon, color: fg, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${p['description'] ?? p['kind'] ?? 'Payment'}',
                    style: const TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900)),
                const SizedBox(height: 2),
                Text(
                  [if (at != null) fmtDate(at), if (p['method'] != null) '${p['method']}'].join(', '),
                  style: const TextStyle(color: Mw.ink500, fontSize: 12.5),
                ),
                const SizedBox(height: 6),
                pill,
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(money(p['amount'], '${p['currency'] ?? _currency}'),
                  style: const TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
              if (ok && p['has_receipt'] == true) ...[
                const SizedBox(height: 6),
                _opening == '${p['id']}'
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.picture_as_pdf_outlined, size: 16, color: Mw.teal),
                          SizedBox(width: 4),
                          Text('Receipt', style: TextStyle(color: Mw.teal, fontWeight: FontWeight.w800, fontSize: 12.5)),
                        ],
                      ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
