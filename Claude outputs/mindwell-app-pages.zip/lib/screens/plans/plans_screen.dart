import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import 'employer_screen.dart';
import 'plan_checkout_screen.dart';

/// "a week" / "a month" for a plan's billing interval.
String intervalText(dynamic interval) => switch ('$interval') {
      'weekly' => 'a week',
      'monthly' => 'a month',
      final other => 'per ${other.replaceAll('ly', '')}',
    };

/// My plan (GET plans): the current plan and its sessions left, renewing, and every plan
/// on offer — same as the website's Plans page.
class PlansScreen extends StatefulWidget {
  const PlansScreen({super.key});

  @override
  State<PlansScreen> createState() => _PlansScreenState();
}

class _PlansScreenState extends State<PlansScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('plans')) as Map<String, dynamic>;
      if (mounted) setState(() => _data = data);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My plan')),
      body: _error != null && _data == null
          ? ErrorView(message: _error!.message, onRetry: _load)
          : _data == null
              ? const LoadingView()
              : RefreshIndicator(onRefresh: _load, child: _body(_data!)),
    );
  }

  Widget _body(Map<String, dynamic> d) {
    final current = d['current'] as Map<String, dynamic>?;
    final currency = '${d['currency'] ?? 'UGX'}';
    final plans = ((d['plans'] as List?) ?? const []).cast<Map<String, dynamic>>();
    final currentPlanId = (current?['plan'] as Map?)?['id'];

    const tints = [
      (Color(0xFFFFEBD6), Color(0xFFC25E00)),
      (Mw.greenTint, Mw.green),
      (Mw.tealTint, Mw.teal),
    ];
    var n = 0;
    Widget fade(Widget w) => MwFadeIn(index: n++, child: w);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        fade(current != null ? _currentCard(current, d['total_credits']) : _noPlanCard(d['recently_ended'] as Map<String, dynamic>?)),
        fade(MwCard(
          onTap: () => _open(const EmployerScreen()),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: Mw.tealTint, borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.business_rounded, color: Mw.teal, size: 21),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Employer benefit', style: TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900)),
                    SizedBox(height: 2),
                    Text('Covered by your employer? Enter your company code.', style: TextStyle(color: Mw.ink500, fontSize: 12.5)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
            ],
          ),
        )),
        Padding(
          padding: const EdgeInsets.fromLTRB(2, 8, 2, 12),
          child: Text(current == null ? 'Choose a plan' : 'Switch plans',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900)),
        ),
        if (plans.isEmpty) const Text('No plans are on offer right now.', style: TextStyle(color: Mw.ink500)),
        for (final (i, p) in plans.indexed)
          fade(MwCard(
            borderColor: p['id'] == currentPlanId ? Mw.teal : null,
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: tints[i % 3].$1, borderRadius: BorderRadius.circular(13)),
                      child: Icon(Icons.layers_outlined, color: tints[i % 3].$2, size: 21),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text('${p['name']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900)),
                    ),
                    if (p['id'] == currentPlanId)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: Mw.teal, borderRadius: BorderRadius.circular(999)),
                        child: const Text('Your plan', style: TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w800)),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Text.rich(TextSpan(children: [
                  TextSpan(text: money(p['price'], currency), style: const TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900, fontSize: 24, letterSpacing: -.4)),
                  TextSpan(text: '  ${intervalText(p['billing_interval'])}'),
                ]), style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                const SizedBox(height: 8),
                for (final f in ['${p['sessions_included']} ${p['sessions_included'] == 1 ? 'session' : 'sessions'} included', ...((p['features'] as List?) ?? const [])])
                  Padding(
                    padding: const EdgeInsets.only(top: 7),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.check_rounded, size: 18, color: Mw.green),
                        const SizedBox(width: 8),
                        Expanded(child: Text('$f', style: const TextStyle(color: Mw.ink700, height: 1.35))),
                      ],
                    ),
                  ),
                if (p['id'] != currentPlanId) ...[
                  const SizedBox(height: 16),
                  current == null
                      ? PrimaryButton(label: 'Choose this plan', color: Mw.orange, onPressed: () => _open(PlanCheckoutScreen.subscribe(planId: '${p['id']}')))
                      : SizedBox(
                          width: double.infinity,
                          child: OutlinedButton(
                            onPressed: () => _open(PlanCheckoutScreen.subscribe(planId: '${p['id']}')),
                            child: const Text('Switch to this plan'),
                          ),
                        ),
                ],
              ],
            ),
          )),
      ],
    );
  }

  Widget _currentCard(Map<String, dynamic> s, dynamic totalCredits) {
    final plan = (s['plan'] as Map?) ?? const {};
    final end = DateTime.tryParse('${s['period_end'] ?? ''}');
    final lastDay = DateTime.tryParse('${s['last_usable_day'] ?? ''}');
    final phase = s['phase'];
    final left = (totalCredits ?? s['sessions_remaining'] ?? 0) as num;

    final String note = switch (phase) {
      'renewed' => 'Renewed. Your next period starts${end != null ? ' on ${fmtDayLong(end)}' : ''}.',
      'ending_soon' => 'Ends${end != null ? ' on ${fmtDayLong(end)}' : ' soon'}. Renew to keep your sessions going.',
      'grace' => 'Your renewal date has passed. You can still use it${lastDay != null ? ' until ${fmtDayLong(lastDay)}' : ' for a few days'}. Renew to continue.',
      _ => end != null ? 'Renews on ${fmtDayLong(end)}.' : '',
    };

    final included = ((plan['sessions_included'] as num?) ?? 0).toDouble();
    final share = included > 0 ? (left / included).clamp(0.0, 1.0).toDouble() : (left > 0 ? 1.0 : 0.0);

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF022F5C), Color(0xFF034C8F), Color(0xFF0B5FB0)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _CreditsRing(left: left.toInt(), share: share),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(phase == 'grace' ? 'DUE FOR RENEWAL' : 'YOUR PLAN',
                        style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: Colors.white70, letterSpacing: .8)),
                    const SizedBox(height: 4),
                    Text('${plan['name'] ?? 'Plan'}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white, height: 1.2)),
                  ],
                ),
              ),
            ],
          ),
          if (note.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text(note, style: const TextStyle(color: Color(0xFFDCE8F5), height: 1.45)),
          ],
          if (s['can_renew'] == true) ...[
            const SizedBox(height: 14),
            PrimaryButton(label: 'Renew now', color: Mw.orange, onPressed: () => _open(const PlanCheckoutScreen.renew())),
          ],
        ],
      ),
    );
  }

  Widget _noPlanCard(Map<String, dynamic>? ended) {
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(ended != null ? 'Your ${ended['name']} plan has ended' : "You're paying per session",
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Mw.ink900)),
          const SizedBox(height: 4),
          const Text('A plan gives you a set number of sessions each period, usually for less than paying one at a time.',
              style: TextStyle(color: Mw.ink500, height: 1.4)),
        ],
      ),
    );
  }
}

/// White ring showing credits left out of the plan's credits per period. Fills in on open.
class _CreditsRing extends StatelessWidget {
  const _CreditsRing({required this.left, required this.share});

  final int left;
  final double share;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 92,
      height: 92,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: MediaQuery.of(context).disableAnimations ? share : 0, end: share),
        duration: const Duration(milliseconds: 1000),
        curve: Curves.easeOutCubic,
        builder: (context, t, _) => CustomPaint(
          painter: _RingPainter(t),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('$left', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800, height: 1)),
                const SizedBox(height: 3),
                Text(left == 1 ? 'credit left' : 'credits left', style: const TextStyle(color: Colors.white70, fontSize: 10.5, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter(this.t);

  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final stroke = size.width * .09;
    final r = rect.deflate(stroke / 2);
    canvas.drawArc(r, 0, 6.2832, false, Paint()
      ..color = Colors.white.withValues(alpha: .18)
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke);
    if (t > 0) {
      canvas.drawArc(r, -1.5708, 6.2832 * t, false, Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = stroke);
    }
  }

  @override
  bool shouldRepaint(_RingPainter old) => old.t != t;
}
