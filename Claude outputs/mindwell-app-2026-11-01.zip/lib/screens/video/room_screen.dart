import 'dart:async';

import 'package:flutter/material.dart';
import 'package:livekit_client/livekit_client.dart' as lk;
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/rate_sheet.dart';

/// The video room — the app's version of the website's sessions/room page, using the
/// same LiveKit server and the same rules (VideoRoomController):
///  - Before joining: GET sessions/{id}/room every 5s. The client may join from a few
///    minutes before the start, or earlier as soon as the therapist is in the room.
///  - Join: POST room/token → {url, token} → connect. A token is only ever asked for
///    at the moment of joining. Nothing is recorded.
///  - While connected: POST room/presence every 15s (so the therapist sees "in the
///    room"); leaving=1 on the way out.
///  - Notepad: POST room/notes (autosaves to the client's private journal; optional
///    "share with my therapist").
class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key, required this.sessionId});

  final String sessionId;

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

enum _Phase { checking, waiting, ready, connecting, inCall, left, unavailable }

class _RoomScreenState extends State<RoomScreen> {
  late final ApiClient _api;
  late final AppState _app;

  _Phase _phase = _Phase.checking;
  Map<String, dynamic> _info = const {};
  String? _message;

  Timer? _statusTimer;
  Timer? _presenceTimer;
  Timer? _clockTimer;

  lk.Room? _room;
  lk.EventsListener<lk.RoomEvent>? _listener;
  bool _camOn = true;
  bool _micOn = true;
  bool _front = true;
  bool _leaving = false;
  bool _controlsBusy = false;

  // Notepad
  final _notes = TextEditingController();
  bool _notesShared = false;
  bool _notesLoaded = false;
  bool _notesDirty = false;
  Timer? _notesDebounce;
  final _notesStatus = ValueNotifier<String>('');

  String get _base => 'sessions/${widget.sessionId}';
  String get _therapistName => '${_info['therapist_name'] ?? 'Your therapist'}';

  @override
  void initState() {
    super.initState();
    _app = context.read<AppState>();
    _api = _app.api;
    _checkRoom();
    _statusTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkRoom());
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted && _phase == _Phase.inCall) setState(() {});
    });
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    _presenceTimer?.cancel();
    _clockTimer?.cancel();
    _notesDebounce?.cancel();
    if (_room != null) {
      // Closed without tapping Leave (e.g. the app was sent away): still tidy up.
      _api.post('$_base/room/presence', {'leaving': 1}).catchError((_) => null);
      _teardown();
    }
    _notes.dispose();
    _notesStatus.dispose();
    super.dispose();
  }

  // ---- before joining -----------------------------------------------------------

  Future<void> _checkRoom() async {
    if (_phase == _Phase.connecting || _phase == _Phase.inCall || _phase == _Phase.left) return;
    try {
      final res = (await _api.get('$_base/room')) as Map<String, dynamic>;
      if (!mounted || _phase == _Phase.connecting || _phase == _Phase.inCall || _phase == _Phase.left) return;
      final notes = res['notes'] as Map?;
      if (!_notesLoaded && notes != null) {
        _notes.text = '${notes['body'] ?? ''}';
        _notesShared = notes['shared'] == true;
        _notesLoaded = true;
      }
      setState(() {
        _info = res;
        switch (res['state']) {
          case 'open':
            _phase = _Phase.ready;
            break;
          case 'too_early':
            _phase = _Phase.waiting;
            break;
          case 'ended':
            _phase = _Phase.unavailable;
            _message = "This session's video window has ended.";
            _statusTimer?.cancel();
            break;
          default:
            _phase = _Phase.unavailable;
            _message = 'This session is no longer open for video.';
            _statusTimer?.cancel();
        }
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      if (e.status == 409 || e.status == 403 || e.status == 404) {
        _statusTimer?.cancel();
        setState(() {
          _phase = _Phase.unavailable;
          _message = e.message;
        });
      } else if (_phase == _Phase.checking) {
        setState(() => _message = e.message);
      }
    }
  }

  // ---- joining ----------------------------------------------------------------------

  Future<void> _join() async {
    setState(() {
      _phase = _Phase.connecting;
      _message = null;
    });

    // Permissions first, with a clear reason if the microphone is refused.
    final wanted = <Permission>[Permission.microphone, if (_camOn) Permission.camera];
    final statuses = await wanted.request();
    if (!mounted) return;
    if (statuses[Permission.microphone]?.isGranted != true) {
      setState(() => _phase = _Phase.ready);
      _permissionHelp('microphone');
      return;
    }
    if (_camOn && statuses[Permission.camera]?.isGranted != true) {
      _camOn = false;
      showSnack(context, 'Joining without video because the camera was not allowed.');
    }

    Map<String, dynamic> creds;
    try {
      creds = (await _api.post('$_base/room/token')) as Map<String, dynamic>;
      if (!mounted) return;
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _phase = e.status == 503 ? _Phase.unavailable : _Phase.ready;
        _message = e.message;
      });
      if (e.status == 409) _checkRoom();
      return;
    }

    final room = lk.Room(roomOptions: const lk.RoomOptions(adaptiveStream: true, dynacast: true));
    final listener = room.createListener();
    listener.on<lk.RoomDisconnectedEvent>((_) => _onDisconnected());
    room.addListener(_onRoomChanged);

    try {
      await room.connect('${creds['url']}', '${creds['token']}');
    } catch (e) {
      room.removeListener(_onRoomChanged);
      await listener.dispose();
      await room.dispose();
      if (!mounted) return;
      setState(() {
        _phase = _Phase.ready;
        _message = "Couldn't connect to the video room. Check your internet and try again.";
      });
      return;
    }

    if (!mounted) {
      // The person left while we were connecting — don't leave a call running.
      room.removeListener(_onRoomChanged);
      await listener.dispose();
      await room.disconnect();
      await room.dispose();
      return;
    }

    _room = room;
    _listener = listener;
    _leaving = false;

    try {
      await room.localParticipant?.setMicrophoneEnabled(_micOn);
    } catch (_) {
      _micOn = false;
    }
    try {
      await room.localParticipant?.setCameraEnabled(_camOn);
    } catch (_) {
      _camOn = false;
    }
    try {
      await lk.Hardware.instance.setSpeakerphoneOn(true);
    } catch (_) {
      // Earpiece is fine too; headphones take over anyway.
    }
    if (!mounted) {
      _teardown();
      return;
    }
    try {
      await WakelockPlus.enable(); // keep the screen on during the session
    } catch (_) {}

    _statusTimer?.cancel();
    _sendPresence();
    _presenceTimer = Timer.periodic(const Duration(seconds: 15), (_) => _sendPresence());

    if (mounted) setState(() => _phase = _Phase.inCall);
  }

  void _permissionHelp(String what) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Allow the $what'),
        content: Text('Mindwell needs your $what for the session. You can allow it in your phone\'s settings for Mindwell.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Not now')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              openAppSettings();
            },
            child: const Text('Open settings'),
          ),
        ],
      ),
    );
  }

  void _sendPresence() {
    _api.post('$_base/room/presence').catchError((_) => null);
  }

  void _onRoomChanged() {
    if (mounted) setState(() {});
  }

  void _onDisconnected() {
    if (_leaving || !mounted) return;
    _teardown();
    setState(() {
      _phase = _Phase.checking;
      _message = 'You were disconnected. Check your connection, then join again.';
    });
    _statusTimer?.cancel();
    _statusTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkRoom());
    _checkRoom();
  }

  /// Stop everything to do with the live call (safe to call twice).
  void _teardown() {
    _presenceTimer?.cancel();
    _presenceTimer = null;
    final room = _room;
    final listener = _listener;
    _room = null;
    _listener = null;
    if (room != null) {
      room.removeListener(_onRoomChanged);
      room.disconnect().catchError((_) {}).whenComplete(() => room.dispose());
    }
    listener?.dispose();
    WakelockPlus.disable().catchError((_) {});
  }

  Future<void> _leave() async {
    final ok = await confirmDialog(context, title: 'Leave the session?', body: 'You can join again while the session is still running.', yes: 'Leave', danger: true);
    if (!ok || !mounted) return;
    _leaving = true;
    await _saveNotes();
    _api.post('$_base/room/presence', {'leaving': 1}).catchError((_) => null);
    _teardown();
    _app.dataChanged();
    if (mounted) setState(() => _phase = _Phase.left);
  }

  // ---- in-call controls -------------------------------------------------------------

  Future<void> _toggleMic() async {
    final p = _room?.localParticipant;
    if (p == null || _controlsBusy) return;
    setState(() => _controlsBusy = true);
    try {
      await p.setMicrophoneEnabled(!_micOn);
      _micOn = !_micOn;
    } catch (_) {
      if (mounted) showSnack(context, "Couldn't change the microphone.", error: true);
    } finally {
      if (mounted) setState(() => _controlsBusy = false);
    }
  }

  Future<void> _toggleCam() async {
    final p = _room?.localParticipant;
    if (p == null || _controlsBusy) return;
    if (!_camOn) {
      final granted = (await Permission.camera.request()).isGranted;
      if (!mounted) return;
      if (!granted) {
        _permissionHelp('camera');
        return;
      }
    }
    setState(() => _controlsBusy = true);
    try {
      await p.setCameraEnabled(!_camOn);
      _camOn = !_camOn;
    } catch (_) {
      if (mounted) showSnack(context, "Couldn't change the camera.", error: true);
    } finally {
      if (mounted) setState(() => _controlsBusy = false);
    }
  }

  Future<void> _flip() async {
    final track = _localVideo();
    if (track == null || _controlsBusy) return;
    setState(() => _controlsBusy = true);
    try {
      await track.setCameraPosition(_front ? lk.CameraPosition.back : lk.CameraPosition.front);
      _front = !_front;
    } catch (_) {
      if (mounted) showSnack(context, "Couldn't switch camera.", error: true);
    } finally {
      if (mounted) setState(() => _controlsBusy = false);
    }
  }

  lk.LocalVideoTrack? _localVideo() {
    final p = _room?.localParticipant;
    if (p == null) return null;
    for (final pub in p.videoTrackPublications) {
      final t = pub.track;
      if (t is lk.LocalVideoTrack && !pub.muted) return t;
    }
    return null;
  }

  lk.RemoteParticipant? _remote() {
    final all = _room?.remoteParticipants.values;
    if (all == null || all.isEmpty) return null;
    return all.first;
  }

  lk.VideoTrack? _remoteVideo(lk.RemoteParticipant? p) {
    if (p == null) return null;
    for (final pub in p.videoTrackPublications) {
      final t = pub.track;
      if (t is lk.RemoteVideoTrack && !pub.muted) return t;
    }
    return null;
  }

  // ---- notepad ------------------------------------------------------------------

  void _notesChanged() {
    _notesDebounce?.cancel();
    _notesDirty = true;
    _notesStatus.value = 'Saving…';
    _notesDebounce = Timer(const Duration(milliseconds: 1200), _saveNotes);
  }

  Future<void> _saveNotes() async {
    _notesDebounce?.cancel();
    // Only when something was typed — never create an empty journal entry.
    if (!_notesDirty) return;
    _notesDirty = false;
    try {
      await _api.post('$_base/room/notes', {'body': _notes.text, 'shared': _notesShared});
      _notesStatus.value = 'Saved to your journal';
    } on ApiException catch (e) {
      _notesStatus.value = e.message;
      // Offline: try again on the next save. Anything else (e.g. the session has been
      // closed) won't fix itself, so stop.
      if (e.isOffline) _notesDirty = true;
    }
    if (mounted) setState(() {});
  }

  void _openNotes() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(18, 18, 18, 18 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('My notes', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Mw.ink900)),
              const SizedBox(height: 2),
              const Text('Private. Saved to your journal as you type.', style: TextStyle(color: Mw.ink500, fontSize: 12.5)),
              const SizedBox(height: 12),
              TextField(
                controller: _notes,
                minLines: 5,
                maxLines: 10,
                maxLength: 20000,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(hintText: 'Anything you want to remember…', counterText: ''),
                onChanged: (_) {
                  _notesChanged();
                  setSheet(() {});
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: _notesShared,
                onChanged: (v) {
                  _notesShared = v;
                  _notesChanged();
                  setSheet(() {});
                },
                title: const Text('Share with my therapist', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
              ValueListenableBuilder<String>(
                valueListenable: _notesStatus,
                builder: (_, status, __) => Text(status, style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
              ),
            ],
          ),
        ),
      ),
    ).whenComplete(_saveNotes);
  }

  // ---- UI --------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    if (_phase == _Phase.inCall) {
      return PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _leave();
        },
        child: _callView(),
      );
    }

    return PopScope(
      canPop: _phase != _Phase.connecting,
      child: Scaffold(
      appBar: AppBar(title: Text(_phase == _Phase.left ? 'Session' : 'Video room')),
      body: switch (_phase) {
        _Phase.left => _leftView(),
        _Phase.unavailable => Center(
            child: EmptyState(
              icon: Icons.videocam_off_outlined,
              title: 'The room is closed',
              text: _message,
              actions: [OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Back'))],
            ),
          ),
        _ => _lobbyView(),
      },
      ),
    );
  }

  Widget _lobbyView() {
    final live = _info['therapist_in_room'] == true;
    final opens = parseDate(_info['opens_at']);
    final ready = _phase == _Phase.ready;
    final connecting = _phase == _Phase.connecting;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      children: [
        Center(child: Avatar(name: _therapistName, size: 92)),
        const SizedBox(height: 14),
        Text(_therapistName, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Mw.ink900)),
        const SizedBox(height: 8),
        Center(
          child: live
              ? const Pill('● In the room now', color: Colors.white, background: Mw.teal)
              : Pill(_phase == _Phase.checking ? 'Checking the room…' : 'Not in the room yet', color: Mw.ink500, background: Colors.white),
        ),
        const SizedBox(height: 18),
        Text(
          switch (_phase) {
            _Phase.waiting => opens != null
                ? 'The room opens at ${fmtTime(opens)}${fmtRelativeDay(opens) == 'Today' ? '' : ' on ${fmtDay(opens)}'}. '
                    "If $_therapistName opens it earlier, you'll be able to join straight away."
                : "The room isn't open yet.",
            _Phase.ready => live ? '$_therapistName is ready for you.' : 'You can join now. $_therapistName will be with you at the start time.',
            _Phase.connecting => 'Connecting…',
            _ => 'One moment…',
          },
          textAlign: TextAlign.center,
          style: const TextStyle(color: Mw.ink700, fontSize: 15, height: 1.5),
        ),
        if (_message != null) ...[
          const SizedBox(height: 12),
          NoticeBox(text: _message!),
        ],
        const SizedBox(height: 18),
        MwCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(
            children: [
              SwitchListTile(
                value: _camOn,
                onChanged: connecting ? null : (v) => setState(() => _camOn = v),
                secondary: Icon(_camOn ? Icons.videocam_rounded : Icons.videocam_off_rounded, color: Mw.teal),
                title: const Text('Camera on', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
              SwitchListTile(
                value: _micOn,
                onChanged: connecting ? null : (v) => setState(() => _micOn = v),
                secondary: Icon(_micOn ? Icons.mic_rounded : Icons.mic_off_rounded, color: Mw.teal),
                title: const Text('Microphone on', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
        PrimaryButton(
          label: ready ? 'Join session' : (connecting ? 'Joining…' : 'Waiting for the room to open'),
          color: Mw.orange,
          busy: connecting,
          onPressed: ready ? _join : null,
        ),
        const SizedBox(height: 14),
        const Text(
          'Find a quiet, private place. Headphones help. Nothing is recorded.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Mw.ink500, fontSize: 12.5),
        ),
        const SizedBox(height: 6),
        Center(
          child: TextButton.icon(
            onPressed: _openNotes,
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('My notes'),
          ),
        ),
      ],
    );
  }

  Widget _callView() {
    final remote = _remote();
    final remoteVideo = _remoteVideo(remote);
    final local = _localVideo();
    final end = parseDate(_info['ends_at']);
    final minsLeft = end?.difference(DateTime.now()).inMinutes;

    return Scaffold(
      backgroundColor: const Color(0xFF101816),
      body: Stack(
        children: [
          Positioned.fill(
            child: remoteVideo != null
                ? lk.VideoTrackRenderer(remoteVideo)
                : Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Avatar(name: _therapistName, size: 96),
                        const SizedBox(height: 14),
                        Text(
                          remote == null ? 'Waiting for $_therapistName to join…' : "$_therapistName's camera is off",
                          style: const TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
          ),
          // Top bar
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xCC000000), Color(0x00000000)],
                ),
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_therapistName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                            if (minsLeft != null)
                              Text(
                                minsLeft > 0 ? '$minsLeft min left' : 'Past the planned end',
                                style: const TextStyle(color: Colors.white70, fontSize: 12.5),
                              ),
                          ],
                        ),
                      ),
                      if (remote != null && !remote.isMicrophoneEnabled())
                        const Padding(
                          padding: EdgeInsets.only(right: 8),
                          child: Icon(Icons.mic_off_rounded, color: Colors.white70, size: 20),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // My picture
          Positioned(
            right: 14,
            top: MediaQuery.of(context).padding.top + 70,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Container(
                width: 104,
                height: 148,
                color: const Color(0xFF26332F),
                child: local != null
                    ? lk.VideoTrackRenderer(local)
                    : const Icon(Icons.videocam_off_rounded, color: Colors.white38),
              ),
            ),
          ),
          // Controls
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _roundButton(_micOn ? Icons.mic_rounded : Icons.mic_off_rounded, _micOn ? 'Mute' : 'Unmute', _toggleMic, on: _micOn),
                    _roundButton(_camOn ? Icons.videocam_rounded : Icons.videocam_off_rounded, 'Camera', _toggleCam, on: _camOn),
                    _roundButton(Icons.cameraswitch_rounded, 'Flip', _camOn ? _flip : null, on: true),
                    _roundButton(Icons.edit_note_rounded, 'Notes', _openNotes, on: true),
                    _roundButton(Icons.call_end_rounded, 'Leave', _leave, danger: true),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _roundButton(IconData icon, String label, VoidCallback? onTap, {bool on = true, bool danger = false}) {
    final bg = danger ? Mw.danger : (on ? const Color(0x33FFFFFF) : Colors.white);
    final fg = danger ? Colors.white : (on ? Colors.white : Mw.ink900);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: onTap == null ? const Color(0x1AFFFFFF) : bg,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(width: 56, height: 56, child: Icon(icon, color: onTap == null ? Colors.white38 : fg)),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
      ],
    );
  }

  Widget _leftView() {
    return Center(
      child: EmptyState(
        icon: Icons.favorite_rounded,
        title: 'Thank you for showing up for yourself',
        text: 'Your notes are in your journal. Take a moment before you go back to your day.',
        actions: [
          ElevatedButton.icon(
            onPressed: () async {
              final sent = await showRateSheet(context, sessionId: widget.sessionId, therapistName: _therapistName);
              if (sent && mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.star_rounded, color: Mw.gold),
            label: const Text('Rate this session'),
          ),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
        ],
      ),
    );
  }
}
