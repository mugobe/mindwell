import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/rate_sheet.dart';
import '../../widgets/reload_on_change.dart';
import '../intake/about_you_screen.dart';
import '../intake/intake_screen.dart';
import '../more/my_details_screen.dart';
import '../progress/check_in_screen.dart';
import '../sessions/session_detail_screen.dart';
import '../sessions/session_flow.dart';
import '../therapists/therapists_screen.dart';
import '../urgent_help_screen.dart';
import '../video/room_screen.dart';

/// Home — the same cards as the website dashboard, from GET /dashboard.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.onOpenTab});

  /// Switch bottom tab (1 Sessions, 2 Messages, 3 Journal, 4 More).
  final void Function(int index) onOpenTab;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with ReloadOnChange<DashboardScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Future<void> reload() => _load();

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = _data == null;
      _error = null;
    });
    try {
      final data = await context.read<AppState>().api.get('dashboard');
      if (mounted) setState(() => _data = data as Map<String, dynamic>);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveMood(int mood) async {
    try {
      await context.read<AppState>().api.post('journal', {'mood': mood});
      if (!mounted) return;
      showSnack(context, 'Thank you for checking in. It is saved in your journal.');
      context.read<AppState>().dataChanged(); // Home and the Journal tab both reload
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  Future<void> _aboutNotNow() async {
    try {
      await context.read<AppState>().api.post('about-you/not-now');
      if (mounted) _load();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final d = _data;

    return Scaffold(
      appBar: AppBar(
        title: const MwLogo(size: 22),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton.icon(
              style: TextButton.styleFrom(foregroundColor: Mw.danger, backgroundColor: Mw.dangerTint, shape: const StadiumBorder()),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen())),
              icon: const Icon(Icons.favorite_rounded, size: 16),
              label: const Text('Get help now'),
            ),
          ),
        ],
      ),
      body: _loading
          ? const LoadingView()
          : (_error != null && d == null)
              ? ErrorView(message: _error!.message, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    children: [
                      Text('${greeting()}, ${d?['greeting_name'] ?? state.firstName}',
                          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Mw.ink900)),
                      const SizedBox(height: 2),
                      Text(fmtDayLong(DateTime.now()), style: const TextStyle(color: Mw.ink500, fontSize: 14)),
                      const SizedBox(height: 16),
                      if (d != null) ..._cards(d),
                    ],
                  ),
                ),
    );
  }

  List<Widget> _cards(Map<String, dynamic> d) {
    final cards = <Widget>[];

    if (d['intake_done'] != true) {
      cards.add(MwBanner(
        kind: MwBannerKind.chat,
        title: "Let's find the right therapist for you",
        text: 'Answer a few short questions about how you have been feeling. We use them to match you with a therapist.',
        actions: [MwPillButton(label: 'Start', filled: true, onPressed: () => _open(const IntakeScreen()))],
      ));
    }

    if (d['next_session'] is Map) {
      final next = d['next_session'] as Map<String, dynamic>;
      cards.add(_NextSessionCard(
        session: next,
        onOpen: () => _open(SessionDetailScreen(sessionId: '${next['id']}')),
        onJoin: () => _open(RoomScreen(sessionId: '${next['id']}')),
      ));
    }
    if (d['in_progress'] is Map) {
      final s = d['in_progress'] as Map<String, dynamic>;
      cards.add(_InProgressCard(session: s, onOpen: () async {
        await openSession(context, s);
        if (mounted) _load();
      }));
    }

    if (d['intake_done'] == true && d['next_session'] == null && d['in_progress'] == null) {
      cards.add(MwCard(
        child: Row(
          children: [
            const Icon(Icons.event_available_rounded, color: Mw.teal),
            const SizedBox(width: 12),
            const Expanded(
              child: Text('Ready for your next session?', style: TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900)),
            ),
            ElevatedButton(onPressed: () => _open(const TherapistsScreen()), child: const Text('Book')),
          ],
        ),
      ));
    }

    if (d['intake_done'] == true) cards.add(_MoodCard(moodToday: d['mood_today'] as int?, onPick: _saveMood, onJournal: () => widget.onOpenTab(3)));

    final checkIn = d['check_in'] as Map<String, dynamic>?;
    if (checkIn?['due'] == true) {
      cards.add(MwBanner(
        kind: MwBannerKind.event,
        title: 'Time for your check-in',
        text: 'It takes about 3 minutes and helps you and your therapist see how things are changing.',
        actions: [MwPillButton(label: 'Start check-in', filled: true, onPressed: () => _open(const CheckInScreen()))],
      ));
    }

    // From AppState (refreshed every 30s and after reading a chat), not the dashboard
    // answer, so the card clears as soon as the messages are read.
    final unread = context.read<AppState>().unreadMessages;
    if (unread > 0) {
      cards.add(MwCard(
        onTap: () => widget.onOpenTab(2),
        child: Row(
          children: [
            const Icon(Icons.chat_bubble_rounded, color: Mw.orange),
            const SizedBox(width: 12),
            Expanded(
              child: Text(unread == 1 ? 'You have a new message' : 'You have $unread new messages',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900)),
            ),
            const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
          ],
        ),
      ));
    }

    if (d['rate_session'] is Map) {
      cards.add(_RateCard(rate: d['rate_session'] as Map<String, dynamic>, onDone: _load));
    }

    if (d['about_you_prompt'] == true) {
      cards.add(MwBanner(
        kind: MwBannerKind.chat,
        title: 'Tell your therapist a bit about you',
        text: 'What brings you here and what you hope for. It takes a couple of minutes and every question is optional.',
        actions: [
          MwPillButton(label: 'Start', filled: true, onPressed: () => _open(const AboutYouScreen())),
          MwPillButton(label: 'Not now', onPressed: _aboutNotNow),
        ],
      ));
    }

    if (d['emergency_contact_missing'] == true) {
      cards.add(MwBanner(
        kind: MwBannerKind.person,
        title: 'Add an emergency contact',
        text: 'Someone we can call if we are ever worried about your safety. Only your care team can see it.',
        actions: [MwPillButton(label: 'Add contact', onPressed: () => _open(const MyDetailsScreen()))],
      ));
    }

    final coverage = d['coverage'] as Map<String, dynamic>?;
    if (coverage != null) {
      cards.add(MwCard(
        child: Row(
          children: [
            Icon(coverage['type'] == 'employer' ? Icons.business_rounded : Icons.workspace_premium_outlined, color: Mw.teal),
            const SizedBox(width: 12),
            Expanded(child: Text('${coverage['label']}', style: const TextStyle(fontWeight: FontWeight.w700, color: Mw.ink900))),
          ],
        ),
      ));
    }

    cards.add(const MwBanner(
      kind: MwBannerKind.privacy,
      title: 'Your privacy comes first',
      text: 'Your sessions and reports are confidential. Only you and your therapist can see them.',
    ));

    return cards;
  }
}

class _NextSessionCard extends StatelessWidget {
  const _NextSessionCard({required this.session, required this.onOpen, required this.onJoin});

  final Map<String, dynamic> session;
  final VoidCallback onOpen;
  final VoidCallback onJoin;

  @override
  Widget build(BuildContext context) {
    final therapist = session['therapist'] as Map<String, dynamic>?;
    final name = '${therapist?['name'] ?? 'Your therapist'}';
    final at = parseDate(session['scheduled_at']);
    final inPerson = session['mode'] == 'in_person';
    final join = session['join'] as Map<String, dynamic>?;
    final opensAt = parseDate(join?['opens_at']);

    String status;
    var canJoin = false;
    if (inPerson) {
      status = ((session['location'] as Map?)?['text'] as String?) ?? 'Place to be confirmed by our team';
    } else if (join?['state'] == 'open') {
      canJoin = true;
      status = join?['therapist_in_room'] == true ? '$name is in the room. Join now.' : 'Your room is open.';
    } else if (join?['state'] == 'too_early' && opensAt != null) {
      status = 'You can join from ${fmtTime(opensAt)}${join?['therapist_in_room'] == true ? ', or now because $name is ready' : ''}.';
    } else {
      status = 'Video session';
    }

    return MwCard(
      onTap: onOpen,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('YOUR NEXT SESSION', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: Mw.teal, letterSpacing: .6)),
          const SizedBox(height: 10),
          Row(
            children: [
              Avatar(name: name, size: 46, photoUrl: therapist?['photo_url'] as String?),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(at != null ? '${fmtDayLong(at)} · ${fmtTime(at)}' : 'Time to be confirmed',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Mw.ink900)),
                    const SizedBox(height: 2),
                    Text('With $name · ${inPerson ? 'In person' : 'Video'} · ${session['duration_minutes'] ?? 70} min',
                        style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(status, style: TextStyle(color: canJoin ? Mw.teal : Mw.ink700, fontWeight: canJoin ? FontWeight.w800 : FontWeight.w500)),
          if (canJoin) ...[
            const SizedBox(height: 10),
            PrimaryButton(label: 'Join session', color: Mw.orange, onPressed: onJoin),
          ],
        ],
      ),
    );
  }
}

class _InProgressCard extends StatelessWidget {
  const _InProgressCard({required this.session, required this.onOpen});

  final Map<String, dynamic> session;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final step = session['next_step'];
    final text = switch (step) {
      'checkout' => 'Waiting for payment. Finish paying to continue.',
      'lobby' => "We're finding the right therapist for you.",
      'awaiting_approval' => 'Booked. Waiting for our team to confirm. We will let you know.',
      _ => '${session['status_label'] ?? ''}',
    };
    return MwCard(
      onTap: onOpen,
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(color: Mw.tealTint, shape: BoxShape.circle),
            child: const Icon(Icons.hourglass_top_rounded, color: Mw.teal),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('You have a session in progress', style: TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
                const SizedBox(height: 2),
                Text(text, style: const TextStyle(color: Mw.ink500, fontSize: 13)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
        ],
      ),
    );
  }
}

class _MoodCard extends StatelessWidget {
  const _MoodCard({required this.moodToday, required this.onPick, required this.onJournal});

  final int? moodToday;
  final void Function(int) onPick;
  final VoidCallback onJournal;

  static const _labels = {1: 'Very low', 2: 'Low', 3: 'Okay', 4: 'Good', 5: 'Great'};

  @override
  Widget build(BuildContext context) {
    if (moodToday != null) {
      return MwCard(
        onTap: onJournal,
        child: Row(
          children: [
            Container(width: 14, height: 14, decoration: BoxDecoration(color: Mw.moods[moodToday], shape: BoxShape.circle)),
            const SizedBox(width: 10),
            Expanded(
              child: Text.rich(TextSpan(children: [
                const TextSpan(text: "Today you said you're feeling "),
                TextSpan(text: (_labels[moodToday] ?? '').toLowerCase(), style: const TextStyle(fontWeight: FontWeight.w800)),
                const TextSpan(text: '.'),
              ]), style: const TextStyle(color: Mw.ink700)),
            ),
          ],
        ),
      );
    }

    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('How are you feeling today?', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: Mw.ink900)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final e in _labels.entries)
                ActionChip(
                  avatar: CircleAvatar(backgroundColor: Mw.moods[e.key], radius: 6),
                  label: Text(e.value),
                  onPressed: () => onPick(e.key),
                  shape: const StadiumBorder(side: BorderSide(color: Mw.line)),
                  backgroundColor: Colors.white,
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RateCard extends StatelessWidget {
  const _RateCard({required this.rate, required this.onDone});

  final Map<String, dynamic> rate;
  final VoidCallback onDone;

  Future<void> _skip(BuildContext context) async {
    try {
      await context.read<AppState>().api.post('sessions/${rate['session_id']}/rating', {'skip': true});
      onDone();
    } on ApiException catch (e) {
      if (context.mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final at = parseDate(rate['scheduled_at']);
    return MwCard(
      borderColor: const Color(0xFFF6E1A8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text.rich(TextSpan(children: [
            const TextSpan(text: '★ ', style: TextStyle(color: Mw.gold)),
            TextSpan(text: 'How was your session with ${rate['therapist_name']}?'),
          ]), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: Mw.ink900)),
          if (at != null) ...[
            const SizedBox(height: 2),
            Text('${fmtDayLong(at)} · takes a few seconds', style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              ElevatedButton(
                onPressed: () async {
                  final sent = await showRateSheet(context, sessionId: '${rate['session_id']}', therapistName: '${rate['therapist_name']}');
                  if (sent) onDone();
                },
                child: const Text('Rate it'),
              ),
              const SizedBox(width: 6),
              TextButton(onPressed: () => _skip(context), child: const Text('Not now')),
            ],
          ),
        ],
      ),
    );
  }
}
