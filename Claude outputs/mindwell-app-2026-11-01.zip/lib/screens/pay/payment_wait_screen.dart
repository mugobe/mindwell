import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';

/// "Approve on your phone" — follows one Mobile Money payment until it's done by
/// polling GET payments/{id} every 4 seconds (stops after 10 minutes).
///
/// Pops with the last API answer ({state, message, payment, session}) once the state
/// is `succeeded` or `failed`, or null if the person leaves early (the payment can still
/// go through — the website and Payments list will show it).
///
/// Used for sessions now and plans/renewals in stage 3.
class PaymentWaitScreen extends StatefulWidget {
  const PaymentWaitScreen({super.key, required this.start});

  /// The answer from the pay call (state = pending).
  final Map<String, dynamic> start;

  @override
  State<PaymentWaitScreen> createState() => _PaymentWaitScreenState();
}

class _PaymentWaitScreenState extends State<PaymentWaitScreen> {
  static const _every = Duration(seconds: 4);
  static const _giveUpAfter = Duration(minutes: 10);

  late Map<String, dynamic> _last = widget.start;
  late String _instruction = (widget.start['message'] as String?) ??
      ((widget.start['payment'] as Map?)?['instruction'] as String?) ??
      'Check your phone and enter your Mobile Money PIN to approve the payment.';
  String? _note;
  Timer? _timer;
  bool _checking = false;
  bool _stopped = false;
  bool _simulating = false;
  bool _done = false; // popped (or popping) — ignore late answers
  final _started = DateTime.now();

  String get _paymentId => '${(widget.start['payment'] as Map)['id']}';

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(_every, (_) => _check());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _check() async {
    if (_done || _checking || !mounted) return;
    if (DateTime.now().difference(_started) > _giveUpAfter) {
      _timer?.cancel();
      setState(() => _stopped = true);
      return;
    }
    _checking = true;
    try {
      final res = (await context.read<AppState>().api.get('payments/$_paymentId')) as Map<String, dynamic>;
      if (!mounted) return;
      _handle(res);
    } on ApiException catch (e) {
      // A dropped connection shouldn't end the wait — keep trying quietly.
      if (mounted) setState(() => _note = e.isOffline ? 'Waiting for a connection…' : e.message);
    } finally {
      _checking = false;
    }
  }

  void _handle(Map<String, dynamic> res) {
    if (_done) return;
    final state = res['state'];
    setState(() {
      _last = res;
      _note = state == 'unreachable' ? (res['message'] as String?) : null;
    });
    if (state == 'succeeded' || state == 'failed') {
      _done = true;
      _timer?.cancel();
      Navigator.pop(context, res);
    }
  }

  Future<void> _simulate(String outcome) async {
    setState(() => _simulating = true);
    try {
      final res = (await context.read<AppState>().api.post('payments/$_paymentId/simulate', {'outcome': outcome})) as Map<String, dynamic>;
      if (mounted) _handle(res);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _simulating = false);
    }
  }

  void _checkAgain() {
    setState(() => _stopped = false);
    _timer?.cancel();
    _timer = Timer.periodic(_every, (_) => _check());
    _check();
  }

  @override
  Widget build(BuildContext context) {
    final payment = (_last['payment'] as Map?) ?? const {};
    final canSimulate = _last['can_simulate'] == true || widget.start['can_simulate'] == true;
    final amount = payment['amount'];
    final currency = '${payment['currency'] ?? 'UGX'}';

    return PopScope(
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) {
          _done = true;
          _timer?.cancel();
        }
      },
      child: Scaffold(
      appBar: AppBar(title: const Text('Approve payment')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        children: [
          Center(
            child: Container(
              width: 92,
              height: 92,
              decoration: const BoxDecoration(color: Mw.tealTint, shape: BoxShape.circle),
              child: _stopped
                  ? const Icon(Icons.hourglass_disabled_rounded, color: Mw.teal, size: 40)
                  : const Padding(
                      padding: EdgeInsets.all(26),
                      child: CircularProgressIndicator(strokeWidth: 3.5),
                    ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            _stopped ? "We haven't heard back yet" : 'Approve on your phone',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Mw.ink900),
          ),
          const SizedBox(height: 8),
          Text(
            _stopped
                ? "If you approved it, it can take a few minutes to come through. Check again, or look at My sessions later."
                : _instruction,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Mw.ink700, fontSize: 15, height: 1.5),
          ),
          if (amount != null) ...[
            const SizedBox(height: 14),
            Center(child: Pill('${payment['method'] ?? 'Mobile Money'} · ${money(amount, currency)}')),
          ],
          if (_note != null) ...[
            const SizedBox(height: 14),
            Text(_note!, textAlign: TextAlign.center, style: const TextStyle(color: Mw.ink500, fontSize: 13)),
          ],
          const SizedBox(height: 22),
          if (!_stopped)
            const MwCard(
              child: Text(
                "Keep this screen open. A prompt will appear on the phone with this Mobile Money number. "
                "Enter your PIN there and we will continue once the payment is confirmed.",
                style: TextStyle(color: Mw.ink700, fontSize: 13.5, height: 1.45),
              ),
            ),
          if (_stopped) PrimaryButton(label: 'Check again', onPressed: _checkAgain),
          if (canSimulate && !_stopped) ...[
            const SizedBox(height: 6),
            MwBanner(
              kind: MwBannerKind.warning,
              title: 'Test mode',
              text: 'No real money is taken. Choose what the client did on their phone.',
              actions: [
                MwPillButton(label: 'Approve', filled: true, onPressed: _simulating ? null : () => _simulate('approve')),
                MwPillButton(label: 'Decline', onPressed: _simulating ? null : () => _simulate('fail')),
              ],
            ),
          ],
          const SizedBox(height: 8),
          TextButton(
            onPressed: () {
              if (_done) return;
              _done = true;
              _timer?.cancel();
              Navigator.pop(context);
            },
            child: const Text("I'll check later"),
          ),
        ],
      ),
      ),
    );
  }
}
