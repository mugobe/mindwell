import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// "I need urgent help" — works signed in or not (Dr. Ntabade's CLIENT DRAFT item 1).
/// Numbers come from GET config (same as the website's partials/crisis-contacts); the
/// built-in list below is used if the app couldn't reach the server.
///
/// [afterIntake] (stage 2): the screen shown when the first assessment raised a crisis
/// flag — same words as the website's intake/crisis page. The care team has already
/// been alerted by the server.
class UrgentHelpScreen extends StatelessWidget {
  const UrgentHelpScreen({super.key, this.afterIntake = false});

  final bool afterIntake;

  static const List<Map<String, dynamic>> _fallback = [
    {'name': 'Emergency (Uganda)', 'number': '999 or 112', 'dial': '112', 'hours': 'Free · 24 hours, every day', 'primary': true},
    {'name': 'Mental Health Uganda', 'number': '0800 21 21 21', 'dial': '+256800212121', 'hours': 'Toll-free, Monday to Friday, 8:30am to 5:00pm', 'primary': false},
  ];

  @override
  Widget build(BuildContext context) {
    final crisis = context.watch<AppState>().config?['crisis'] as Map<String, dynamic>?;
    final List<Map<String, dynamic>> contacts = (crisis?['contacts'] as List?)?.cast<Map<String, dynamic>>() ?? _fallback;
    final note = (crisis?['note'] as String?) ??
        "You can also go straight to the emergency department of your nearest hospital, or ask someone you trust to stay with you. If you're thinking about ending your life, please tell someone now. You do not have to go through this alone.";

    return Scaffold(
      appBar: AppBar(title: Text(afterIntake ? 'Support is available' : 'Get help now')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 28),
        children: [
          if (afterIntake) ...[
            const Text("You're not alone right now",
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Mw.ink900, height: 1.3)),
            const SizedBox(height: 10),
            const Text(
              'Thank you for answering honestly. Some of your answers suggest you may be going through a lot right now, '
              'including thoughts of hurting yourself. Please reach out to a real person right away. You should not carry this alone.',
              style: TextStyle(fontSize: 14.5, color: Mw.ink700, height: 1.55),
            ),
          ] else
            const Text(
              "If you're in danger or thinking about harming yourself, please reach out right now.",
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Mw.ink900, height: 1.35),
            ),
          const SizedBox(height: 18),
          for (final c in contacts) _ContactButton(contact: c),
          const SizedBox(height: 6),
          if (afterIntake)
            const MwBanner(
              kind: MwBannerKind.info,
              text: "Your answers are saved and we have told the Mindwell care team, so someone can follow up with you. "
                  "Please don't wait for us. Call one of the numbers above now.",
            ),
          MwCard(
            child: Text(note, style: const TextStyle(fontSize: 13.5, color: Mw.ink700, height: 1.5)),
          ),
        ],
      ),
    );
  }
}

class _ContactButton extends StatelessWidget {
  const _ContactButton({required this.contact});

  final Map<String, dynamic> contact;

  @override
  Widget build(BuildContext context) {
    final primary = contact['primary'] == true;
    final dial = '${contact['dial'] ?? ''}';
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: primary ? Mw.danger : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Mw.danger, width: 1.6),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => callNumber(context, dial),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Icon(Icons.call_rounded, color: primary ? Colors.white : Mw.danger),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Call ${contact['name']}: ${contact['number']}',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: primary ? Colors.white : Mw.danger)),
                      const SizedBox(height: 2),
                      Text('${contact['hours'] ?? ''}',
                          style: TextStyle(fontSize: 12.5, color: primary ? Colors.white : Mw.ink500)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
