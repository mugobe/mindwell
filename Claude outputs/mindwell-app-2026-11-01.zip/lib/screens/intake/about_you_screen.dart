import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import 'about_fields.dart';

/// "About you" on its own — for clients who did intake before these questions existed,
/// or who want to change their answers (GET / PUT about-you). Every question is optional.
class AboutYouScreen extends StatefulWidget {
  const AboutYouScreen({super.key});

  @override
  State<AboutYouScreen> createState() => _AboutYouScreenState();
}

class _AboutYouScreenState extends State<AboutYouScreen> {
  List<Map<String, dynamic>> _sections = const [];
  final Map<String, dynamic> _answers = {};
  ApiException? _error;
  bool _loading = true;
  bool _saving = false;
  String? _saveError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = (await context.read<AppState>().api.get('about-you')) as Map<String, dynamic>;
      _sections = ((data['sections'] as List?) ?? const []).cast<Map<String, dynamic>>();
      _answers.clear();
      final a = data['answers'];
      if (a is Map) {
        a.forEach((k, v) {
          if (k != 'dismissed' && v != null) _answers['$k'] = v is List ? [...v] : v;
        });
      }
    } on ApiException catch (e) {
      _error = e;
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _saveError = null;
    });
    final app = context.read<AppState>();
    try {
      final res = await app.api.put('about-you', aboutPayload(_sections, _answers));
      if (!mounted) return;
      app.dataChanged();
      Navigator.pop(context);
      showSnack(context, (res is Map && res['message'] is String) ? res['message'] as String : 'Saved.');
    } on ApiException catch (e) {
      if (mounted) setState(() => _saveError = e.errors.isNotEmpty ? e.errors.values.first.first : e.message);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About you')),
      body: _loading
          ? const LoadingView()
          : _error != null
              ? ErrorView(message: _error!.message, onRetry: _load)
              : _sections.isEmpty
                  ? const Center(
                      child: EmptyState(
                        icon: Icons.person_outline_rounded,
                        title: 'Nothing to fill in right now',
                        text: 'Your therapist will get to know you in your sessions.',
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                      children: [
                        const Text(
                          'What brings you here and what you hope for. Every question is optional. Your therapist sees this before your next session.',
                          style: TextStyle(color: Mw.ink700, height: 1.45),
                        ),
                        const SizedBox(height: 14),
                        for (final s in _sections)
                          MwCard(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${s['title']}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Mw.ink900)),
                                if (s['help'] != null) ...[
                                  const SizedBox(height: 4),
                                  Text('${s['help']}', style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                                ],
                                const SizedBox(height: 14),
                                AboutSectionFields(section: s, answers: _answers, onChanged: () {}),
                              ],
                            ),
                          ),
                        if (_saveError != null) NoticeBox(text: _saveError!),
                        PrimaryButton(label: 'Save', busy: _saving, onPressed: _save),
                      ],
                    ),
    );
  }
}
