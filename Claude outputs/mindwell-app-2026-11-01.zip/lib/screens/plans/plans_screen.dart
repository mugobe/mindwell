import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import 'employer_screen.dart';
import 'plan_checkout_screen.dart';

/// "a week" / "a month" for a plan's billing interval.
String intervalText(dynamic interval) => switch ('$interval') {
      'weekly' => 'a week',
      'monthly' => 'a month',
      final other => 'per ${other.replaceAll('ly', '')}',
    };

/// My plan (GET plans): the current plan and its sessions left, renewing, and every plan
/// on offer — same as the website's Plans page.
class PlansScreen extends StatefulWidget {
  const PlansScreen({super.key});

  @override
  State<PlansScreen> createState() => _PlansScreenState();
}

class _PlansScreenState extends State<PlansScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('plans')) as Map<String, dynamic>;
      if (mounted) setState(() => _data = data);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My plan')),
      body: _error != null && _data == null
          ? ErrorView(message: _error!.message, onRetry: _load)
          : _data == null
              ? const LoadingView()
              : RefreshIndicator(onRefresh: _load, child: _body(_data!)),
    );
  }

  Widget _body(Map<String, dynamic> d) {
    final current = d['current'] as Map<String, dynamic>?;
    final currency = '${d['currency'] ?? 'UGX'}';
    final plans = ((d['plans'] as List?) ?? const []).cast<Map<String, dynamic>>();
    final currentPlanId = (current?['plan'] as Map?)?['id'];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        if (current != null) _currentCard(current, d['total_credits']) else _noPlanCard(d['recently_ended'] as Map<String, dynamic>?),
        MwCard(
          onTap: () => _open(const EmployerScreen()),
          child: const Row(
            children: [
              Icon(Icons.business_rounded, color: Mw.teal),
              SizedBox(width: 12),
              Expanded(
                child: Text('Covered by your employer? Enter your company code',
                    style: TextStyle(fontWeight: FontWeight.w700, color: Mw.ink900)),
              ),
              Icon(Icons.chevron_right_rounded, color: Mw.ink300),
            ],
          ),
        ),
        const SectionTitle('Plans'),
        if (plans.isEmpty) const Text('No plans are on offer right now.', style: TextStyle(color: Mw.ink500)),
        for (final p in plans)
          MwCard(
            borderColor: p['id'] == currentPlanId ? Mw.teal : null,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text('${p['name']}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Mw.ink900)),
                    ),
                    if (p['id'] == currentPlanId) const Pill('Your plan'),
                  ],
                ),
                const SizedBox(height: 4),
                Text.rich(TextSpan(children: [
                  TextSpan(text: money(p['price'], currency), style: const TextStyle(fontWeight: FontWeight.w900, color: Mw.teal, fontSize: 18)),
                  TextSpan(text: '  ·  ${p['sessions_included']} ${p['sessions_included'] == 1 ? 'session' : 'sessions'} ${intervalText(p['billing_interval'])}'),
                ]), style: const TextStyle(color: Mw.ink500)),
                for (final f in ((p['features'] as List?) ?? const []))
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.check_rounded, size: 18, color: Mw.teal),
                        const SizedBox(width: 6),
                        Expanded(child: Text('$f', style: const TextStyle(color: Mw.ink700))),
                      ],
                    ),
                  ),
                if (p['id'] != currentPlanId) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => _open(PlanCheckoutScreen.subscribe(planId: '${p['id']}')),
                      child: Text(current == null ? 'Choose this plan' : 'Switch to this plan'),
                    ),
                  ),
                ],
              ],
            ),
          ),
      ],
    );
  }

  Widget _currentCard(Map<String, dynamic> s, dynamic totalCredits) {
    final plan = (s['plan'] as Map?) ?? const {};
    final end = DateTime.tryParse('${s['period_end'] ?? ''}');
    final lastDay = DateTime.tryParse('${s['last_usable_day'] ?? ''}');
    final phase = s['phase'];
    final left = (totalCredits ?? s['sessions_remaining'] ?? 0) as num;

    final String note = switch (phase) {
      'renewed' => 'Renewed. Your next period starts${end != null ? ' on ${fmtDayLong(end)}' : ''}.',
      'ending_soon' => 'Ends${end != null ? ' on ${fmtDayLong(end)}' : ' soon'}. Renew to keep your sessions going.',
      'grace' => 'Your renewal date has passed. You can still use it${lastDay != null ? ' until ${fmtDayLong(lastDay)}' : ' for a few days'}. Renew to continue.',
      _ => end != null ? 'Renews on ${fmtDayLong(end)}.' : '',
    };

    return MwCard(
      color: Mw.tealTint,
      borderColor: Mw.tealTint,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('YOUR PLAN', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: Mw.teal, letterSpacing: .6)),
          const SizedBox(height: 6),
          Text('${plan['name'] ?? 'Plan'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Mw.ink900)),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('$left', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Mw.tealDark, height: 1)),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(left == 1 ? 'session left' : 'sessions left', style: const TextStyle(color: Mw.tealDark, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          if (note.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(note, style: const TextStyle(color: Mw.ink700, height: 1.4)),
          ],
          if (s['can_renew'] == true) ...[
            const SizedBox(height: 12),
            ElevatedButton(onPressed: () => _open(const PlanCheckoutScreen.renew()), child: const Text('Renew now')),
          ],
        ],
      ),
    );
  }

  Widget _noPlanCard(Map<String, dynamic>? ended) {
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(ended != null ? 'Your ${ended['name']} plan has ended' : "You're paying per session",
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Mw.ink900)),
          const SizedBox(height: 4),
          const Text('A plan gives you a set number of sessions each period, usually for less than paying one at a time.',
              style: TextStyle(color: Mw.ink500, height: 1.4)),
        ],
      ),
    );
  }
}
