import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../pay/momo_pay.dart';
import 'plans_screen.dart';

/// Buy / switch to a plan (GET plans/{id}/checkout → POST plans/{id}/subscribe), or renew
/// the current one (GET / POST subscription/renew). Same payment steps as a session:
/// voucher → Mobile Money → approve on the phone. The plan only changes once the payment
/// is confirmed on the server.
class PlanCheckoutScreen extends StatefulWidget {
  const PlanCheckoutScreen.subscribe({super.key, required String this.planId}) : renew = false;
  const PlanCheckoutScreen.renew({super.key})
      : planId = null,
        renew = true;

  final String? planId;
  final bool renew;

  @override
  State<PlanCheckoutScreen> createState() => _PlanCheckoutScreenState();
}

class _PlanCheckoutScreenState extends State<PlanCheckoutScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  String? _blocked; // 409: e.g. already renewed

  final _voucher = TextEditingController();
  final _phone = TextEditingController();
  String? _appliedCode;
  bool _applying = false;
  String _network = 'MTN';
  bool _paying = false;
  String? _payError;
  Map<String, String?> _fieldErrors = const {};

  String get _quotePath => widget.renew ? 'subscription/renew' : 'plans/${widget.planId}/checkout';
  String get _payPath => widget.renew ? 'subscription/renew' : 'plans/${widget.planId}/subscribe';

  @override
  void initState() {
    super.initState();
    _phone.text = context.read<AppState>().phoneDigits;
    _network = guessNetwork(_phone.text) ?? 'MTN';
    _load();
  }

  @override
  void dispose() {
    _voucher.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _load({String? voucher}) async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get(
        _quotePath,
        query: voucher == null || voucher.isEmpty ? null : {'voucher': voucher},
      )) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _data = data;
        final q = data['quote'] as Map;
        _appliedCode = q['applied'] == true ? '${q['code']}' : null;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      if (e.status == 409) {
        setState(() => _blocked = e.message);
      } else if (_data != null) {
        showSnack(context, e.message, error: true);
      } else {
        setState(() => _error = e);
      }
    }
  }

  Future<void> _apply() async {
    final code = _voucher.text.trim();
    if (code.isEmpty) return;
    setState(() => _applying = true);
    await _load(voucher: code);
    if (mounted) setState(() => _applying = false);
  }

  Future<void> _pay() async {
    final free = (_data?['quote'] as Map?)?['free'] == true;
    setState(() {
      _paying = true;
      _payError = null;
      _fieldErrors = const {};
    });
    final app = context.read<AppState>();
    try {
      final res = (await app.api.post(_payPath, {
        if (_appliedCode != null) 'voucher': _appliedCode,
        if (!free) 'network': _network,
        if (!free) 'phone_number': digitsOnly(_phone.text),
      })) as Map<String, dynamic>;
      if (!mounted) return;

      final done = await followPayment(context, res);
      if (!mounted) return;
      if (done == null) {
        app.dataChanged();
        Navigator.pop(context);
        showSnack(context, 'If the payment goes through, your plan will update. Check My plan in a few minutes.');
        return;
      }
      if (done['state'] == 'succeeded') {
        app.dataChanged();
        Navigator.pop(context, true);
        showSnack(context, (done['message'] as String?) ?? (widget.renew ? 'Your plan is renewed. Thank you.' : 'Your plan is active. Thank you.'));
      } else {
        setState(() => _payError = (done['message'] as String?) ?? 'Payment was not completed. You can try again.');
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _payError = e.errors.isEmpty ? e.message : null;
        // A voucher that stopped working: drop it so the voucher box shows why.
        if (e.fieldError('voucher') != null) _appliedCode = null;
        _fieldErrors = {
          'phone_number': e.fieldError('phone_number'),
          'network': e.fieldError('network'),
          'voucher': e.fieldError('voucher'),
        };
      });
    } finally {
      if (mounted) setState(() => _paying = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.renew ? 'Renew your plan' : 'Choose this plan')),
      body: _blocked != null
          ? Center(
              child: EmptyState(
                icon: Icons.info_outline_rounded,
                title: widget.renew ? 'Nothing to renew' : 'Not available',
                text: _blocked,
                actions: [OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Back'))],
              ),
            )
          : _error != null && _data == null
              ? ErrorView(message: _error!.message, onRetry: _load)
              : _data == null
                  ? const LoadingView()
                  : _body(),
    );
  }

  Widget _body() {
    final d = _data!;
    final q = d['quote'] as Map<String, dynamic>;
    final currency = '${q['currency'] ?? 'UGX'}';
    final free = q['free'] == true;
    // (Kept out of a `? :` on purpose: `x ? y?['k'] : z` confuses Dart's parser.)
    final Map<String, dynamic>? plan;
    if (widget.renew) {
      final sub = d['subscription'] as Map?;
      plan = sub?['plan'] as Map<String, dynamic>?;
    } else {
      plan = d['plan'] as Map<String, dynamic>?;
    }
    final switching = d['switching_from'] as Map<String, dynamic>?;
    final proration = d['proration'] as Map<String, dynamic>?;
    final bonus = (proration == null ? 0 : (proration['bonus_credits'] as num?) ?? 0).toInt();
    final newStart = DateTime.tryParse('${d['new_period_start'] ?? ''}');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        MwCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${plan?['name'] ?? 'Plan'}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Mw.ink900)),
              if (plan != null)
                Text('${plan['sessions_included']} ${plan['sessions_included'] == 1 ? 'session' : 'sessions'} ${intervalText(plan['billing_interval'])}',
                    style: const TextStyle(color: Mw.ink500)),
              if (widget.renew && newStart != null) ...[
                const SizedBox(height: 8),
                Text(
                  d['in_grace'] == true
                      ? 'Your plan has run past its renewal date. Renewing starts a new period today.'
                      : 'Your next period starts on ${fmtDayLong(newStart)}. Unused sessions carry on until then.',
                  style: const TextStyle(color: Mw.ink700, height: 1.4),
                ),
              ],
              if (!widget.renew && switching != null) ...[
                const SizedBox(height: 10),
                NoticeBox(
                  error: false,
                  text: 'This replaces your ${(switching['plan'] as Map?)?['name'] ?? 'current plan'}.'
                      '${bonus > 0 ? ' The value left on it becomes $bonus extra ${bonus == 1 ? 'session' : 'sessions'} on the new plan.' : ''}',
                ),
              ],
              const Divider(height: 24),
              _line('Price', money(q['original'], currency)),
              if (q['applied'] == true) _line('Voucher ${q['code']}', '− ${money(q['discount'], currency)}', color: Mw.teal),
              const SizedBox(height: 4),
              _line('To pay', money(q['total'], currency), bold: true),
            ],
          ),
        ),
        MwCard(
          child: VoucherBox(
            controller: _voucher,
            appliedCode: _appliedCode,
            error: (q['error'] as String?) ?? _fieldErrors['voucher'],
            applying: _applying,
            onApply: _apply,
            onRemove: () {
              _voucher.clear();
              setState(() => _appliedCode = null);
              _load();
            },
          ),
        ),
        if (free)
          const NoticeBox(text: 'Your voucher covers the full price. There is nothing to pay.', error: false)
        else
          MwCard(
            child: MomoFields(
              network: _network,
              onNetwork: (v) => setState(() => _network = v),
              phone: _phone,
              phoneError: _fieldErrors['phone_number'],
              networkError: _fieldErrors['network'],
            ),
          ),
        if (_payError != null) NoticeBox(text: _payError!),
        PrimaryButton(label: free ? 'Confirm' : 'Pay ${money(q['total'], currency)}', busy: _paying, onPressed: _pay),
      ],
    );
  }

  Widget _line(String label, String value, {bool bold = false, Color? color}) {
    final style = TextStyle(
      fontSize: bold ? 17 : 14,
      fontWeight: bold ? FontWeight.w900 : FontWeight.w600,
      color: color ?? (bold ? Mw.ink900 : Mw.ink700),
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [Expanded(child: Text(label, style: style)), Text(value, style: style)]),
    );
  }
}
