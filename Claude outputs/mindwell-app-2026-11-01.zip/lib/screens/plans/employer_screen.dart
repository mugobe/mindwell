import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

/// Employer benefit (GET / POST employer-benefit): enter the code from your employer and
/// your sessions are covered — same as the website.
class EmployerScreen extends StatefulWidget {
  const EmployerScreen({super.key});

  @override
  State<EmployerScreen> createState() => _EmployerScreenState();
}

class _EmployerScreenState extends State<EmployerScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  final _code = TextEditingController();
  bool _busy = false;
  String? _codeError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('employer-benefit')) as Map<String, dynamic>;
      if (mounted) setState(() => _data = data);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  Future<void> _redeem() async {
    final code = _code.text.trim();
    if (code.isEmpty) {
      setState(() => _codeError = 'Enter the code from your employer.');
      return;
    }
    setState(() {
      _busy = true;
      _codeError = null;
    });
    final app = context.read<AppState>();
    try {
      final res = (await app.api.post('employer-benefit', {'seat_code': code})) as Map<String, dynamic>;
      if (!mounted) return;
      app.dataChanged();
      showSnack(context, '${res['message'] ?? 'Your sessions are now covered.'}');
      _load();
    } on ApiException catch (e) {
      if (mounted) setState(() => _codeError = e.fieldError('seat_code') ?? e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _data;
    return Scaffold(
      appBar: AppBar(title: const Text('Employer benefit')),
      body: _error != null && d == null
          ? ErrorView(message: _error!.message, onRetry: _load)
          : d == null
              ? const LoadingView()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                  children: [
                    if (d['covered'] == true)
                      MwBanner(
                        kind: MwBannerKind.success,
                        title: 'Covered by ${d['employer'] ?? 'your employer'}',
                        text: 'Your sessions are free for as long as this benefit is active. There are no credits to run out.',
                      )
                    else ...[
                      const Text(
                        "If your employer offers Mindwell as a staff benefit, they will give you a short code. Enter it below "
                        'to get free sessions for as long as the benefit is active. You do not need to pay or buy a plan while it covers you.',
                        style: TextStyle(color: Mw.ink700, height: 1.45),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _code,
                        textCapitalization: TextCapitalization.characters,
                        decoration: InputDecoration(labelText: 'Employer code', hintText: 'e.g. AB3D-9KLM', errorText: _codeError),
                        onSubmitted: (_) => _redeem(),
                      ),
                      const SizedBox(height: 14),
                      PrimaryButton(label: 'Redeem code', busy: _busy, onPressed: _redeem),
                    ],
                  ],
                ),
    );
  }
}
