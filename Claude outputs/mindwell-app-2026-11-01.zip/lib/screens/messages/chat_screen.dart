import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../urgent_help_screen.dart';

/// One conversation with a therapist. Opens with POST messages/with/{therapistId} (last 200
/// messages, marks them read), then asks for new ones every 4 seconds while open
/// (GET conversations/{id}/poll?since=…) — same as the website's chat page.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.therapist});

  /// {id, name, photo_url, …} from the API.
  final Map<String, dynamic> therapist;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final ApiClient _api;
  String? _conversationId;
  final List<Map<String, dynamic>> _messages = [];
  DateTime? _theirLastRead;
  String? _safetyNote;
  String? _blocked;
  ApiException? _error;
  bool _loading = true;
  bool _sending = false;
  bool _polling = false;
  bool _canSend = true;
  Timer? _timer;
  final _input = TextEditingController();

  String get _name => '${widget.therapist['name'] ?? 'Your therapist'}';

  @override
  void initState() {
    super.initState();
    _api = context.read<AppState>().api;
    _open();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _input.dispose();
    super.dispose();
  }

  Future<void> _open() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = (await _api.post('messages/with/${widget.therapist['id']}')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _conversationId = '${data['conversation_id']}';
        _messages
          ..clear()
          ..addAll(((data['messages'] as List?) ?? const []).cast<Map<String, dynamic>>());
        _theirLastRead = parseDate(data['therapist_last_read_at']);
        _safetyNote = data['safety_note'] as String?;
        _canSend = data['can_send'] != false;
      });
      context.read<AppState>().refreshUnread();
      _timer?.cancel();
      _timer = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
    } on ApiException catch (e) {
      if (!mounted) return;
      if (e.status == 403) {
        setState(() => _blocked = "You can message $_name after you've had a session together.");
      } else {
        setState(() => _error = e);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _poll() async {
    final id = _conversationId;
    if (id == null || _polling) return;
    // Only while the app is on screen: polling marks messages read for the therapist.
    if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) return;
    _polling = true;
    try {
      final since = _messages.isEmpty ? null : (_messages.last['at'] as String?);
      final data = (await _api.get('conversations/$id/poll', query: since == null ? null : {'since': since})) as Map<String, dynamic>;
      if (!mounted) return;
      _merge(((data['messages'] as List?) ?? const []).cast<Map<String, dynamic>>());
      final read = parseDate(data['otherLastReadAt']);
      if (read != _theirLastRead) setState(() => _theirLastRead = read);
    } catch (_) {
      // Keep quiet — the next poll tries again.
    } finally {
      _polling = false;
    }
  }

  void _merge(List<Map<String, dynamic>> incoming) {
    final known = _messages.map((m) => '${m['id']}').toSet();
    final fresh = incoming.where((m) => !known.contains('${m['id']}')).toList();
    if (fresh.isEmpty) return;
    setState(() => _messages.addAll(fresh));
  }

  Future<void> _send() async {
    final body = _input.text.trim();
    final id = _conversationId;
    if (body.isEmpty || id == null || _sending) return;
    setState(() => _sending = true);
    try {
      final data = (await _api.post('conversations/$id/messages', {'body': body})) as Map<String, dynamic>;
      if (!mounted) return;
      _input.clear();
      final m = data['message'];
      if (m is Map<String, dynamic>) _merge([m]);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.status == 403 ? "This conversation can't take new messages right now." : e.message, error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            Avatar(name: _name, size: 36, photoUrl: widget.therapist['photo_url'] as String?),
            const SizedBox(width: 10),
            Expanded(child: Text(_name, overflow: TextOverflow.ellipsis)),
          ],
        ),
      ),
      body: _loading
          ? const LoadingView()
          : _blocked != null
              ? Center(child: EmptyState(icon: Icons.lock_clock_outlined, title: 'Not open yet', text: _blocked))
              : _error != null
                  ? ErrorView(message: _error!.message, onRetry: _open)
                  : Column(
                      children: [
                        if (_safetyNote != null)
                          Material(
                            color: MwBanner.surface,
                            child: InkWell(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen())),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(16, 9, 16, 9),
                                child: Row(
                                  children: [
                                    const Icon(Icons.info_outline_rounded, size: 18, color: Mw.teal),
                                    const SizedBox(width: 10),
                                    Expanded(child: Text(_safetyNote!, style: const TextStyle(color: MwBanner.body, fontSize: 12.5))),
                                    const Icon(Icons.chevron_right_rounded, size: 18, color: MwBanner.body),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        Expanded(child: _list()),
                        if (_canSend)
                          _composer()
                        else
                          SafeArea(
                            top: false,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(14),
                              color: Colors.white,
                              child: Text("You can message $_name again after your next session together.",
                                  textAlign: TextAlign.center, style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                            ),
                          ),
                      ],
                    ),
    );
  }

  Widget _list() {
    if (_messages.isEmpty) {
      return Center(
        child: EmptyState(
          icon: Icons.waving_hand_outlined,
          title: 'Start the conversation',
          text: 'Send $_name a message. They\'ll reply when they can.',
        ),
      );
    }

    // Newest at the bottom: build the list reversed.
    final items = <Widget>[];
    final lastMineIndex = _messages.lastIndexWhere((m) => m['mine'] == true);
    for (var i = _messages.length - 1; i >= 0; i--) {
      final m = _messages[i];
      final seen = i == lastMineIndex && _theirLastRead != null && (parseDate(m['at'])?.isBefore(_theirLastRead!.add(const Duration(seconds: 1))) ?? false);
      items.add(_bubble(m, seen: seen));
      final prevDay = i > 0 ? _messages[i - 1]['day'] : null;
      if (prevDay != m['day']) items.add(_dayLabel('${m['day'] ?? ''}'));
    }

    return ListView(
      reverse: true,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      children: items,
    );
  }

  Widget _dayLabel(String day) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Center(
          child: Text(day, style: const TextStyle(color: Mw.ink300, fontSize: 12, fontWeight: FontWeight.w700)),
        ),
      );

  Widget _bubble(Map<String, dynamic> m, {bool seen = false}) {
    final mine = m['mine'] == true;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
        child: Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.fromLTRB(13, 9, 13, 7),
          decoration: BoxDecoration(
            color: mine ? Mw.teal : Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(16),
              topRight: const Radius.circular(16),
              bottomLeft: Radius.circular(mine ? 16 : 4),
              bottomRight: Radius.circular(mine ? 4 : 16),
            ),
            border: mine ? null : Border.all(color: Mw.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              SelectableText(
                '${m['body']}',
                style: TextStyle(color: mine ? Colors.white : Mw.ink900, fontSize: 14.5, height: 1.35),
              ),
              const SizedBox(height: 3),
              Text(
                '${m['time'] ?? ''}${seen ? ' · Seen' : ''}',
                style: TextStyle(color: mine ? Colors.white70 : Mw.ink300, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _composer() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
        decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Mw.line))),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: TextField(
                controller: _input,
                minLines: 1,
                maxLines: 5,
                maxLength: 5000,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(hintText: 'Write a message…', counterText: '', fillColor: Mw.canvas),
              ),
            ),
            const SizedBox(width: 6),
            IconButton.filled(
              onPressed: _sending ? null : _send,
              style: IconButton.styleFrom(backgroundColor: Mw.teal, fixedSize: const Size(48, 48)),
              icon: _sending
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.send_rounded, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
