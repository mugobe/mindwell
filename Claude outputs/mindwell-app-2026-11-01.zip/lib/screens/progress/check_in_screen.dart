import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import '../urgent_help_screen.dart';

/// The two-weekly check-in (GET / POST check-in) — the same 16 questions as the first
/// assessment, one per screen. If the answers raise a safety concern the server alerts
/// the care team and the app shows the support screen.
class CheckInScreen extends StatefulWidget {
  const CheckInScreen({super.key});

  @override
  State<CheckInScreen> createState() => _CheckInScreenState();
}

class _CheckInScreenState extends State<CheckInScreen> {
  List<Map<String, dynamic>> _questions = const [];
  List<Map<String, dynamic>> _options = const [];
  String _intro = '';
  final Map<String, int> _answers = {};
  int _index = 0; // 0..n-1 questions, n = send page
  ApiException? _error;
  String? _closed;
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = (await context.read<AppState>().api.get('check-in')) as Map<String, dynamic>;
      _options = ((d['options'] as List?) ?? const []).cast<Map<String, dynamic>>();
      _questions = [
        ...((d['phq9'] as List?) ?? const []).cast<Map<String, dynamic>>(),
        ...((d['gad7'] as List?) ?? const []).cast<Map<String, dynamic>>(),
      ];
      _intro = '${d['intro'] ?? 'Over the last 2 weeks, how often have you been bothered by…'}';
    } on ApiException catch (e) {
      if (e.status == 409) {
        _closed = e.message;
      } else {
        _error = e;
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _answer(String key, int value) async {
    setState(() => _answers[key] = value);
    await Future<void>.delayed(const Duration(milliseconds: 220));
    if (mounted && _index < _questions.length && _questions[_index]['key'] == key) setState(() => _index++);
  }

  Future<void> _send() async {
    final missing = _questions.indexWhere((q) => !_answers.containsKey(q['key']));
    if (missing >= 0) {
      setState(() => _index = missing);
      return;
    }
    setState(() => _sending = true);
    final app = context.read<AppState>();
    try {
      final res = (await app.api.post('check-in', _answers)) as Map<String, dynamic>;
      if (!mounted) return;
      app.dataChanged();
      if (res['outcome'] == 'crisis') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen(afterIntake: true)));
      } else {
        Navigator.pop(context);
        showSnack(context, '${res['message'] ?? 'Thank you. Your check-in is saved.'}');
      }
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(appBar: AppBar(title: const Text('Check-in')), body: const LoadingView());
    if (_closed != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Check-in')),
        body: Center(child: EmptyState(icon: Icons.event_repeat_rounded, title: 'Not open right now', text: _closed)),
      );
    }
    if (_error != null) {
      return Scaffold(appBar: AppBar(title: const Text('Check-in')), body: ErrorView(message: _error!.message, onRetry: _load));
    }

    final n = _questions.length;
    final onSend = _index >= n;

    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => _index--);
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Check-in'),
          leading: _index == 0 ? const CloseButton() : BackButton(onPressed: () => setState(() => _index--)),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4),
            child: LinearProgressIndicator(value: n == 0 ? 0 : _index / n, minHeight: 4, color: Mw.teal, backgroundColor: Mw.tealTint),
          ),
        ),
        body: SafeArea(
          child: onSend ? _sendView() : _questionView(_questions[_index], _index + 1, n),
        ),
      ),
    );
  }

  Widget _questionView(Map<String, dynamic> q, int number, int total) {
    final key = '${q['key']}';
    return ListView(
      key: ValueKey(key),
      padding: const EdgeInsets.all(20),
      children: [
        Text('Question $number of $total', style: const TextStyle(color: Mw.teal, fontWeight: FontWeight.w800, fontSize: 13)),
        const SizedBox(height: 10),
        Text(_intro, style: const TextStyle(color: Mw.ink500, fontSize: 14)),
        const SizedBox(height: 6),
        Text('${q['text']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Mw.ink900, height: 1.3)),
        const SizedBox(height: 22),
        for (final o in _options)
          Builder(builder: (_) {
            final value = o['value'] is int ? o['value'] as int : int.tryParse('${o['value']}') ?? 0;
            final on = _answers[key] == value;
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Material(
                color: on ? Mw.tealTint : Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: BorderSide(color: on ? Mw.teal : Mw.line, width: on ? 1.6 : 1),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => _answer(key, value),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: on ? Mw.teal : Mw.ink300),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text('${o['label']}',
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: on ? Mw.tealDark : Mw.ink900)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget _sendView() {
    return Column(
      children: [
        const Expanded(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("That's everything", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Mw.ink900)),
                SizedBox(height: 10),
                Text('Thank you for checking in. Your therapist will see how things are going.',
                    style: TextStyle(color: Mw.ink700, fontSize: 15, height: 1.5)),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
          child: PrimaryButton(label: 'Send my check-in', busy: _sending, onPressed: _send),
        ),
      ],
    );
  }
}
