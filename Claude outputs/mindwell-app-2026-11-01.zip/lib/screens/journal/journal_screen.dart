import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/reload_on_change.dart';
import '../progress/progress_screen.dart';
import 'journal_entry_screen.dart';

const Map<int, String> kMoodLabels = {1: 'Very low', 2: 'Low', 3: 'Okay', 4: 'Good', 5: 'Great'};

/// Journal tab (GET journal?page=) — daily mood + notes and notes from sessions. Private
/// unless an entry is shared with the therapist. Links to My progress.
class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> with ReloadOnChange<JournalScreen> {
  final List<Map<String, dynamic>> _entries = [];
  List<Map<String, dynamic>> _twoWeeks = const [];
  int _page = 0;
  bool _hasMore = false;
  bool _loading = false;
  bool _loadedOnce = false;
  ApiException? _error;

  @override
  void initState() {
    super.initState();
    reload();
  }

  @override
  Future<void> reload() => _fetch(reset: true);

  Future<void> _fetch({bool reset = false}) async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final next = reset ? 1 : _page + 1;
      final data = (await context.read<AppState>().api.get('journal', query: {'page': '$next'})) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        if (reset) _entries.clear();
        _entries.addAll(((data['entries'] as List?) ?? const []).cast<Map<String, dynamic>>());
        _twoWeeks = ((data['last_two_weeks'] as List?) ?? const []).cast<Map<String, dynamic>>();
        _page = next;
        _hasMore = data['has_more'] == true;
        _loadedOnce = true;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
      if (_loadedOnce) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _openEntry([Map<String, dynamic>? entry]) async {
    final changed = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => JournalEntryScreen(entry: entry)));
    if (changed == true && mounted) context.read<AppState>().dataChanged();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Journal'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: TextButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProgressScreen())),
              icon: const Icon(Icons.insights_rounded),
              label: const Text('My progress'),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEntry(),
        backgroundColor: Mw.teal,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New entry'),
      ),
      body: !_loadedOnce && _error != null
          ? ErrorView(message: _error!.message, onRetry: reload)
          : !_loadedOnce
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: reload,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                    children: [
                      _moodStrip(),
                      if (_entries.isEmpty)
                        const EmptyState(
                          icon: Icons.book_outlined,
                          title: 'Your journal is empty',
                          text: 'Note how you feel each day. It only takes a moment and stays private unless you choose to share it.',
                        ),
                      for (final e in _entries) _entryCard(e),
                      if (_hasMore)
                        Center(
                          child: TextButton(onPressed: _loading ? null : () => _fetch(), child: Text(_loading ? 'Loading…' : 'Show older entries')),
                        ),
                    ],
                  ),
                ),
    );
  }

  Widget _moodStrip() {
    final byDate = {for (final d in _twoWeeks) '${d['date']}': (d['mood'] as num?)?.toInt()};
    final today = DateTime.now();
    final days = List.generate(14, (i) => DateTime(today.year, today.month, today.day).subtract(Duration(days: 13 - i)));
    String key(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Your mood, last 2 weeks', style: TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (final d in days)
                Column(
                  children: [
                    Container(
                      width: 16,
                      height: 16,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: byDate[key(d)] != null ? Mw.moods[byDate[key(d)]] : Colors.transparent,
                        border: byDate[key(d)] != null ? null : Border.all(color: Mw.line, width: 1.5),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(weekdayShort(d).substring(0, 1), style: const TextStyle(color: Mw.ink300, fontSize: 10.5)),
                  ],
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _entryCard(Map<String, dynamic> e) {
    final at = parseDate(e['created_at']);
    final mood = (e['mood'] as num?)?.toInt();
    final session = e['session'] as Map?;
    final body = '${e['body'] ?? ''}'.trim();

    return MwCard(
      onTap: () => _openEntry(e),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (mood != null) ...[
                Container(width: 12, height: 12, decoration: BoxDecoration(color: Mw.moods[mood], shape: BoxShape.circle)),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Text(
                  session != null
                      ? 'Notes · session with ${session['therapist_name'] ?? 'your therapist'}'
                      : (e['mood_label'] ?? kMoodLabels[mood] ?? 'Entry').toString(),
                  style: const TextStyle(fontWeight: FontWeight.w800, color: Mw.ink900),
                ),
              ),
              if (at != null) Text('${fmtRelativeDay(at)} · ${fmtTime(at)}', style: const TextStyle(color: Mw.ink300, fontSize: 12)),
            ],
          ),
          if (body.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(body, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Mw.ink700, height: 1.4)),
          ],
          if (e['shared_with_therapist'] == true) ...[
            const SizedBox(height: 8),
            const Pill('Shared with your therapist'),
          ],
        ],
      ),
    );
  }
}
