import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

/// Notification settings (PUT me/notifications) — email / SMS and the number for SMS.
/// Same wording as the website's settings page.
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late final Map<String, dynamic> _u = context.read<AppState>().user ?? const {};
  late final _phone = TextEditingController(text: '${_u['phone'] ?? ''}');
  late bool _email = _u['notify_email'] != false;
  late bool _sms = _u['notify_sms'] == true;
  bool _saving = false;
  String? _error;
  String? _phoneError;

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _error = null;
      _phoneError = null;
    });
    final app = context.read<AppState>();
    try {
      final res = await app.api.put('me/notifications', {
        'phone': _phone.text.trim().isEmpty ? null : _phone.text.trim(),
        'notify_email': _email,
        'notify_sms': _sms,
      });
      if (!mounted) return;
      app.applyUserResponse(res);
      Navigator.pop(context);
      showSnack(context, (res is Map && res['message'] is String) ? res['message'] as String : 'Saved.');
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _phoneError = e.fieldError('phone');
          _error = _phoneError == null ? e.message : null;
        });
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          MwCard(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Column(
              children: [
                SwitchListTile(
                  value: _email,
                  onChanged: (v) => setState(() => _email = v),
                  title: const Text('Email', style: TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('Confirmations, reminders and new-message alerts, sent to ${_u['email'] ?? 'your email'}.'),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  value: _sms,
                  onChanged: (v) => setState(() => _sms = v),
                  title: const Text('SMS', style: TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: const Text('Only the time-sensitive ones: confirmations, reminders, and "your appointment is ready". New messages are email only.'),
                ),
              ],
            ),
          ),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              labelText: 'Mobile number for SMS',
              hintText: 'e.g. 0772123456',
              helperText: "MTN or Airtel Uganda. Leave empty if you don't want text messages.",
              errorText: _phoneError,
            ),
          ),
          const SizedBox(height: 14),
          const Text('We keep these messages discreet. They only say "your appointment" or "a new message", never what it is about.',
              style: TextStyle(color: Mw.ink500, fontSize: 12.5)),
          const SizedBox(height: 16),
          if (_error != null) NoticeBox(text: _error!),
          PrimaryButton(label: 'Save', busy: _saving, onPressed: _save),
        ],
      ),
    );
  }
}
