import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/rate_sheet.dart';
import '../pay/checkout_screen.dart';
import '../video/room_screen.dart';
import 'change_request_screen.dart';
import 'lobby_screen.dart';
import 'session_flow.dart';

/// One session (GET sessions/{id}): when, with whom, where — and the one thing to do
/// next (pay, wait, join the video, find the place, rate it). While a video session is
/// waiting to open, it re-checks every 15 seconds so Join appears by itself.
class SessionDetailScreen extends StatefulWidget {
  const SessionDetailScreen({super.key, required this.sessionId});

  final String sessionId;

  @override
  State<SessionDetailScreen> createState() => _SessionDetailScreenState();
}

class _SessionDetailScreenState extends State<SessionDetailScreen> {
  Map<String, dynamic>? _s;
  ApiException? _error;
  Timer? _timer;
  bool _withdrawing = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      final join = _s?['join'] as Map?;
      if (join != null && join['state'] == 'too_early') _load(quiet: true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool quiet = false}) async {
    if (!quiet) setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('sessions/${widget.sessionId}')) as Map<String, dynamic>;
      if (mounted) setState(() => _s = data['session'] as Map<String, dynamic>);
    } on ApiException catch (e) {
      if (mounted && !quiet) setState(() => _error = e);
    }
  }

  Future<void> _push(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _load();
  }

  Future<void> _withdraw(String id) async {
    final ok = await confirmDialog(context, title: 'Withdraw your request?', body: 'Your session stays as it is.', yes: 'Withdraw');
    if (!ok || !mounted) return;
    setState(() => _withdrawing = true);
    final app = context.read<AppState>();
    try {
      final res = await app.api.delete('change-requests/$id');
      if (!mounted) return;
      app.dataChanged();
      showSnack(context, (res is Map && res['message'] is String) ? res['message'] as String : 'Request withdrawn.');
      _load();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _withdrawing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return Scaffold(
      appBar: AppBar(title: const Text('Session')),
      body: _error != null && s == null
          ? ErrorView(message: _error!.message, onRetry: _load)
          : s == null
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                    children: [
                      _header(s),
                      ..._next(s),
                      ..._changeRequest(s),
                      ..._details(s),
                    ],
                  ),
                ),
    );
  }

  Widget _header(Map<String, dynamic> s) {
    final t = s['therapist'] as Map<String, dynamic>?;
    final at = parseDate(s['scheduled_at']);
    final end = parseDate(s['ends_at']);
    return MwCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              t != null
                  ? Avatar(name: '${t['name']}', size: 54, photoUrl: t['photo_url'] as String?)
                  : Container(
                      width: 54,
                      height: 54,
                      decoration: const BoxDecoration(color: Mw.tealTint, shape: BoxShape.circle),
                      child: const Icon(Icons.person_search_rounded, color: Mw.teal),
                    ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t != null ? '${t['name']}' : 'Therapist to be matched',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Mw.ink900)),
                    if (t?['title'] != null) Text('${t!['title']}', style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                    const SizedBox(height: 6),
                    Pill.forStatus(s['status'] as String?, '${s['status_label'] ?? ''}'),
                  ],
                ),
              ),
            ],
          ),
          const Divider(height: 28),
          _row(Icons.event_rounded, at != null ? fmtDayLong(at) : 'Time to be confirmed'),
          if (at != null) _row(Icons.schedule_rounded, fmtTimeRange(at, end)),
          _row(s['mode'] == 'in_person' ? Icons.place_outlined : Icons.videocam_outlined, modeLine(s)),
          if (s['session_number'] != null) _row(Icons.tag_rounded, 'Session ${s['session_number']}'),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Icon(icon, size: 19, color: Mw.teal),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: const TextStyle(color: Mw.ink700, fontWeight: FontWeight.w600))),
          ],
        ),
      );

  List<Widget> _next(Map<String, dynamic> s) {
    final currency = '${context.read<AppState>().config?['currency'] ?? 'UGX'}';
    final therapistName = '${(s['therapist'] as Map?)?['name'] ?? 'your therapist'}';

    switch (s['next_step']) {
      case 'checkout':
        return [
          _action(
            title: 'Waiting for payment',
            text: s['price'] != null ? 'Pay ${money(s['price'], currency)} to confirm this session.' : 'Pay to confirm this session.',
            button: PrimaryButton(label: 'Pay now', onPressed: () => _push(CheckoutScreen(sessionId: '${s['id']}'))),
          ),
        ];
      case 'lobby':
        return [
          _action(
            title: "We're finding your therapist",
            text: 'Open the waiting room to see how it\'s going.',
            button: PrimaryButton(label: 'Open waiting room', onPressed: () => _push(LobbyScreen(sessionId: '${s['id']}'))),
          ),
        ];
      case 'awaiting_approval':
        return [
          _action(
            title: 'Waiting for confirmation',
            text: 'You have booked this time. Our team will confirm it and let you know, usually the same day.',
          ),
        ];
      case 'video':
        final join = (s['join'] as Map?) ?? const {};
        final opens = parseDate(join['opens_at']);
        final live = join['therapist_in_room'] == true;
        switch (join['state']) {
          case 'open':
            return [
              _action(
                title: live ? '$therapistName is in the room' : 'Your room is open',
                text: live ? 'Join now. They are ready for you.' : 'You can join now. $therapistName will be with you at the start time.',
                highlight: true,
                button: PrimaryButton(
                  label: 'Join session',
                  color: Mw.orange,
                  onPressed: () => _push(RoomScreen(sessionId: '${s['id']}')),
                ),
              ),
            ];
          case 'too_early':
            return [
              _action(
                title: 'Video session',
                text: opens != null
                    ? 'You can join from ${_dayWord(opens)} at ${fmtTime(opens)}, or earlier if $therapistName opens the room. This page updates by itself.'
                    : 'The room opens shortly before your session.',
                button: OutlinedButton.icon(
                  onPressed: () => _push(RoomScreen(sessionId: '${s['id']}')),
                  icon: const Icon(Icons.videocam_outlined),
                  label: const Text('Go to the room'),
                ),
              ),
            ];
          default:
            return [_action(title: 'Video window closed', text: "This session's video window has ended.")];
        }
      case 'in_person':
        final loc = (s['location'] as Map?) ?? const {};
        final venue = loc['venue'] as Map?;
        return [
          MwCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Where', style: TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
                const SizedBox(height: 6),
                Text('${loc['text'] ?? 'Place to be confirmed by our team'}', style: const TextStyle(color: Mw.ink700, height: 1.45)),
                if (venue?['address'] != null) ...[
                  const SizedBox(height: 4),
                  Text('${venue!['address']}', style: const TextStyle(color: Mw.ink500)),
                ],
                if (venue?['directions'] != null) ...[
                  const SizedBox(height: 8),
                  Text('${venue!['directions']}', style: const TextStyle(color: Mw.ink500, fontSize: 13, height: 1.45)),
                ],
                if (venue?['map_url'] != null || venue?['phone'] != null) ...[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    children: [
                      if (venue?['map_url'] != null)
                        OutlinedButton.icon(
                          onPressed: () => openLink(context, '${venue!['map_url']}'),
                          icon: const Icon(Icons.map_outlined),
                          label: const Text('Map'),
                        ),
                      if (venue?['phone'] != null)
                        OutlinedButton.icon(
                          onPressed: () => callNumber(context, '${venue!['phone']}'.replaceAll(' ', '')),
                          icon: const Icon(Icons.call_outlined),
                          label: const Text('Call'),
                        ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ];
      case 'completed':
        return [
          if (s['can_rate'] == true)
            _action(
              title: 'How was your session?',
              text: 'It takes a few seconds and helps us look after you.',
              button: OutlinedButton.icon(
                onPressed: () async {
                  final sent = await showRateSheet(context, sessionId: '${s['id']}', therapistName: therapistName);
                  if (sent && mounted) _load();
                },
                icon: const Icon(Icons.star_outline_rounded, color: Mw.gold),
                label: const Text('Rate it'),
              ),
            ),
        ];
      default:
        return const [];
    }
  }

  List<Widget> _changeRequest(Map<String, dynamic> s) {
    final cr = s['change_request'] as Map?;
    if (cr != null) {
      final mine = cr['mine'] == true;
      final at = parseDate(cr['proposed_at']);
      final what = cr['type'] == 'cancel'
          ? 'cancel this session'
          : (at != null ? 'move it to ${fmtDayLong(at)} at ${fmtTime(at)}' : 'move it');
      return [
        MwBanner(
          kind: MwBannerKind.info,
          title: mine ? 'You asked to $what' : 'A change to this session is being arranged',
          text: 'Your session stays as it is until we confirm. We will let you know.',
          actions: [
            if (mine)
              MwPillButton(
                label: 'Withdraw my request',
                onPressed: _withdrawing ? null : () => _withdraw('${cr['id']}'),
              ),
          ],
        ),
      ];
    }
    if (s['can_change'] == true) {
      return [
        Center(
          child: TextButton.icon(
            onPressed: () => _push(ChangeRequestScreen(session: s)),
            icon: const Icon(Icons.edit_calendar_outlined),
            label: const Text('Move or cancel this session'),
          ),
        ),
        const SizedBox(height: 8),
      ];
    }
    return const [];
  }

  List<Widget> _details(Map<String, dynamic> s) {
    final currency = '${context.read<AppState>().config?['currency'] ?? 'UGX'}';
    final method = switch (s['payment_method']) {
      'employer_seat' => 'Covered by your employer',
      'credit' => 'From your plan',
      'one_off' => 'Paid',
      null => null,
      final other => '$other'.replaceAll('_', ' '),
    };
    if (method == null && s['amount_charged'] == null) return const [];
    return [
      const SectionTitle('Payment'),
      MwCard(
        child: Row(
          children: [
            const Icon(Icons.receipt_long_outlined, color: Mw.teal),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                [
                  if (method != null) method,
                  if (s['amount_charged'] != null) money(s['amount_charged'], currency),
                ].join(' · '),
                style: const TextStyle(color: Mw.ink700, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  String _dayWord(DateTime d) {
    final w = fmtRelativeDay(d);
    return (w == 'Today' || w == 'Tomorrow') ? w.toLowerCase() : w;
  }

  Widget _action({required String title, required String text, Widget? button, bool highlight = false}) {
    return MwCard(
      color: highlight ? MwBanner.surface : Colors.white,
      borderColor: highlight ? MwBanner.surface : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, color: Mw.ink900)),
          const SizedBox(height: 4),
          Text(text, style: const TextStyle(color: Mw.ink700, height: 1.45)),
          if (button != null) ...[
            const SizedBox(height: 12),
            button,
          ],
        ],
      ),
    );
  }
}
