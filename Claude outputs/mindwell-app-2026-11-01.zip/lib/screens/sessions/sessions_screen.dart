import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/reload_on_change.dart';
import '../intake/intake_screen.dart';
import '../therapists/therapists_screen.dart';
import 'session_flow.dart';

/// Sessions tab — upcoming (incl. waiting for payment / matching / confirmation) and
/// past, from GET sessions. "Book" opens the therapist list.
class SessionsScreen extends StatefulWidget {
  const SessionsScreen({super.key});

  @override
  State<SessionsScreen> createState() => _SessionsScreenState();
}

class _SessionsScreenState extends State<SessionsScreen> with ReloadOnChange<SessionsScreen> {
  List<Map<String, dynamic>>? _upcoming;
  List<Map<String, dynamic>> _past = const [];
  ApiException? _error;
  bool _showPast = false;

  @override
  void initState() {
    super.initState();
    reload();
  }

  @override
  Future<void> reload() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('sessions')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _upcoming = ((data['upcoming'] as List?) ?? const []).cast<Map<String, dynamic>>();
        _past = ((data['past'] as List?) ?? const []).cast<Map<String, dynamic>>();
      });
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  void _book() => Navigator.push(context, MaterialPageRoute(builder: (_) => const TherapistsScreen()));

  Future<void> _open(Map<String, dynamic> s) async {
    await openSession(context, s);
    if (mounted) reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sessions'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: TextButton.icon(onPressed: _book, icon: const Icon(Icons.add_rounded), label: const Text('Book')),
          ),
        ],
      ),
      body: _error != null && _upcoming == null
          ? ErrorView(message: _error!.message, onRetry: reload)
          : _upcoming == null
              ? const LoadingView()
              : RefreshIndicator(onRefresh: reload, child: _list()),
    );
  }

  Widget _list() {
    final upcoming = _upcoming!;
    if (upcoming.isEmpty && _past.isEmpty) {
      return ListView(
        children: [
          EmptyState(
            icon: Icons.event_note_rounded,
            title: 'No sessions yet',
            text: 'Answer a few short questions and we will match you with a therapist, or choose one yourself.',
            actions: [
              ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IntakeScreen())),
                child: const Text('Get matched'),
              ),
              OutlinedButton(onPressed: _book, child: const Text('Choose a therapist')),
            ],
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        const SectionTitle('Upcoming'),
        if (upcoming.isEmpty)
          MwCard(
            child: Row(
              children: [
                const Expanded(child: Text('Nothing booked right now.', style: TextStyle(color: Mw.ink500))),
                TextButton(onPressed: _book, child: const Text('Book a session')),
              ],
            ),
          ),
        for (final s in upcoming) _SessionTile(session: s, onTap: () => _open(s)),
        if (_past.isNotEmpty) ...[
          const SizedBox(height: 6),
          InkWell(
            onTap: () => setState(() => _showPast = !_showPast),
            child: Row(
              children: [
                Expanded(child: SectionTitle('Past (${_past.length})')),
                Icon(_showPast ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: Mw.ink500),
              ],
            ),
          ),
          if (_showPast) for (final s in _past) _SessionTile(session: s, onTap: () => _open(s), past: true),
        ],
      ],
    );
  }
}

class _SessionTile extends StatelessWidget {
  const _SessionTile({required this.session, required this.onTap, this.past = false});

  final Map<String, dynamic> session;
  final VoidCallback onTap;
  final bool past;

  @override
  Widget build(BuildContext context) {
    final s = session;
    final t = s['therapist'] as Map<String, dynamic>?;
    final at = parseDate(s['scheduled_at']);
    final name = t != null ? '${t['name']}' : null;

    final title = at != null ? '${fmtRelativeDay(at)} · ${fmtTime(at)}' : (s['status_label'] ?? 'Session').toString();
    final sub = [
      if (name != null) 'With $name' else if (s['next_step'] == 'lobby' || s['next_step'] == 'checkout') 'Therapist to be matched',
      modeLine(s),
    ].join(' · ');

    return MwCard(
      onTap: onTap,
      child: Row(
        children: [
          name != null
              ? Avatar(name: name, size: 44, photoUrl: t?['photo_url'] as String?)
              : Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(color: Mw.tealTint, shape: BoxShape.circle),
                  child: const Icon(Icons.hourglass_top_rounded, color: Mw.teal, size: 22),
                ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: past ? Mw.ink700 : Mw.ink900)),
                const SizedBox(height: 2),
                Text(sub, style: const TextStyle(color: Mw.ink500, fontSize: 12.5)),
                const SizedBox(height: 6),
                Pill.forStatus(s['status'] as String?, '${s['status_label'] ?? ''}'),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: Mw.ink300),
        ],
      ),
    );
  }
}
