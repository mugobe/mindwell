import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../therapists/therapists_screen.dart';
import 'session_flow.dart';

/// The waiting room while we find a therapist — like the website's lobby. Polls
/// GET sessions/{id}/lobby every 5 seconds (each poll is also one matching attempt) and
/// moves on by itself once the session is placed. After the target wait, offers
/// "Browse therapists instead" (POST stop-waiting).
class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key, required this.sessionId});

  final String sessionId;

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  static const _lines = [
    'This is a private session. Only you and your therapist will be in the room.',
    'If you can, find a quiet place where you will not be disturbed.',
    'Headphones help you hear better, if you have them.',
    'A stable connection helps, but it does not need to be perfect.',
    'There is no right way to start. Say whatever is on your mind.',
    'We are looking for a therapist who is free now.',
    'You do not need the right words. Come as you are.',
  ];

  Timer? _poll;
  Timer? _tick;
  int _line = 0;
  int _seconds = 0;
  bool _busy = false;
  bool _stopping = false;

  Map<String, dynamic>? _session;
  DateTime? _waitingSince;
  int _targetMinutes = 10;
  String? _note;

  @override
  void initState() {
    super.initState();
    _check();
    _poll = Timer.periodic(const Duration(seconds: 5), (_) => _check());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _seconds++;
        if (_seconds % 7 == 0) _line = (_line + 1) % _lines.length;
      });
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    super.dispose();
  }

  Future<void> _check() async {
    if (_busy || _stopping) return;
    _busy = true;
    try {
      final res = (await context.read<AppState>().api.get('sessions/${widget.sessionId}/lobby')) as Map<String, dynamic>;
      if (!mounted) return;
      final s = res['session'] as Map<String, dynamic>;
      setState(() {
        _session = s;
        _waitingSince = parseDate(res['waiting_since']);
        _targetMinutes = (res['target_minutes'] as num?)?.toInt() ?? 10;
        _note = null;
      });
      if (s['next_step'] != 'lobby') _moveOn(s);
    } on ApiException catch (e) {
      if (mounted) setState(() => _note = e.isOffline ? 'Waiting for a connection…' : e.message);
    } finally {
      _busy = false;
    }
  }

  void _moveOn(Map<String, dynamic> s) {
    _poll?.cancel();
    final app = context.read<AppState>();
    app.dataChanged();
    if (s['status'] == 'cancelled') {
      setState(() {}); // shows the "no longer waiting" view
      return;
    }
    if (s['next_step'] == 'video' || s['next_step'] == 'in_person') {
      final name = (s['therapist'] as Map?)?['name'];
      showSnack(context, name != null ? "You're matched with $name." : "You're matched.");
    }
    openSession(context, s, replace: true);
  }

  Future<void> _stopWaiting() async {
    // Pause polling while the question is open, so a match can't land underneath it.
    setState(() => _stopping = true);
    final ok = await confirmDialog(
      context,
      title: 'Choose a therapist yourself?',
      body: "We'll stop looking for you and you can pick a therapist and a time that suits you.",
      yes: 'Browse therapists',
    );
    if (!mounted) return;
    if (!ok) {
      setState(() => _stopping = false);
      return;
    }
    final app = context.read<AppState>();
    try {
      final res = (await app.api.post('sessions/${widget.sessionId}/stop-waiting')) as Map<String, dynamic>;
      if (!mounted) return;
      app.dataChanged();
      final s = res['session'] as Map<String, dynamic>;
      if (s['status'] == 'cancelled') {
        _poll?.cancel();
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const TherapistsScreen()));
        showSnack(context, 'No problem. Choose a therapist and a time that suits you.');
      } else {
        // Matched in the meantime: better matched than cancelled by a stray tap.
        _moveOn(s);
      }
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _stopping = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cancelled = _session?['status'] == 'cancelled';
    final waited = _waitingSince == null ? Duration(seconds: _seconds) : DateTime.now().difference(_waitingSince!);
    final longWait = waited.inMinutes >= _targetMinutes;

    return Scaffold(
      appBar: AppBar(title: const Text('Finding your therapist')),
      body: cancelled
          ? Center(
              child: EmptyState(
                icon: Icons.event_busy_rounded,
                title: 'This request was stopped',
                text: 'You can choose a therapist and time yourself.',
                actions: [
                  ElevatedButton(
                    onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const TherapistsScreen())),
                    child: const Text('Choose a therapist'),
                  ),
                ],
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 28),
              children: [
                const Center(child: _Breathing()),
                const SizedBox(height: 22),
                const Center(child: Pill('Finding a specialist…')),
                const SizedBox(height: 14),
                Text(
                  _session == null ? 'One moment…' : "We're matching you with the right therapist",
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Mw.ink900),
                ),
                const SizedBox(height: 6),
                Text(
                  'Usually within $_targetMinutes minutes · waiting ${_fmtWait(waited)}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Mw.ink500, fontSize: 13.5),
                ),
                const SizedBox(height: 22),
                MwCard(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 500),
                    child: Text(
                      '“${_lines[_line]}”',
                      key: ValueKey(_line),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15.5, color: Mw.ink700, fontStyle: FontStyle.italic, height: 1.5),
                    ),
                  ),
                ),
                if (_note != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(_note!, textAlign: TextAlign.center, style: const TextStyle(color: Mw.ink500, fontSize: 13)),
                  ),
                if (longWait) ...[
                  const Text(
                    'This is taking a little longer than usual. You can keep waiting while we keep looking, '
                    'or you can choose a therapist and a time yourself.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Mw.ink700, fontSize: 13.5, height: 1.45),
                  ),
                  const SizedBox(height: 12),
                  Center(
                    child: OutlinedButton(
                      onPressed: _stopping ? null : _stopWaiting,
                      child: const Text('Browse therapists instead'),
                    ),
                  ),
                ],
                const SizedBox(height: 18),
                const Text(
                  'You can leave this screen. We will keep looking, and your session will show in Sessions once you are matched.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Mw.ink300, fontSize: 12.5),
                ),
              ],
            ),
    );
  }

  String _fmtWait(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return m == 0 ? '${s}s' : '${m}m ${s.toString().padLeft(2, '0')}s';
  }
}

/// A slow breathing circle (4s in, 4s out).
class _Breathing extends StatefulWidget {
  const _Breathing();

  @override
  State<_Breathing> createState() => _BreathingState();
}

class _BreathingState extends State<_Breathing> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final t = Curves.easeInOut.transform(_c.value);
        return Container(
          width: 150,
          height: 150,
          alignment: Alignment.center,
          decoration: BoxDecoration(shape: BoxShape.circle, color: Mw.tealTint.withValues(alpha: .6)),
          child: Container(
            width: 70 + 60 * t,
            height: 70 + 60 * t,
            decoration: const BoxDecoration(shape: BoxShape.circle, color: Mw.teal),
            alignment: Alignment.center,
            child: Text(_c.status == AnimationStatus.forward ? 'Breathe in' : 'Breathe out',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5)),
          ),
        );
      },
    );
  }
}
