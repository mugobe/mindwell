/* Mindwell Consultancy Ltd website.
 *
 * EDIT HERE: settings used across every page.
 *  - portal:    the Mindwell client portal (online booking, log in). Every link with
 *               data-portal="/register" etc. points at this address.
 *  - email:     where the contact form and email links go.
 *  - playStore: the Google Play link once the app is published (empty = "Coming soon").
 *  - appStore:  the iPhone app link, later.
 */
var MINDWELL = {
    portal: 'https://mindwell.insight360apps.net',
    email: 'care@mindwell.com',
    playStore: '',
    appStore: ''
};

(function () {
    var base = MINDWELL.portal.replace(/\/+$/, '');

    document.querySelectorAll('[data-portal]').forEach(function (a) {
        a.setAttribute('href', base + a.getAttribute('data-portal'));
    });

    document.querySelectorAll('[data-email]').forEach(function (a) {
        var subject = a.getAttribute('data-email');
        a.setAttribute('href', 'mailto:' + MINDWELL.email + (subject ? '?subject=' + encodeURIComponent(subject) : ''));
        if (a.hasAttribute('data-email-text')) a.textContent = MINDWELL.email;
    });

    document.querySelectorAll('[data-store]').forEach(function (a) {
        var url = MINDWELL[a.getAttribute('data-store')];
        if (url) {
            a.setAttribute('href', url);
            a.classList.remove('soon');
            var s = a.querySelector('small');
            if (s) s.textContent = a.getAttribute('data-store') === 'playStore' ? 'Get it on' : 'Download on the';
        } else {
            a.setAttribute('aria-disabled', 'true');
            a.addEventListener('click', function (e) { e.preventDefault(); });
        }
    });

    var y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();

    // Phone menu and the Services dropdown.
    var btn = document.querySelector('.menu-btn');
    var nav = document.getElementById('nav');
    if (btn && nav) {
        btn.addEventListener('click', function () {
            var open = nav.classList.toggle('open');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }
    document.querySelectorAll('.dd > button').forEach(function (b) {
        b.addEventListener('click', function () {
            var dd = b.parentElement;
            var open = dd.classList.toggle('open');
            b.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    });
    document.addEventListener('click', function (e) {
        document.querySelectorAll('.dd.open').forEach(function (dd) {
            if (!dd.contains(e.target) && !(nav && nav.classList.contains('open'))) dd.classList.remove('open');
        });
    });

    // Contact form: opens the visitor's email app with the message filled in.
    var form = document.getElementById('enquiry');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var f = form.elements;
            var subject = 'Enquiry: ' + f.topic.value;
            var body = [
                'Name: ' + f.name.value,
                'Phone: ' + f.phone.value,
                'Email: ' + f.email.value,
                'About: ' + f.topic.value,
                'Best way to reach me: ' + f.reach.value,
                '',
                f.message.value
            ].join('\n');
            window.location.href = 'mailto:' + MINDWELL.email + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
            var done = document.getElementById('enquiry-done');
            if (done) done.hidden = false;
        });
    }

    // Gentle fade-in as sections scroll into view.
    var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!calm && 'IntersectionObserver' in window) {
        document.documentElement.classList.add('js-motion');
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
        }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
        document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
    }
})();
