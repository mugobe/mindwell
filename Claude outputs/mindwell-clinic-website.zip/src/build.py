"""Builds the Mindwell Consultancy Ltd website (static HTML) into ../site.

Every page shares the same header, footer and help band, so they live here once.
Run:  python3 build.py
Text still to confirm is wrapped in <span class="placeholder">.
"""
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / 'site'
PORTAL = 'https://mindwell.insight360apps.net'  # also set in assets/js/site.js

ICON = {
    'person': '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.4-3.6 4.4-5.5 7.5-5.5s6.1 1.9 7.5 5.5"/>',
    'couple': '<circle cx="8.5" cy="8.5" r="3"/><circle cx="16" cy="9.5" r="2.6"/><path d="M3 19.5c.9-3 3-4.6 5.5-4.6s4.6 1.6 5.5 4.6"/><path d="M14.5 14.6c2.6-.2 4.9 1.3 5.8 4.4"/>',
    'building': '<rect x="4" y="3" width="10" height="18" rx="1"/><path d="M14 9h5a1 1 0 011 1v11h-6"/><path d="M7.5 7h3M7.5 11h3M7.5 15h3"/>',
    'video': '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>',
    'shield': '<path d="M12 3l7 3v5c0 4.5-3 8-7 9-4-1-7-4.5-7-9V6l7-3z"/><path d="M9 12.5l2 2 4-4.5"/>',
    'lock': '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
    'pin': '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0119 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    'phone': '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2"/>',
    'mail': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    'clock': '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    'mobile': '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M11 18.5h2"/>',
    'leaf': '<path d="M5 19c8 0 14-6 14-14-8 0-14 6-14 14z"/><path d="M5 19l7-7"/>',
    'chat': '<path d="M4 5.5h16a1 1 0 011 1v9a1 1 0 01-1 1H10l-4.5 3.5V16.5H4a1 1 0 01-1-1v-9a1 1 0 011-1z"/>',
    'book': '<path d="M4 5.5A2.5 2.5 0 016.5 3H20v15H6.5A2.5 2.5 0 004 20.5z"/><path d="M4 20.5A2.5 2.5 0 016.5 18H20v3H6.5"/>',
    'heart': '<path d="M12 20.5s-7.5-4.6-7.5-10.2A4.3 4.3 0 0112 7.6a4.3 4.3 0 017.5 2.7c0 5.6-7.5 10.2-7.5 10.2z"/>',
    'chart': '<path d="M4 19h16"/><path d="M5 15l4-4 3 3 6-6"/><path d="M15 8h3v3"/>',
    'calendar': '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 9h16M8 3v4M16 3v4"/>',
    'users': '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c1-3.3 3.4-5 6-5s5 1.7 6 5"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14.6c2.2.2 3.9 1.7 5 4.4"/>',
    'camera': '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
}


def ic(name, size=None):
    s = f' style="width:{size}px;height:{size}px"' if size else ''
    return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"{s}>{ICON[name]}</svg>'


def photo(label, cls='', file_hint=''):
    """Labelled frame for a real photo. Replace the inner <div class="ph"> with <img>."""
    hint = f'<!-- Photo: put assets/img/{file_hint} here: <img src="assets/img/{file_hint}" alt="{label}"> -->' if file_hint else ''
    return f'<div class="photo {cls}">{hint}<div class="ph">{ic("camera")}<span>Photo: {label}</span></div></div>'


def P(text):
    return f'<span class="placeholder">{text}</span>'


SERVICES = [
    ('individual-therapy.html', 'Individual therapy', 'person', 'One-to-one counselling for adults facing stress, anxiety, low mood, grief, trauma or big life changes.'),
    ('couples-and-family.html', 'Couples and family', 'couple', 'Support for partners and families to talk openly, work through conflict and rebuild trust.'),
    ('corporate-wellness.html', 'Corporate wellness', 'building', 'Confidential staff counselling, workshops and training that help organisations look after their people.'),
    ('online-sessions.html', 'Online sessions', 'video', 'See your therapist by secure video from home or work, using the Mindwell client portal.'),
]


def head(title, desc, current):
    def a(href, label, key):
        cur = ' aria-current="page"' if key == current else ''
        return f'<a href="{href}"{cur}>{label}</a>'
    svc_cur = ' current' if current == 'services' else ''
    short = {
        'individual-therapy.html': 'For adults, one to one',
        'couples-and-family.html': 'For partners and families',
        'corporate-wellness.html': 'For organisations and staff',
        'online-sessions.html': 'Secure video sessions',
    }
    menu = ''.join(f'<a href="{f}">{n}<small>{short[f]}</small></a>' for f, n, _, _ in SERVICES)
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<meta name="theme-color" content="#0B7A5E">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:image" content="assets/img/mindwell-logo.png">
<link rel="icon" href="favicon.ico">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="preload" href="assets/fonts/source-serif-4-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="assets/fonts/plus-jakarta-sans-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="assets/css/site.css">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<div class="topbar">
    <div class="wrap">
        <div class="items">
            <span class="hide-sm">{P("Plot and street")}, Ntinda, Kampala</span>
            <span>Call {P("+256 7XX XXX XXX")}</span>
            <a data-email="" data-email-text href="mailto:care@mindwell.com">care@mindwell.com</a>
        </div>
        <span class="emerg">In an emergency call <a href="tel:112">999 or 112</a></span>
    </div>
</div>
<header class="site-head">
    <div class="wrap head-in">
        <a class="brand" href="index.html" aria-label="Mindwell Consultancy Ltd, home"><img src="assets/img/mindwell-logo-horizontal.png" alt="Mindwell Consultancy Ltd" width="174" height="52"></a>
        <nav class="nav" id="nav" aria-label="Main">
            {a("index.html", "Home", "home")}
            {a("about.html", "About us", "about")}
            <div class="dd{svc_cur}">
                <button type="button" aria-expanded="false">Services <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>
                <div class="dd-menu">
                    <a href="services.html">All services and fees<small>Overview</small></a>
                    <hr>
                    {menu}
                </div>
            </div>
            {a("contact.html", "Contact", "contact")}
            <a data-portal="/login" href="{PORTAL}/login">Client log in</a>
            <a class="btn btn-primary mobile-cta" href="contact.html#book">Book an appointment</a>
        </nav>
        <a class="btn btn-primary head-cta" href="contact.html#book">Book an appointment</a>
        <button class="menu-btn" type="button" aria-label="Menu" aria-expanded="false" aria-controls="nav">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
        </button>
    </div>
</header>
<main id="main">
'''


def help_band():
    return f'''
<section class="help" aria-labelledby="help-title">
    <div class="wrap">
        <div class="txt">
            <h2 id="help-title">If you need help right now</h2>
            <p>Mindwell is not an emergency service. If you or someone else is in danger, call for help now.</p>
        </div>
        <div class="nums">
            <a href="tel:112"><b>999 or 112</b><span>Emergency, any time</span></a>
            <a href="tel:+256800212121"><b>0800 21 21 21</b><span>Mental Health Uganda, toll-free, weekdays</span></a>
            <a data-portal="/urgent-help" href="{PORTAL}/urgent-help"><b>More numbers</b><span>Our urgent help page</span></a>
        </div>
    </div>
</section>'''


def book_band(title='Ready to talk to someone?', text='Book an appointment online, or call us and we will help you find a time.'):
    return f'''
<section class="book-band">
    <div class="wrap">
        <div>
            <h2>{title}</h2>
            <p>{text}</p>
        </div>
        <div class="cta-row">
            <a class="btn btn-white" href="contact.html#book">Book an appointment</a>
            <a class="btn btn-line-white" href="contact.html">Contact us</a>
        </div>
    </div>
</section>'''


def foot():
    return f'''
</main>
{help_band()}
<footer class="foot">
    <div class="wrap">
        <div class="foot-grid">
            <div>
                <img src="assets/img/mindwell-logo-horizontal-white.png" alt="Mindwell Consultancy Ltd" width="168" height="50">
                <p>Professional, confidential counselling and psychotherapy for individuals, couples, families and organisations in Uganda.</p>
                <div class="tagline">HEAL &nbsp;&bull;&nbsp; GROW &nbsp;&bull;&nbsp; THRIVE</div>
            </div>
            <div>
                <h4>Services</h4>
                <ul>
                    <li><a href="individual-therapy.html">Individual therapy</a></li>
                    <li><a href="couples-and-family.html">Couples and family</a></li>
                    <li><a href="corporate-wellness.html">Corporate wellness</a></li>
                    <li><a href="online-sessions.html">Online sessions</a></li>
                    <li><a href="services.html#fees">Fees</a></li>
                </ul>
            </div>
            <div>
                <h4>Mindwell</h4>
                <ul>
                    <li><a href="about.html">About us</a></li>
                    <li><a href="about.html#team">Our team</a></li>
                    <li><a href="contact.html">Contact and booking</a></li>
                    <li><a data-portal="/login" href="{PORTAL}/login">Client log in</a></li>
                    <li><a data-portal="/register/therapist" href="{PORTAL}/register/therapist">Work with us</a></li>
                </ul>
            </div>
            <div>
                <h4>Visit or call</h4>
                <ul>
                    <li>{P("Plot and street")}, Ntinda, Kampala</li>
                    <li>{P("+256 7XX XXX XXX")}</li>
                    <li><a data-email="" data-email-text href="mailto:care@mindwell.com">care@mindwell.com</a></li>
                    <li><a data-portal="/privacy" href="{PORTAL}/privacy">Privacy Policy</a> &middot; <a data-portal="/terms" href="{PORTAL}/terms">Terms</a></li>
                </ul>
            </div>
        </div>
        <div class="foot-bottom">
            <span>&copy; <span id="year">2026</span> Mindwell Consultancy Ltd. All rights reserved.</span>
            <span>Not an emergency service. In an emergency call 999 or 112.</span>
        </div>
    </div>
</footer>
<script src="assets/js/site.js"></script>
</body>
</html>
'''


def page_hero(crumb, title, lead, kicker=''):
    k = f'<span class="eyebrow">{kicker}</span>' if kicker else ''
    return f'''
<section class="page-hero">
    <div class="wrap">
        <ol class="crumbs"><li><a href="index.html">Home</a></li>{crumb}</ol>
        {k}
        <h1>{title}</h1>
        <p class="lead">{lead}</p>
    </div>
</section>'''


def faq(items):
    return '<div class="faq">' + ''.join(f'<details><summary>{q}</summary><div class="ans">{a}</div></details>' for q, a in items) + '</div>'


def online_band():
    return f'''
<div class="online-band reveal">
    <div>
        <h2>Prefer to meet online?</h2>
        <p style="margin:0;">Clients can book, pay and join secure video sessions through the Mindwell client portal. A Mindwell app for Android is on its way.</p>
        <div class="cta-row" style="margin-top:20px;">
            <a class="btn btn-white" href="online-sessions.html">About online sessions</a>
            <a class="btn btn-line-white" data-portal="/register" href="{PORTAL}/register">Create a client account</a>
        </div>
    </div>
    <div class="stores">
        <a class="store soon" data-store="playStore" href="#"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.5 3.3c-.3.3-.5.8-.5 1.4v14.6c0 .6.2 1.1.5 1.4l8.2-8.7-8.2-8.7zm9.4 7.4l2.4-2.5-9.9-5.8c-.4-.2-.8-.3-1.1-.2l8.6 8.5zm0 2.6l-8.6 8.5c.3.1.7 0 1.1-.2l9.9-5.8-2.4-2.5zm3.5-3.8L15 11.8l2.4 2.5 2.6-1.5c.8-.5.8-1.3 0-1.8l-2.6-1.5z"/></svg><span><small>Coming soon</small><b>Google Play</b></span></a>
    </div>
</div>'''


FEES_ROWS = f'''
<tr><td><b>Individual session, in person</b><small>At our Ntinda clinic</small></td><td>UGX 20,000 {P("to confirm")}</td></tr>
<tr><td><b>Individual session, online</b><small>Secure video through the client portal</small></td><td>UGX 15,000 {P("to confirm")}</td></tr>
<tr><td><b>Couples or family session</b><small>In person or online</small></td><td>{P("Fee to confirm")}</td></tr>
<tr><td><b>Session plans</b><small>A set number of sessions each week or month, at a lower cost per session</small></td><td>See plans when you book</td></tr>
<tr><td><b>Corporate wellness</b><small>Staff counselling, workshops and training</small></td><td>Quoted for your organisation</td></tr>'''


def fees_table():
    return f'''<table class="fees">
<thead><tr><th>Service</th><th>Fee</th></tr></thead>
<tbody>{FEES_ROWS}</tbody>
</table>
<p class="note">Payment by MTN Mobile Money or Airtel Money. You receive an official receipt for every payment. Staff covered by an employer agreement pay nothing.</p>'''


# =====================================================================================
# HOME
# =====================================================================================
def home():
    cards = ''.join(f'''
        <a class="card reveal" href="{f}">
            {photo(n.lower(), '')}
            <div class="card-body">
                <h3>{n}</h3>
                <p>{d}</p>
                <span class="link-arrow">Learn more</span>
            </div>
        </a>''' for f, n, _, d in SERVICES)
    topics = ''.join(f'<li>{t}</li>' for t in [
        'Anxiety and constant worry', 'Low mood and depression', 'Stress and burnout',
        'Grief and loss', 'Trauma and difficult experiences', 'Relationship difficulties',
        'Family conflict and parenting', 'Work and money pressure', 'Self-esteem and confidence',
        'Anger and frustration', 'Sleep problems', 'Life changes and transitions'])
    return head('Mindwell Consultancy Ltd | Counselling and psychotherapy in Kampala',
                'Mindwell Consultancy Ltd offers confidential counselling and psychotherapy for individuals, couples, families and organisations, in person in Ntinda, Kampala and online.',
                'home') + f'''
<section class="hero">
    <div class="wrap hero-in">
        <div>
            <span class="eyebrow">Counselling and psychotherapy in Kampala</span>
            <h1>Professional support for your mental health and wellbeing</h1>
            <p class="lead">Mindwell Consultancy Ltd provides confidential counselling for individuals, couples, families and organisations. Meet a qualified therapist at our clinic in Ntinda, or online from wherever you are.</p>
            <div class="cta-row">
                <a class="btn btn-primary" href="contact.html#book">Book an appointment</a>
                <a class="btn btn-outline" href="services.html">Our services</a>
            </div>
            <ul class="facts">
                <li>{ic('shield')}Qualified, licensed therapists</li>
                <li>{ic('lock')}Strictly confidential</li>
                <li>{ic('pin')}In person and online</li>
            </ul>
        </div>
        <div class="hero-photo">
            {photo('a calm consultation room at the Ntinda clinic', 'tall', 'clinic-room.jpg')}
            <div class="badge-card"><b>A safe place to talk</b><span>Every conversation stays between you and your therapist.</span></div>
        </div>
    </div>
</section>

<section class="sec">
    <div class="wrap two">
        <div class="prose reveal">
            <span class="eyebrow">Welcome to Mindwell</span>
            <h2>Care that starts with listening</h2>
            <p>Life in Uganda can bring heavy pressures: work and money worries, family responsibilities, loss, and experiences that are hard to talk about. Many people carry these on their own, often for years.</p>
            <p>Mindwell Consultancy Ltd was founded to make professional, respectful mental health care easier to reach. Our therapists take time to understand you, agree clear goals with you, and support you at a pace that feels right.</p>
            <a class="link-arrow" href="about.html">About Mindwell</a>
        </div>
        <blockquote class="pull reveal">
            "Asking for help is a sign of strength. Our work is to make sure that when someone reaches out, they find a trained professional ready to listen."
            <cite>{P("Dr. Ntabade Joan, Founder")}</cite>
        </blockquote>
    </div>
</section>

<section class="sec tint">
    <div class="wrap">
        <div class="sec-head">
            <span class="eyebrow">Our services</span>
            <h2>How we can help</h2>
            <p>We work with adults, couples, families and organisations. Sessions are available in person at our clinic and online.</p>
        </div>
        <div class="cards">{cards}
        </div>
    </div>
</section>

<section class="sec">
    <div class="wrap">
        <div class="sec-head">
            <span class="eyebrow">What we help with</span>
            <h2>You do not need to be in crisis to talk to someone</h2>
            <p>People come to us for many reasons. These are some of the most common.</p>
        </div>
        <ul class="topic-list reveal">{topics}</ul>
        <p class="note">Not sure if counselling is right for you? <a href="contact.html">Contact us</a> and we will talk it through with you.</p>
    </div>
</section>

<section class="sec cream">
    <div class="wrap">
        <div class="sec-head">
            <span class="eyebrow">Your first appointment</span>
            <h2>What to expect</h2>
        </div>
        <ol class="steps reveal">
            <li><h3>Get in touch</h3><p>Book online, call or send us a message. We will find a time that suits you.</p></li>
            <li><h3>First assessment</h3><p>Your therapist listens to what has brought you here and asks some gentle questions about your wellbeing.</p></li>
            <li><h3>A plan together</h3><p>You agree on goals, how often to meet, and whether to meet in person or online.</p></li>
            <li><h3>Ongoing support</h3><p>Regular sessions, with check-ins along the way so you can both see how things are changing.</p></li>
        </ol>
    </div>
</section>

<section class="sec">
    <div class="wrap two">
        <div class="reveal">{photo('therapist and client in conversation (hands or backs only, no faces)', '', 'session.jpg')}</div>
        <div class="prose reveal">
            <span class="eyebrow">Why choose Mindwell</span>
            <h2>Professional, confidential and close to you</h2>
            <ul class="ticks">
                <li><span><b>Qualified therapists.</b> Every therapist's licence and qualifications are checked before they see clients.</span></li>
                <li><span><b>Confidential by design.</b> Your records are private. Reminders by SMS or email never say what your appointment is about.</span></li>
                <li><span><b>In person or online.</b> Visit our Ntinda clinic, or meet by secure video if travel is difficult.</span></li>
                <li><span><b>Clear, fair fees.</b> You always know the fee before you book, and you can pay by Mobile Money.</span></li>
                <li><span><b>Support for organisations.</b> Employers can cover counselling for their staff, with full confidentiality.</span></li>
            </ul>
        </div>
    </div>
</section>

<section class="sec tint">
    <div class="wrap">{online_band()}</div>
</section>
{book_band()}
''' + foot()


# =====================================================================================
# ABOUT
# =====================================================================================
def about():
    team = ''.join(f'''
        <div class="person reveal">
            {photo(f'portrait of {n}', 'tall', f'team-{i}.jpg')}
            <h3>{P(n)}</h3>
            <div class="role">{P(r)}</div>
            <p>{P("Two or three sentences: qualifications, areas of focus and languages spoken.")}</p>
        </div>''' for i, (n, r) in enumerate([('Therapist name', 'Counselling psychologist'), ('Therapist name', 'Couples and family therapist'), ('Therapist name', 'Clinical psychologist')], 1))
    return head('About us | Mindwell Consultancy Ltd',
                'Who we are, our mission and values, and the team behind Mindwell Consultancy Ltd in Kampala.',
                'about') + page_hero('<li>About us</li>', 'About Mindwell Consultancy Ltd',
                'We are a counselling and psychotherapy practice in Kampala, here to make professional mental health care respectful, confidential and easier to reach.', 'About us') + f'''
<section class="sec">
    <div class="wrap two top">
        <div class="prose reveal">
            <h2>Who we are</h2>
            <p>Mindwell Consultancy Ltd is a Ugandan mental health practice offering counselling and psychotherapy to individuals, couples, families and organisations. We see clients at our clinic in Ntinda, Kampala, and online through our secure client portal.</p>
            <p>We believe that everyone deserves a safe place to talk, without judgement and without stigma. Our therapists bring professional training together with an understanding of the realities of life in Uganda: family, faith, work and community.</p>
            <h3>Our mission</h3>
            <p>To provide professional, confidential and affordable mental health support that helps people heal, grow and thrive.</p>
            <h3>Our vision</h3>
            <p>A Uganda where caring for your mental health is as normal as caring for your physical health.</p>
        </div>
        <div class="reveal">{photo('the reception or waiting area', 'tall', 'reception.jpg')}</div>
    </div>
</section>

<section class="sec cream">
    <div class="wrap">
        <div class="sec-head center">
            <span class="eyebrow">Our values</span>
            <h2>Heal, grow, thrive</h2>
            <p>The three words in our logo describe the journey we walk with every client.</p>
        </div>
        <div class="values reveal">
            <div><div class="word">Heal</div><p>We start by listening. Together we make sense of what hurts and begin to ease it, at a pace that feels safe.</p></div>
            <div><div class="word">Grow</div><p>We help you build skills, understanding and confidence to handle what life brings, now and later.</p></div>
            <div><div class="word">Thrive</div><p>The goal is not only to feel less bad, but to live fully: in your relationships, your work and your community.</p></div>
        </div>
    </div>
</section>

<section class="sec" id="founder">
    <div class="wrap founder">
        <div class="reveal">{photo('portrait of Dr. Ntabade Joan', 'tall', 'dr-ntabade.jpg')}</div>
        <div class="prose reveal">
            <span class="eyebrow">Our founder</span>
            <h2>Dr. Ntabade Joan</h2>
            <p style="color:var(--green);font-weight:700;">{P("Title, for example Founder and Lead Therapist")}</p>
            <p>{P("Biography from Dr. Ntabade: her training and qualifications, professional registration, years of experience, and the kind of work she does with clients.")}</p>
            <p>{P("Why she founded Mindwell, in her own words, in two or three sentences.")}</p>
        </div>
    </div>
</section>

<section class="sec tint" id="team">
    <div class="wrap">
        <div class="sec-head">
            <span class="eyebrow">Our team</span>
            <h2>The people you will meet</h2>
            <p>Our therapists are qualified and licensed professionals. Each one is checked by our team before they see clients.</p>
        </div>
        <div class="team">{team}
        </div>
    </div>
</section>

<section class="sec">
    <div class="wrap two top">
        <div class="prose reveal">
            <span class="eyebrow">Our standards</span>
            <h2>How we look after you</h2>
            <ul class="ticks">
                <li><span><b>Qualified professionals.</b> Every therapist holds recognised qualifications and a valid licence {P("name the professional body, for example the Uganda Counselling Association")}.</span></li>
                <li><span><b>Confidentiality.</b> What you share stays between you and your therapist. The only exception is a serious and immediate risk to your life or someone else's, which your therapist will explain at the start.</span></li>
                <li><span><b>Data protection.</b> We handle personal information in line with Uganda's Data Protection and Privacy Act, 2019.</span></li>
                <li><span><b>Respect.</b> We welcome every client without judgement, whatever their background, faith or story.</span></li>
            </ul>
        </div>
        <div class="prose reveal">
            <span class="eyebrow">Work with us</span>
            <h2>Are you a licensed therapist?</h2>
            <p>We are always glad to hear from qualified counsellors, psychologists and therapists who share our values. Mindwell takes care of bookings, payments and reminders, so you can focus on your clients, in person or online.</p>
            <div class="cta-row"><a class="btn btn-outline" data-portal="/register/therapist" href="{PORTAL}/register/therapist">Apply to join our team</a></div>
        </div>
    </div>
</section>
{book_band()}
''' + foot()


# =====================================================================================
# SERVICES OVERVIEW
# =====================================================================================
def services():
    rows = ''.join(f'''
    <div class="two reveal" style="margin-bottom:64px;">
        <div style="order:{i % 2};">{photo(n.lower(), '', f.replace('.html', '.jpg'))}</div>
        <div class="prose">
            <div class="icon">{ic(icn)}</div>
            <h2>{n}</h2>
            <p>{d}</p>
            <a class="link-arrow" href="{f}">More about {n.lower()}</a>
        </div>
    </div>''' for i, (f, n, icn, d) in enumerate(SERVICES))
    return head('Services and fees | Mindwell Consultancy Ltd',
                'Individual therapy, couples and family counselling, corporate wellness and online sessions at Mindwell Consultancy Ltd, Kampala. Fees and how to book.',
                'services') + page_hero('<li>Services</li>', 'Our services',
                'Professional counselling and psychotherapy for individuals, couples, families and organisations, in person at our clinic and online.', 'Services') + f'''
<section class="sec">
    <div class="wrap">{rows}</div>
</section>

<section class="sec cream" id="fees">
    <div class="wrap narrow">
        <div class="sec-head">
            <span class="eyebrow">Fees</span>
            <h2>Fees and payment</h2>
            <p>You always see the fee before you confirm a booking. Plans with several sessions cost less per session.</p>
        </div>
        <div class="reveal">{fees_table()}</div>
    </div>
</section>

<section class="sec">
    <div class="wrap narrow">
        <div class="sec-head">
            <span class="eyebrow">Common questions</span>
            <h2>Before you book</h2>
        </div>
        {faq([
            ('How long is a session?', f'<p>Your therapist will agree the length and frequency of sessions with you at your first appointment. {P("Standard session length to confirm.")}</p>'),
            ('How many sessions will I need?', '<p>It depends on what you would like help with. Some people find a few sessions enough, others prefer longer support. You and your therapist will review progress together regularly.</p>'),
            ('Do I need a referral?', '<p>No. You can book directly with us. If a doctor has referred you, please bring or send the referral letter.</p>'),
            ('Can I cancel or move an appointment?', '<p>Yes. Please let us know as early as you can. If you booked online, you can ask to move or cancel from your client portal and our team will confirm.</p>'),
            ('Is everything I say confidential?', '<p>Yes. The only exception is a serious and immediate risk to your life or someone else&#39;s. Your therapist will explain this before you begin.</p>'),
        ])}
    </div>
</section>
{book_band()}
''' + foot()


# =====================================================================================
# SERVICE DETAIL PAGES
# =====================================================================================
def service_page(file, title, desc, lead, intro_html, helps, how_html, extra_html, faqs, book_title, book_text, photo_label,
                 helps_kicker='What we help with', helps_title='Common reasons people come to us'):
    helps_li = ''.join(f'<li>{h}</li>' for h in helps)
    return head(f'{title} | Mindwell Consultancy Ltd', desc, 'services') + page_hero(
        f'<li><a href="services.html">Services</a></li><li>{title}</li>', title, lead, 'Services') + f'''
<section class="sec">
    <div class="wrap two top">
        <div class="prose reveal">{intro_html}</div>
        <div class="reveal">{photo(photo_label, '', file.replace('.html', '.jpg'))}</div>
    </div>
</section>

<section class="sec tint">
    <div class="wrap">
        <div class="sec-head"><span class="eyebrow">{helps_kicker}</span><h2>{helps_title}</h2></div>
        <ul class="topic-list reveal">{helps_li}</ul>
    </div>
</section>

<section class="sec">
    <div class="wrap two top">
        <div class="prose reveal">{how_html}</div>
        <div class="reveal">{extra_html}</div>
    </div>
</section>

<section class="sec cream">
    <div class="wrap narrow">
        <div class="sec-head"><span class="eyebrow">Questions</span><h2>Frequently asked</h2></div>
        {faq(faqs)}
    </div>
</section>
{book_band(book_title, book_text)}
''' + foot()


def fees_box(rows_html, note):
    return f'''<div class="card"><div class="card-body">
        <h3>Fees</h3>
        <table class="fees" style="border:0;margin-top:6px;"><tbody>{rows_html}</tbody></table>
        <p class="note">{note}</p>
        <a class="link-arrow" href="services.html#fees">All fees</a>
    </div></div>'''


def individual():
    return service_page(
        'individual-therapy.html', 'Individual therapy',
        'One-to-one counselling and psychotherapy for adults in Kampala and online: anxiety, low mood, stress, grief, trauma and life changes.',
        'One-to-one counselling with a qualified therapist, in a confidential space where you can speak freely.',
        '''<h2>Time and space for you</h2>
        <p>Individual therapy gives you regular, private time with a trained professional to talk about what is troubling you. Your therapist will listen without judgement, help you understand what is happening, and work with you on practical ways to cope and move forward.</p>
        <p>You do not need to know exactly what is wrong before you come. Many people start simply because they feel stuck, overwhelmed or not like themselves.</p>''',
        ['Anxiety, panic and constant worry', 'Low mood and depression', 'Stress and burnout', 'Grief and loss',
         'Trauma and painful experiences', 'Self-esteem and confidence', 'Anger and frustration', 'Sleep problems',
         'Life changes and big decisions'],
        '''<span class="eyebrow">How it works</span>
        <h2>Your sessions</h2>
        <ul class="ticks">
            <li><span><b>First assessment.</b> Your first session is about getting to know you: what brings you here, how you have been feeling, and what you hope to change.</span></li>
            <li><span><b>A plan that suits you.</b> Together you agree goals and how often to meet, usually weekly or every two weeks.</span></li>
            <li><span><b>In person or online.</b> Meet at our Ntinda clinic, or by secure video. You can switch between the two.</span></li>
            <li><span><b>Progress check-ins.</b> Short questionnaires every few weeks help you and your therapist see what is changing.</span></li>
        </ul>''',
        fees_box(f'<tr><td><b>In person</b></td><td>UGX 20,000 {P("to confirm")}</td></tr><tr><td><b>Online</b></td><td>UGX 15,000 {P("to confirm")}</td></tr>',
                 'Plans with several sessions cost less per session. Payment by Mobile Money.'),
        [('Who is individual therapy for?', '<p>Adults aged 18 and over. If you are looking for help for a young person, please contact us and we will advise you.</p>'),
         ('Can I choose my therapist?', '<p>Yes. You can ask for a particular therapist, or tell us what matters to you, for example language or gender, and we will match you.</p>'),
         ('Which languages can I use?', f'<p>Sessions are available in English and {P("other languages, for example Luganda and Swahili")}. Tell us your preference when you book.</p>')],
        'Take the first step', 'Book an individual session online, or call us to talk it through first.',
        'a quiet, private consultation room')


def couples():
    return service_page(
        'couples-and-family.html', 'Couples and family',
        'Couples and family counselling in Kampala: communication, conflict, trust, premarital counselling and parenting support.',
        'Support for partners and families to understand each other, work through difficulties and grow closer.',
        '''<h2>When relationships feel hard</h2>
        <p>Every relationship goes through difficult seasons. Arguments repeat, trust is broken, or you simply feel far apart. Couples and family counselling gives everyone a fair, safe place to be heard, with a therapist who does not take sides.</p>
        <p>We work with married and unmarried couples, couples preparing for marriage, parents and their adult children, and wider family members.</p>''',
        ['Communication problems and constant arguments', 'Rebuilding trust after infidelity', 'Premarital counselling',
         'Parenting disagreements', 'Blended families', 'Separation and divorce', 'Family conflict and extended family pressure',
         'Money and responsibilities at home', 'Coping together with illness or loss'],
        '''<span class="eyebrow">How it works</span>
        <h2>Your sessions</h2>
        <ul class="ticks">
            <li><span><b>Everyone is heard.</b> Your therapist makes sure each person has the space to speak and be understood.</span></li>
            <li><span><b>Joint and individual time.</b> Sometimes it helps to meet partners or family members separately as well as together.</span></li>
            <li><span><b>Practical tools.</b> You will practise new ways of talking, listening and solving problems between sessions.</span></li>
            <li><span><b>In person or online.</b> Sessions can take place at our clinic or by video.</span></li>
        </ul>''',
        fees_box(f'<tr><td><b>Couples or family session</b></td><td>{P("Fee to confirm")}</td></tr>',
                 'Please contact us to book couples and family sessions, so we can plan the right format with you.'),
        [('Do we both have to come?', '<p>It works best when everyone involved takes part, but you can start on your own if your partner or family member is not ready yet.</p>'),
         ('Will the therapist take sides?', '<p>No. Your therapist supports the relationship and each person in it, fairly and without judgement.</p>'),
         ('Do you offer premarital counselling?', '<p>Yes. Premarital sessions help couples talk openly about expectations, money, family, faith and conflict before marriage.</p>')],
        'Book a couples or family session', 'Contact us and we will arrange the right format and time for you.',
        'two chairs facing each other in the consultation room')


def corporate():
    return service_page(
        'corporate-wellness.html', 'Corporate wellness',
        'Employee counselling, workplace mental health workshops and training for organisations in Uganda, from Mindwell Consultancy Ltd.',
        'Confidential counselling for your staff, and practical workshops that help your organisation look after its people.',
        '''<h2>Healthy people, stronger organisations</h2>
        <p>Stress, burnout, grief and family pressure affect how people feel and work, even when nobody talks about them. Supporting your staff's mental health reduces absence, improves focus, and shows your team that you care.</p>
        <p>Mindwell works with companies, NGOs, schools and public bodies of all sizes. We tailor our support to your people and your budget.</p>''',
        ['Staff counselling (employee assistance)', 'Stress and burnout prevention', 'Mental health awareness talks',
         'Training for managers and HR', 'Support after a difficult event at work', 'Work and life balance',
         'Financial stress', 'Wellness days and workshops', 'Confidential referral pathways'],
        '''<span class="eyebrow">How it works</span>
        <h2>Staff counselling benefit</h2>
        <ul class="ticks">
            <li><span><b>One agreement.</b> You choose how many staff to cover and for how long.</span></li>
            <li><span><b>A private code for each person.</b> Staff use their code to book sessions, in person or online, with nothing to pay.</span></li>
            <li><span><b>Complete confidentiality.</b> You never see who uses the service or what they talk about.</span></li>
            <li><span><b>Simple renewal.</b> We remind you before your agreement ends.</span></li>
        </ul>''',
        f'''<div class="card"><div class="card-body">
            <h3>Workshops and training</h3>
            <p>Practical, interactive sessions for teams and managers, delivered at your workplace or online.</p>
            <ul class="ticks" style="margin-top:8px;">
                <li>Understanding stress and burnout</li>
                <li>Mental health awareness for all staff</li>
                <li>Supporting a colleague who is struggling</li>
                <li>{P("Other topics to confirm")}</li>
            </ul>
            <a class="btn btn-primary" style="margin-top:20px;" data-email="Corporate wellness enquiry" href="mailto:care@mindwell.com">Request a proposal</a>
        </div></div>''',
        [('How much does it cost?', '<p>We prepare a quote based on the number of staff and the services you choose. Contact us for a proposal.</p>'),
         ('Will you tell us who used the service?', '<p>No. We never share who uses counselling or what they discuss. If you wish, we can share anonymous, overall figures on how much the service is used.</p>'),
         ('Can staff family members be covered?', f'<p>{P("To confirm.")} Please ask us about options for staff families.</p>')],
        'Talk to us about your team', 'Tell us about your organisation and we will suggest the right support.',
        'a workplace wellness workshop', 'What we offer', 'Support for your organisation')


def online():
    return service_page(
        'online-sessions.html', 'Online sessions',
        'Secure video counselling with Mindwell Consultancy Ltd. Book, pay by Mobile Money and join sessions through the Mindwell client portal.',
        'See your therapist by secure video from home, work or wherever you feel comfortable.',
        f'''<h2>Professional care, wherever you are</h2>
        <p>Online sessions are the same professional counselling we offer at our clinic, delivered by secure video. They are ideal if you live outside Kampala, have a busy schedule, find travel difficult, or simply feel more comfortable at home.</p>
        <p>Everything happens through the Mindwell client portal: booking, payment by Mobile Money, joining your session, messages with your therapist and your private journal.</p>
        <div class="cta-row"><a class="btn btn-primary" data-portal="/register" href="{PORTAL}/register">Create a client account</a><a class="btn btn-outline" data-portal="/login" href="{PORTAL}/login">Client log in</a></div>''',
        ['Anything we offer in person', 'Clients outside Kampala', 'Busy work schedules', 'Difficulty travelling',
         'Ongoing support between clinic visits', 'Couples in different locations', 'People who prefer the privacy of home',
         'Staff covered by an employer', 'Follow-up after in-person sessions'],
        '''<span class="eyebrow">How it works</span>
        <h2>Getting started online</h2>
        <ol class="ticks" style="padding:0;list-style:none;">
            <li><span><b>Create your account</b> on the client portal. It takes about two minutes.</span></li>
            <li><span><b>Answer a short assessment</b> about how you have been feeling. It is private.</span></li>
            <li><span><b>Choose a therapist and a time,</b> or let us match you with someone available.</span></li>
            <li><span><b>Pay by Mobile Money</b> and receive an official receipt.</span></li>
            <li><span><b>Join your session</b> from the portal a few minutes before your time.</span></li>
        </ol>
        <h3>What you need</h3>
        <p>A phone or laptop with a camera, an internet connection, and a quiet private place. Headphones help.</p>''',
        f'''<div class="card"><div class="card-body">
            <h3>Private and secure</h3>
            <ul class="ticks" style="margin-top:8px;">
                <li>Sessions take place in a private video room for you and your therapist only</li>
                <li>Your journal and notes stay private unless you choose to share them</li>
                <li>Reminders never say what your appointment is about</li>
            </ul>
            <table class="fees" style="border:0;margin-top:14px;"><tbody><tr><td><b>Online session</b></td><td>UGX 15,000 {P("to confirm")}</td></tr></tbody></table>
        </div></div>
        <div class="card" style="margin-top:22px;"><div class="card-body">
            <h3>The Mindwell app</h3>
            <p>An Android app is on its way, so you can book and join sessions from your phone. Until then, the client portal works in any phone browser.</p>
            <div class="cta-row" style="margin-top:12px;"><a class="store soon" data-store="playStore" href="#" style="background:var(--navy);"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.5 3.3c-.3.3-.5.8-.5 1.4v14.6c0 .6.2 1.1.5 1.4l8.2-8.7-8.2-8.7zm9.4 7.4l2.4-2.5-9.9-5.8c-.4-.2-.8-.3-1.1-.2l8.6 8.5zm0 2.6l-8.6 8.5c.3.1.7 0 1.1-.2l9.9-5.8-2.4-2.5zm3.5-3.8L15 11.8l2.4 2.5 2.6-1.5c.8-.5.8-1.3 0-1.8l-2.6-1.5z"/></svg><span><small>Coming soon</small><b>Google Play</b></span></a></div>
        </div></div>''',
        [('Is online counselling as effective as meeting in person?', '<p>For many people, yes. What matters most is the relationship with your therapist. You can also mix online and in-person sessions.</p>'),
         ('What if my connection drops?', '<p>Simply rejoin from the portal. Your therapist will wait for you. The connection does not need to be perfect.</p>'),
         ('Can I message my therapist between sessions?', '<p>Yes, through the portal. Messages are not checked around the clock, so they are not for emergencies.</p>')],
        'Start online today', 'Create your client account and book your first online session.',
        'a person on a video call at home (no face visible)', 'Who it suits', 'Online sessions work well for')


# =====================================================================================
# CONTACT
# =====================================================================================
def contact():
    return head('Contact and booking | Mindwell Consultancy Ltd',
                'Book an appointment or contact Mindwell Consultancy Ltd in Ntinda, Kampala. Phone, email, opening hours and directions.',
                'contact') + page_hero('<li>Contact</li>', 'Contact and booking',
                'Book online, call us, or send a message. We will get back to you as soon as we can.', 'Contact us') + f'''
<section class="sec" id="book">
    <div class="wrap">
        <div class="sec-head"><span class="eyebrow">Book an appointment</span><h2>Three ways to book</h2></div>
        <div class="cards three">
            <div class="card reveal"><div class="card-body">
                <div class="icon">{ic('calendar')}</div>
                <h3>Book online</h3>
                <p>Create a client account, choose a therapist and a time, and pay by Mobile Money. For individual sessions in person or online.</p>
                <div class="cta-row" style="margin-top:auto;padding-top:16px;"><a class="btn btn-primary" data-portal="/register" href="{PORTAL}/register">Book online</a></div>
            </div></div>
            <div class="card reveal"><div class="card-body">
                <div class="icon">{ic('phone')}</div>
                <h3>Call us</h3>
                <p>Talk to our team about the right service and find a time that suits you. Best for couples, family and first-time questions.</p>
                <p style="font-size:20px;font-weight:700;color:var(--navy);margin-top:auto;padding-top:16px;">{P("+256 7XX XXX XXX")}</p>
            </div></div>
            <div class="card reveal"><div class="card-body">
                <div class="icon">{ic('mail')}</div>
                <h3>Send a message</h3>
                <p>Use the form below or email us, and we will reply within {P("one working day")}. Organisations, please include your company name.</p>
                <div class="cta-row" style="margin-top:auto;padding-top:16px;"><a class="btn btn-outline" href="#message">Write to us</a></div>
            </div></div>
        </div>
        <p class="note">Already a client? <a data-portal="/login" href="{PORTAL}/login">Log in to the client portal</a> to see your sessions, messages and receipts.</p>
    </div>
</section>

<section class="sec cream" id="message">
    <div class="wrap contact-grid">
        <div class="info reveal">
            <h2 style="font-size:clamp(26px,3vw,34px);">Visit or contact us</h2>
            <div class="info-item"><div class="icon">{ic('pin')}</div><div><b>Clinic address</b><span>{P("Plot and street name")}<br>Ntinda, Kampala, Uganda</span></div></div>
            <div class="info-item"><div class="icon">{ic('phone')}</div><div><b>Phone</b><span>{P("+256 7XX XXX XXX")}</span></div></div>
            <div class="info-item"><div class="icon">{ic('mail')}</div><div><b>Email</b><a data-email="" data-email-text href="mailto:care@mindwell.com">care@mindwell.com</a></div></div>
            <div class="info-item"><div class="icon">{ic('clock')}</div><div style="flex:1;"><b>Opening hours</b>
                <table class="hours"><tbody>
                    <tr><td>Monday to Friday</td><td>{P("8:30 am to 5:30 pm")}</td></tr>
                    <tr><td>Saturday</td><td>{P("9:00 am to 1:00 pm")}</td></tr>
                    <tr><td>Sunday and public holidays</td><td>Closed</td></tr>
                </tbody></table>
                <span style="font-size:14px;color:var(--muted);">Online sessions may be available outside these hours.</span>
            </div></div>
            <div class="map">{photo('map or photo of the building entrance', 'wide', 'map.jpg')}</div>
            <a class="link-arrow" href="https://www.google.com/maps/search/?api=1&query=Ntinda%2C%20Kampala" target="_blank" rel="noopener">Open in Google Maps</a>
        </div>

        <form class="enquiry reveal" id="enquiry">
            <h2 style="font-size:26px;margin-bottom:6px;">Send us a message</h2>
            <p style="color:var(--muted);font-size:15px;">Please do not include detailed personal or medical information. We will discuss that with you privately.</p>
            <div class="field-row">
                <div class="field"><label for="f-name">Your name</label><input id="f-name" name="name" required autocomplete="name"></div>
                <div class="field"><label for="f-phone">Phone</label><input id="f-phone" name="phone" type="tel" autocomplete="tel" placeholder="07XX XXX XXX"></div>
            </div>
            <div class="field"><label for="f-email">Email</label><input id="f-email" name="email" type="email" autocomplete="email"></div>
            <div class="field-row">
                <div class="field"><label for="f-topic">I am asking about</label>
                    <select id="f-topic" name="topic">
                        <option>Individual therapy</option><option>Couples and family</option><option>Corporate wellness</option>
                        <option>Online sessions</option><option>Fees and payment</option><option>Something else</option>
                    </select></div>
                <div class="field"><label for="f-reach">Best way to reach me</label>
                    <select id="f-reach" name="reach"><option>Phone call</option><option>WhatsApp</option><option>Email</option></select></div>
            </div>
            <div class="field"><label for="f-msg">Message</label><textarea id="f-msg" name="message" rows="5" required></textarea></div>
            <button class="btn btn-primary" type="submit">Send message</button>
            <p class="form-note">This opens your email app with your message ready to send.</p>
            <p class="form-note" id="enquiry-done" hidden style="color:var(--green);font-weight:700;">Your email app should now be open. If it did not open, email us at care@mindwell.com.</p>
        </form>
    </div>
</section>
''' + foot()


PAGES = {
    'index.html': home, 'about.html': about, 'services.html': services, 'contact.html': contact,
    'individual-therapy.html': individual, 'couples-and-family.html': couples,
    'corporate-wellness.html': corporate, 'online-sessions.html': online,
}

if __name__ == '__main__':
    for name, fn in PAGES.items():
        (OUT / name).write_text(fn(), encoding='utf-8')
        print('built', name)
