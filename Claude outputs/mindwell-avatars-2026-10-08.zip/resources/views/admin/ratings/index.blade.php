@extends('layouts.app')
@section('title', 'Session Ratings')
@section('content')
{{-- Added 2026-10-04 — see Admin\RatingController. Admin-only: therapists never see
     comments, and only see their own average once they have 3+ ratings. --}}
@php
    $stars = fn (int $n) => '<span style="color:#e8a33d;letter-spacing:1px;" aria-hidden="true">'.str_repeat('★', $n).'</span><span style="color:#d8dedc;letter-spacing:1px;" aria-hidden="true">'.str_repeat('★', 5 - $n).'</span>';
    $total = $overall['count'] + $overall['skipped'];
@endphp

<div class="dash-head">
    <h1>Session ratings</h1>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:18px;">
    <div class="card">
        <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">Average (all time)</div>
        <div style="font-size:24px;font-weight:800;color:var(--ink-900);margin-top:4px;">{{ $overall['count'] ? number_format($overall['average'], 1) : '—' }}<span style="font-size:13px;color:var(--ink-300);"> / 5</span></div>
        <div style="font-size:12px;color:var(--ink-500);">{{ $overall['count'] }} rating{{ $overall['count'] === 1 ? '' : 's' }}</div>
    </div>
    <div class="card">
        <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">Last 30 days</div>
        <div style="font-size:24px;font-weight:800;color:var(--ink-900);margin-top:4px;">{{ $overall['count_30'] ? number_format($overall['average_30'], 1) : '—' }}<span style="font-size:13px;color:var(--ink-300);"> / 5</span></div>
        <div style="font-size:12px;color:var(--ink-500);">{{ $overall['count_30'] }} rating{{ $overall['count_30'] === 1 ? '' : 's' }}</div>
    </div>
    <a class="card" href="{{ route('admin.ratings.index', ['low' => 1]) }}" style="text-decoration:none;">
        <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">Low (1–2 stars)</div>
        <div style="font-size:24px;font-weight:800;color:{{ $overall['low'] ? 'var(--danger, #c0392b)' : 'var(--ink-900)' }};margin-top:4px;">{{ $overall['low'] }}</div>
        <div style="font-size:12px;color:var(--teal-600, #2f6f66);font-weight:600;">See them →</div>
    </a>
    <div class="card">
        <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">Response rate</div>
        <div style="font-size:24px;font-weight:800;color:var(--ink-900);margin-top:4px;">{{ $total ? round($overall['count'] / $total * 100) . '%' : '—' }}</div>
        <div style="font-size:12px;color:var(--ink-500);">{{ $overall['skipped'] }} skipped</div>
    </div>
</div>

<div class="card" style="padding:0;margin-bottom:18px;">
    <div class="section-title" style="padding:16px 16px 0;">By therapist</div>
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Therapist</th>
                <th>Average</th>
                <th>Ratings</th>
                <th>Last 30 days</th>
                <th>Low</th>
                <th style="padding-right:16px;"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($therapists as $t)
                <tr>
                    <td style="padding-left:16px;">@include('partials.person', ['name' => $t['name']])</td>
                    <td style="white-space:nowrap;">{!! $stars((int) round($t['average'])) !!} <span style="font-weight:700;margin-left:4px;">{{ number_format($t['average'], 1) }}</span></td>
                    <td>{{ $t['count'] }}</td>
                    <td>{{ $t['average_30'] !== null ? number_format($t['average_30'], 1) : '—' }}</td>
                    <td>
                        @if ($t['low'])
                            <span class="pill danger">{{ $t['low'] }}</span>
                        @else
                            <span style="color:var(--ink-300);">0</span>
                        @endif
                    </td>
                    <td style="padding-right:16px;text-align:right;"><a href="{{ route('admin.ratings.index', ['therapist' => $t['id']]) }}" class="btn ghost sm">View ratings</a></td>
                </tr>
            @empty
                <tr><td colspan="6" style="padding:16px;color:var(--ink-500);">No ratings yet. Clients are asked as they leave the video room, and once by email the next day.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="card" style="padding:0;">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding:16px 16px 0;">
        <div class="section-title" style="margin:0;">
            {{ ! empty($filters['low']) ? 'Low ratings' : 'All ratings' }}{{ $filterTherapistName ? ' · '.$filterTherapistName : '' }}
        </div>
        <div style="display:flex;gap:8px;">
            @if (! empty($filters['low']) || ! empty($filters['therapist']))
                <a href="{{ route('admin.ratings.index') }}" class="btn ghost sm">Show all</a>
            @endif
            @if (empty($filters['low']))
                <a href="{{ route('admin.ratings.index', array_filter(['low' => 1, 'therapist' => $filters['therapist'] ?? null])) }}" class="btn ghost sm">Low only</a>
            @endif
        </div>
    </div>
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Rated</th>
                <th>Client</th>
                <th>Therapist</th>
                <th>Rating</th>
                <th style="padding-right:16px;">Comment</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($ratings as $r)
                <tr>
                    <td style="padding-left:16px;white-space:nowrap;font-size:12.5px;">
                        {{ $r->created_at->format('M j, Y') }}
                        @if ($r->therapySession?->scheduled_at)
                            <div style="font-size:11px;color:var(--ink-300);">Session {{ $r->therapySession->scheduled_at->format('M j') }}</div>
                        @endif
                    </td>
                    <td>@include('partials.person', ['name' => $r->clientProfile?->user?->name, 'size' => 28])</td>
                    <td>@include('partials.person', ['name' => $r->therapistProfile?->user?->name, 'size' => 28])</td>
                    <td style="white-space:nowrap;">
                        {!! $stars($r->rating) !!}
                        <span class="sr-only" style="position:absolute;left:-9999px;">{{ $r->rating }} of 5</span>
                    </td>
                    <td style="padding-right:16px;font-size:12.5px;color:var(--ink-700);max-width:380px;">{{ $r->comment ?? '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="5" style="padding:16px;color:var(--ink-500);">Nothing here yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div style="margin-top:16px;">{{ $ratings->links() }}</div>
@endsection
