@extends('layouts.app')
@section('title', 'Check-ins')
@section('content')
{{-- Added 2026-10-06 (roadmap 28) — see Admin\CheckInOverviewController. --}}
@php
    $S = \App\Support\Screeners::class;
    $labels = [
        'overdue' => ['danger', 'Overdue', 'Due more than '.config('mindwell.check_in_reminder_delay_days', 2).' days ago — they have been sent a reminder'],
        'due' => ['warn', 'Due', 'Due now — shown on their dashboard'],
        'up_to_date' => ['success', 'Up to date', 'Checked in within the last 2 weeks'],
        'no_intake' => ['', 'No intake', 'In care but never did the first assessment'],
    ];
@endphp

<div class="dash-head">
    <h1>Check-ins</h1>
    <span style="font-size:12.5px;color:var(--ink-500);">{{ $total }} {{ $total === 1 ? 'client' : 'clients' }} in care</span>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:16px;">
    @foreach ($labels as $key => [$pill, $label, $hint])
        <a href="{{ route('admin.check-ins.index', $filter === $key ? [] : ['status' => $key]) }}" class="card" style="text-decoration:none;display:block;{{ $filter === $key ? 'outline:2px solid var(--teal-600, #2f6f66);' : '' }}">
            <div style="font-size:11.5px;font-weight:700;color:var(--ink-500);text-transform:uppercase;letter-spacing:.03em;">{{ $label }}</div>
            <div style="font-size:26px;font-weight:800;color:{{ $key === 'overdue' && ($counts[$key] ?? 0) > 0 ? 'var(--danger, #c0392b)' : 'var(--ink-900)' }};margin-top:4px;">{{ $counts[$key] ?? 0 }}</div>
            <div style="font-size:11.5px;color:var(--ink-500);">{{ $hint }}</div>
        </a>
    @endforeach
</div>

<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Client</th>
                <th>Therapist</th>
                <th>Last assessed</th>
                <th>Next due</th>
                <th>Latest scores</th>
                <th>Check-ins</th>
                <th style="padding-right:16px;">Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($rows as $r)
                @php [$pill, $label] = $labels[$r['key']]; @endphp
                <tr>
                    <td style="padding-left:16px;">
                        @include('partials.person', ['name' => $r['profile']->user->name, 'href' => route('admin.clients.show', $r['profile']), 'sub' => $r['profile']->user->clientLabel()])
                    </td>
                    <td style="font-size:12.5px;">@if ($r['therapist']) @include('partials.person', ['name' => $r['therapist'], 'size' => 28]) @else — @endif</td>
                    <td style="font-size:12.5px;white-space:nowrap;">{{ $r['status']['last_at']?->format('j M Y') ?? '—' }}</td>
                    <td style="font-size:12.5px;white-space:nowrap;">
                        {{ $r['status']['due_at']?->format('j M') ?? '—' }}
                        @if ($r['status']['overdue_days'] > 0)
                            <div style="font-size:11px;color:var(--danger, #c0392b);">{{ $r['status']['overdue_days'] }} day(s) late</div>
                        @endif
                    </td>
                    <td style="font-size:12px;white-space:nowrap;">
                        @if ($r['latest'])
                            PHQ-9 {{ $r['latest']['phq9'] }} · GAD-7 {{ $r['latest']['gad7'] }}
                            <div style="font-size:11px;color:var(--ink-300);">{{ $S::band('phq9', $r['latest']['phq9']) }} / {{ $S::band('gad7', $r['latest']['gad7']) }}</div>
                        @else
                            —
                        @endif
                    </td>
                    <td>{{ $r['checkIns'] }}</td>
                    <td style="padding-right:16px;white-space:nowrap;">
                        <span class="pill {{ $pill }}">{{ $label }}</span>
                        <a href="{{ route('admin.clients.progress', $r['profile']) }}" style="font-size:12px;color:var(--teal-600, #2f6f66);font-weight:700;margin-left:6px;">Progress</a>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" style="padding:16px;color:var(--ink-500);">{{ $filter ? 'No clients in this group.' : 'No clients in care yet.' }}</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<p style="font-size:11px;color:var(--ink-300);margin-top:12px;">Check-ins are due every {{ config('mindwell.check_in_interval_days', 14) }} days. Clients who are overdue are reminded by email/SMS automatically.</p>
@endsection
