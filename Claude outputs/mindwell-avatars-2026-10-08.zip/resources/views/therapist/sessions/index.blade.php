@extends('layouts.app')
@section('title', 'My Sessions')
@section('content')

<div class="dash-head">
    <h1>Your sessions</h1>
    <a href="{{ route('therapist.reports.index') }}" class="btn ghost sm">See all reports</a>
</div>

{{-- Client rating summary (added 2026-10-04): average + count only, shown from 3 ratings. --}}
<div class="card" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:20px;padding:14px 18px;">
    <span style="font-size:22px;color:#e8a33d;" aria-hidden="true">★</span>
    @if (! empty($ratingSummary))
        <div>
            <div style="font-size:15px;font-weight:800;color:var(--ink-900);">{{ number_format($ratingSummary['average'], 1) }} / 5 average client rating</div>
            <div style="font-size:12px;color:var(--ink-500);">From {{ $ratingSummary['count'] }} session ratings. Individual ratings and comments are only seen by the Mindwell team.</div>
        </div>
    @else
        <div style="font-size:12.5px;color:var(--ink-500);">
            Your average client rating will appear here once you have {{ \App\Models\SessionRating::MIN_FOR_THERAPIST }} ratings — so no single client's rating can be worked out.
        </div>
    @endif
</div>

<div class="section-title">Upcoming / to close out ({{ $upcoming->count() }})</div>
<div class="card" style="padding:0;margin-bottom:24px;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Client</th>
                <th>When</th>
                <th>How they were matched</th>
                <th style="padding-right:16px;"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($upcoming as $session)
            <tr>
                <td style="padding-left:16px;">
                    @include('partials.person', ['name' => $session->clientProfile?->user?->name, 'fallback' => 'Unknown client', 'size' => 30])
                </td>
                <td>
                    <span style="display:inline-flex;align-items:center;gap:6px;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px;flex-shrink:0;color:var(--ink-300);"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 9h16"/><path d="M8 3v4M16 3v4"/></svg>
                        {{ $session->scheduled_at?->format('M j, Y g:i A') ?? '—' }}
                    </span>
                </td>
                <td>
                    <span class="pill teal">
                        {{ match($session->routing_method) {
                            'algorithmic' => 'Matched automatically',
                            'manual' => 'Routed by staff',
                            'self_booked' => 'Client booked directly',
                            'therapist_scheduled' => 'Follow-up you scheduled',
                            default => '—',
                        } }}
                    </span>
                </td>
                <td style="padding-right:16px;text-align:right;white-space:nowrap;">
                    {{-- Added 2026-09-28: real video via LiveKit. The room page itself
                         handles "not open yet" / "ended", so the button always shows. --}}
                    <a href="{{ route('therapist.clients.show', $session->client_profile_id) }}" class="btn ghost sm" style="margin-right:6px;">Client file</a>
                    @if ($session->isInPerson())
                        {{-- In-person (2026-10-07): no video room. --}}
                        <span class="pill success" style="margin-right:6px;" title="{{ $session->locationText() }}">In person{{ $session->venue ? ' · '.$session->venue->name : '' }}</span>
                    @else
                        <a href="{{ route('sessions.room', $session) }}" class="btn coral sm" style="margin-right:6px;">Join video</a>
                    @endif
                    <a href="{{ route('therapist.sessions.close', $session) }}" class="btn primary sm">Close session</a>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" style="padding:16px;color:var(--ink-500);">Nothing scheduled yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="section-title">Recently closed</div>
<div class="card" style="padding:0;">
    <table class="mw-table">
        <thead>
            <tr>
                <th style="padding-left:16px;">Client</th>
                <th>Closed</th>
                <th>Outcome</th>
                <th>Report</th>
                <th style="padding-right:16px;"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($recentlyClosed as $session)
            <tr>
                <td style="padding-left:16px;">
                    @include('partials.person', ['name' => $session->clientProfile?->user?->name, 'fallback' => 'Unknown client', 'size' => 30])
                </td>
                <td>{{ $session->closed_at?->format('M j, Y g:i A') ?? '—' }}</td>
                <td><span class="pill success">{{ \App\Models\TherapySession::CLOSURE_OUTCOMES[$session->closure_outcome] ?? $session->closure_outcome }}</span></td>
                <td style="font-size:12px;color:var(--ink-500);max-width:260px;">
                    {{ \Illuminate\Support\Str::limit($session->session_summary ?: $session->closure_report ?: '', 70) }}
                </td>
                <td style="padding-right:16px;text-align:right;white-space:nowrap;">
                    <a href="{{ route('therapist.clients.show', $session->client_profile_id) }}" class="btn ghost sm" style="margin-right:6px;">Client file</a>
                    <a href="{{ route('therapist.reports.show', $session) }}" class="btn ghost sm">View</a>
                </td>
            </tr>
            @empty
            <tr><td colspan="5" style="padding:16px;color:var(--ink-500);">No closed sessions yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<p style="font-size:11px;color:var(--ink-300);margin-top:12px;">
    Only your 10 most recent closures show here — see <a href="{{ route('therapist.reports.index') }}" style="color:var(--teal-600);">all your reports</a>
    to search, filter, or download any of them as a PDF.
</p>
@endsection
