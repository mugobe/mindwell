import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import '../sessions/session_flow.dart';
import '../therapists/therapists_screen.dart';
import '../urgent_help_screen.dart';
import 'about_fields.dart';

/// First assessment — the website's intake, one step at a time:
///   intro → "About you" sections the admin has switched on (each can be skipped)
///   → PHQ-9 (9) and GAD-7 (7), one question per screen, tap to answer → send.
/// POST intake runs the website's own code; the answer says where to go next:
/// crisis → support screen, lobby → waiting room, checkout → pay.
/// [forBooking] (2026-11-07): opened from a therapist's booking screen, so only the
/// assessment is saved ('assessed') and this screen closes with true to go back to booking.
class IntakeScreen extends StatefulWidget {
  const IntakeScreen({super.key, this.forBooking = false});

  final bool forBooking;

  @override
  State<IntakeScreen> createState() => _IntakeScreenState();
}

class _Step {
  const _Step.intro() : kind = 'intro', section = null, question = null, group = null;
  const _Step.about(this.section) : kind = 'about', question = null, group = null;
  const _Step.question(this.question, this.group) : kind = 'question', section = null;
  const _Step.send() : kind = 'send', section = null, question = null, group = null;

  final String kind;
  final Map<String, dynamic>? section;
  final Map<String, dynamic>? question;
  final String? group; // phq9 | gad7
}

class _IntakeScreenState extends State<IntakeScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  bool _loading = true;
  bool _sending = false;

  final List<_Step> _steps = [];
  int _index = 0;

  final Map<String, dynamic> _about = {};
  final Set<String> _skipped = {};
  final Map<String, int> _scores = {};

  List<Map<String, dynamic>> _sections = const [];
  List<Map<String, dynamic>> _options = const [];
  String _intro = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = (await context.read<AppState>().api.get('intake')) as Map<String, dynamic>;
      final about = (data['about'] as Map?) ?? const {};
      final screening = (data['screening'] as Map?) ?? const {};
      _sections = ((about['sections'] as List?) ?? const []).cast<Map<String, dynamic>>();
      final answers = about['answers'];
      if (answers is Map) {
        answers.forEach((k, v) {
          if (k != 'dismissed' && v != null) _about['$k'] = v is List ? [...v] : v;
        });
      }
      _options = ((screening['options'] as List?) ?? const []).cast<Map<String, dynamic>>();
      _intro = '${screening['intro'] ?? 'Over the last 2 weeks, how often have you been bothered by…'}';

      _steps
        ..clear()
        ..add(const _Step.intro())
        ..addAll(_sections.map((s) => _Step.about(s)))
        ..addAll(((screening['phq9'] as List?) ?? const []).cast<Map<String, dynamic>>().map((q) => _Step.question(q, 'phq9')))
        ..addAll(((screening['gad7'] as List?) ?? const []).cast<Map<String, dynamic>>().map((q) => _Step.question(q, 'gad7')))
        ..add(const _Step.send());

      if (mounted) setState(() => _data = data);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  int get _questionCount => _steps.where((s) => s.kind == 'question').length;
  int get _answered => _scores.length;

  void _next() {
    if (_index < _steps.length - 1) setState(() => _index++);
  }

  void _back() {
    if (_index > 0) setState(() => _index--);
  }

  Future<void> _answer(String key, int value) async {
    setState(() => _scores[key] = value);
    // A short pause so the person sees their choice light up before moving on.
    await Future<void>.delayed(const Duration(milliseconds: 220));
    if (mounted && _steps[_index].question?['key'] == key) _next();
  }

  Future<void> _send() async {
    final missing = _steps.indexWhere((s) => s.kind == 'question' && !_scores.containsKey(s.question!['key']));
    if (missing >= 0) {
      setState(() => _index = missing);
      showSnack(context, 'Please answer this one. It helps us look after you.', error: true);
      return;
    }

    setState(() => _sending = true);
    final app = context.read<AppState>();
    try {
      final body = <String, dynamic>{
        ..._scores,
        ...aboutPayload(_sections, _about, skipped: _skipped),
        'skipped': _skipped.toList(),
        if (widget.forBooking) 'for_booking': true,
      };
      final res = (await app.api.post('intake', body)) as Map<String, dynamic>;
      if (!mounted) return;
      app.dataChanged();

      final outcome = res['outcome'];
      if (outcome == 'crisis') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen(afterIntake: true)));
        return;
      }
      if (res['message'] is String) showSnack(context, res['message'] as String);
      if (outcome == 'assessed') {
        Navigator.pop(context, true); // back to the booking screen
        return;
      }
      final session = res['session'];
      if (session is Map<String, dynamic>) {
        openSession(context, session, replace: true);
      } else {
        Navigator.pop(context);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      if (e.code == 'intake_done') {
        app.dataChanged();
        Navigator.pop(context);
        showSnack(context, e.message);
      } else {
        showSnack(context, e.message, error: true);
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(appBar: AppBar(title: const Text('Getting started')), body: const LoadingView());
    if (_error != null || _data == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Getting started')),
        body: ErrorView(message: _error?.message ?? 'Something went wrong.', onRetry: _load),
      );
    }
    if (_data!['completed'] == true) {
      if (widget.forBooking) {
        // Done meanwhile (on the website, say): straight back to booking.
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) Navigator.pop(context, true);
        });
        return const Scaffold(body: SizedBox.shrink());
      }
      return _alreadyDone();
    }

    final step = _steps[_index];
    final progress = (_index) / (_steps.length - 1);

    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _back();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(switch (step.kind) {
            'about' => 'About you',
            'question' => 'How you\'ve been',
            'send' => 'Nearly done',
            _ => 'Getting started',
          }),
          leading: _index == 0 ? const CloseButton() : BackButton(onPressed: _back),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4),
            child: LinearProgressIndicator(value: progress, minHeight: 4, color: Mw.teal, backgroundColor: Mw.tealTint),
          ),
        ),
        body: SafeArea(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 200),
            child: KeyedSubtree(key: ValueKey(_index), child: _stepView(step)),
          ),
        ),
      ),
    );
  }

  Widget _stepView(_Step step) {
    switch (step.kind) {
      case 'intro':
        return _scroll([
          const Text("Let's get you matched", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Mw.ink900)),
          const SizedBox(height: 10),
          Text(
            _sections.isEmpty
                ? 'You\'ll answer $_questionCount short questions about how you\'ve been feeling. It takes about 3 minutes.'
                : 'First, a little about you. You can skip any part. Then $_questionCount short questions about how you\'ve been feeling. About 5 minutes in all.',
            style: const TextStyle(color: Mw.ink700, fontSize: 15, height: 1.5),
          ),
          const SizedBox(height: 16),
          const MwCard(
            child: Row(
              children: [
                Icon(Icons.lock_outline_rounded, color: Mw.teal),
                SizedBox(width: 12),
                Expanded(
                  child: Text('Your answers are private. Only you, your therapist and the Mindwell care team see them.',
                      style: TextStyle(color: Mw.ink700, fontSize: 13.5)),
                ),
              ],
            ),
          ),
          const Text('There are no right or wrong answers. Answer as honestly as you can.',
              style: TextStyle(color: Mw.ink500, fontSize: 13.5)),
        ], bottom: PrimaryButton(label: 'Start', onPressed: _next));

      case 'about':
        final s = step.section!;
        final key = '${s['key']}';
        return _scroll([
          Text('${s['title']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Mw.ink900)),
          if (s['help'] != null) ...[
            const SizedBox(height: 6),
            Text('${s['help']}', style: const TextStyle(color: Mw.ink500, fontSize: 14)),
          ],
          const SizedBox(height: 18),
          AboutSectionFields(section: s, answers: _about, onChanged: () => setState(() {})),
        ],
            bottom: Row(
              children: [
                TextButton(
                  onPressed: () {
                    _skipped.add(key);
                    _next();
                  },
                  child: const Text('Skip'),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: PrimaryButton(
                    label: 'Continue',
                    onPressed: () {
                      _skipped.remove(key);
                      _next();
                    },
                  ),
                ),
              ],
            ));

      case 'question':
        final q = step.question!;
        final key = '${q['key']}';
        final qNumber = _steps.where((s) => s.kind == 'question').toList().indexOf(step) + 1;
        return _scroll([
          Text('Question $qNumber of $_questionCount', style: const TextStyle(color: Mw.teal, fontWeight: FontWeight.w800, fontSize: 13)),
          const SizedBox(height: 10),
          Text(_intro, style: const TextStyle(color: Mw.ink500, fontSize: 14)),
          const SizedBox(height: 6),
          Text('${q['text']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Mw.ink900, height: 1.3)),
          const SizedBox(height: 22),
          for (final o in _options) _optionButton(key, o),
        ]);

      default: // send
        return _scroll([
          const Text("That's everything", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Mw.ink900)),
          const SizedBox(height: 10),
          Text('You answered $_answered of $_questionCount questions. Thank you for taking the time.',
              style: const TextStyle(color: Mw.ink700, fontSize: 15, height: 1.5)),
          const SizedBox(height: 10),
          const Text("When you send this, we'll look for the right therapist for you.",
              style: TextStyle(color: Mw.ink500, fontSize: 14, height: 1.45)),
        ], bottom: PrimaryButton(label: 'Send my answers', busy: _sending, onPressed: _send));
    }
  }

  Widget _optionButton(String key, Map<String, dynamic> o) {
    final value = o['value'] is int ? o['value'] as int : int.tryParse('${o['value']}') ?? 0;
    final on = _scores[key] == value;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: on ? Mw.tealTint : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: on ? Mw.teal : Mw.line, width: on ? 1.6 : 1),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => _answer(key, value),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Row(
              children: [
                Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: on ? Mw.teal : Mw.ink300),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('${o['label']}',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: on ? Mw.tealDark : Mw.ink900)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _scroll(List<Widget> children, {Widget? bottom}) {
    return Column(
      children: [
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(20, 20, 20, 20), children: children),
        ),
        if (bottom != null)
          Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 16), child: bottom),
      ],
    );
  }

  Widget _alreadyDone() {
    return Scaffold(
      appBar: AppBar(title: const Text('Getting started')),
      body: Center(
        child: EmptyState(
          icon: Icons.check_rounded,
          title: "You've already done your first assessment",
          text: 'You can book a session with a therapist whenever you like.',
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const TherapistsScreen())),
              child: const Text('Choose a therapist'),
            ),
          ],
        ),
      ),
    );
  }
}
