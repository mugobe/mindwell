import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../utils/format.dart';
import '../../widgets/common.dart';
import '../../widgets/slot_picker.dart';
import '../intake/intake_screen.dart';
import '../sessions/session_flow.dart';

/// A therapist's profile, their open times (next few weeks), and booking
/// (GET therapists/{id} → POST therapists/{id}/book). The server re-checks the time
/// under a lock, so two people can never get the same slot.
class TherapistScreen extends StatefulWidget {
  const TherapistScreen({super.key, required this.therapistId});

  final String therapistId;

  @override
  State<TherapistScreen> createState() => _TherapistScreenState();
}

class _TherapistScreenState extends State<TherapistScreen> {
  Map<String, dynamic>? _data;
  ApiException? _error;
  String? _slot;
  String _mode = 'video';
  bool _booking = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final data = (await context.read<AppState>().api.get('therapists/${widget.therapistId}')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _data = data;
        // Drop a picked time that is no longer free.
        final all = ((data['days'] as List?) ?? const []).expand((d) => ((d as Map)['times'] as List?) ?? const []).map((e) => '$e');
        if (_slot != null && !all.contains(_slot)) _slot = null;
      });
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  bool get _needsAssessment => _data?['assessment_required'] == true;

  /// 2026-11-07: the first assessment comes before any booking. Do it, then come back
  /// here with the chosen time still picked.
  Future<void> _assessFirst() async {
    final done = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const IntakeScreen(forBooking: true)));
    if (!mounted) return;
    await _load();
    if (done == true && mounted && _slot != null) showSnack(context, 'Thank you. Now confirm your time.');
  }

  Future<void> _book() async {
    if (_needsAssessment) return _assessFirst();
    final t = _data!['therapist'] as Map<String, dynamic>;
    final at = parseDate(_slot);
    if (_slot == null || at == null) return;
    final prices = (_data!['prices'] as Map?) ?? const {};
    final currency = '${context.read<AppState>().config?['currency'] ?? 'UGX'}';
    final price = _mode == 'in_person' ? prices['in_person'] : prices['video'];

    final ok = await confirmDialog(
      context,
      title: 'Book this session?',
      body: '${fmtDayLong(at)} at ${fmtTime(at)}\n'
          'With ${t['name']} · ${_mode == 'in_person' ? 'In person' : 'Video'}\n\n'
          'If your plan or employer doesn\'t cover it, you\'ll pay ${money(price, currency)} on the next screen.',
      yes: 'Book',
    );
    if (!ok || !mounted) return;

    setState(() => _booking = true);
    final app = context.read<AppState>();
    try {
      final res = (await app.api.post('therapists/${widget.therapistId}/book', {
        'scheduled_at': _slot,
        'session_mode': _mode,
      })) as Map<String, dynamic>;
      if (!mounted) return;
      app.dataChanged();
      final session = res['session'] as Map<String, dynamic>;
      if (session['next_step'] == 'awaiting_approval') {
        showSnack(context, 'Booked. Our team will confirm it and let you know.');
      }
      // Leave the therapist pages behind: Back from the next screen goes home.
      final nav = Navigator.of(context);
      nav.popUntil((r) => r.isFirst);
      nav.push(sessionRoute(session));
    } on ApiException catch (e) {
      if (!mounted) return;
      if (e.code == 'assessment_required') {
        showSnack(context, e.message);
        _assessFirst();
        return;
      }
      showSnack(context, e.errors.isNotEmpty ? e.errors.values.first.first : e.message, error: true);
      if (e.code == 'slot_taken' || e.status == 422) _load();
    } finally {
      if (mounted) setState(() => _booking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _data;
    return Scaffold(
      appBar: AppBar(title: Text(d == null ? 'Therapist' : '${(d['therapist'] as Map)['name']}')),
      body: _error != null && d == null
          ? ErrorView(message: _error!.message, onRetry: _load)
          : d == null
              ? const LoadingView()
              : RefreshIndicator(onRefresh: _load, child: _body(d)),
      bottomNavigationBar: d == null
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: PrimaryButton(
                  label: _slot == null
                      ? 'Pick a time to book'
                      : _needsAssessment
                          ? 'Continue to the assessment'
                          : 'Book ${fmtRelativeDay(parseDate(_slot)!)} at ${fmtTime(parseDate(_slot)!)}',
                  busy: _booking,
                  onPressed: _slot == null ? null : _book,
                ),
              ),
            ),
    );
  }

  Widget _body(Map<String, dynamic> d) {
    final t = d['therapist'] as Map<String, dynamic>;
    final name = '${t['name']}';
    final specialties = ((t['specialties'] as List?) ?? const []).map((e) => '$e').toList();
    final prices = (d['prices'] as Map?) ?? const {};
    final currency = '${context.read<AppState>().config?['currency'] ?? 'UGX'}';
    final inPerson = t['offers_in_person'] == true;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        MwCard(
          child: Column(
            children: [
              Avatar(name: name, size: 84, photoUrl: t['photo_url'] as String?),
              const SizedBox(height: 10),
              Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Mw.ink900)),
              if ((t['title'] ?? '').toString().isNotEmpty)
                Text('${t['title']}', style: const TextStyle(color: Mw.ink500)),
              if (specialties.isNotEmpty) ...[
                const SizedBox(height: 12),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 6,
                  runSpacing: 6,
                  children: [for (final s in specialties) Pill(s, color: Mw.ink700, background: Mw.canvas)],
                ),
              ],
            ],
          ),
        ),
        if ((t['bio'] ?? '').toString().trim().isNotEmpty)
          MwCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('About', style: TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
                const SizedBox(height: 6),
                Text('${t['bio']}', style: const TextStyle(color: Mw.ink700, height: 1.5)),
              ],
            ),
          ),
        if (listText(t['qualifications']).trim().isNotEmpty || listText(t['languages']).isNotEmpty)
          MwCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (listText(t['qualifications']).trim().isNotEmpty) ...[
                  const Text('Qualifications', style: TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
                  const SizedBox(height: 4),
                  Text(listText(t['qualifications']), style: const TextStyle(color: Mw.ink700, height: 1.45)),
                  const SizedBox(height: 10),
                ],
                if (listText(t['languages']).isNotEmpty) ...[
                  const Text('Languages', style: TextStyle(fontWeight: FontWeight.w900, color: Mw.ink900)),
                  const SizedBox(height: 4),
                  Text(listText(t['languages']), style: const TextStyle(color: Mw.ink700)),
                ],
              ],
            ),
          ),
        const SectionTitle('Book a session'),
        if (_needsAssessment)
          MwBanner(
            kind: MwBannerKind.info,
            title: 'One step before you book',
            text: 'Your first booking starts with a short assessment, about 5 minutes. $name reads it before you meet. '
                "Pick a time and we'll take you through it, then bring you back to confirm.",
            actions: [MwPillButton(label: 'Start it now', onPressed: _assessFirst)],
          ),
        MwCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (inPerson) ...[
                SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<String>(
                    segments: [
                      ButtonSegment(value: 'video', icon: const Icon(Icons.videocam_outlined), label: Text('Video · ${money(prices['video'], currency)}')),
                      ButtonSegment(value: 'in_person', icon: const Icon(Icons.place_outlined), label: Text('In person · ${money(prices['in_person'], currency)}')),
                    ],
                    selected: {_mode},
                    showSelectedIcon: false,
                    onSelectionChanged: (v) => setState(() => _mode = v.first),
                  ),
                ),
                const SizedBox(height: 14),
              ] else ...[
                Text('Video session · ${money(prices['video'], currency)} · ${context.read<AppState>().config?['session_minutes'] ?? 70} min',
                    style: const TextStyle(color: Mw.ink700, fontWeight: FontWeight.w700)),
                const SizedBox(height: 12),
              ],
              SlotPicker(
                days: (d['days'] as List?) ?? const [],
                selected: _slot,
                onChanged: (v) => setState(() => _slot = v),
              ),
              if (((d['days'] as List?) ?? const []).isEmpty) ...[
                const SizedBox(height: 6),
                Text('$name has no open times in the next few weeks. Try another therapist, or check back later.',
                    style: const TextStyle(color: Mw.ink500, fontSize: 13)),
              ],
            ],
          ),
        ),
        if (inPerson && _mode == 'in_person')
          const Text("Our team confirms the place for in-person sessions and lets you know.",
              style: TextStyle(color: Mw.ink500, fontSize: 12.5)),
      ],
    );
  }
}
