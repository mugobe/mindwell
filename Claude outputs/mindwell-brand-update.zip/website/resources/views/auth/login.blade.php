@extends('layouts.app')
@section('title', 'Log in')
@section('content')
<div class="mw-auth-shell" style="margin:-28px;">
    <div class="mw-auth-side">
        <img src="{{ asset('images/mindwell-mark-white.png') }}" alt="" aria-hidden="true" style="width:72px;height:auto;display:block;margin-bottom:18px;">
        <div style="font-size:24px;font-weight:800;margin-bottom:8px;">Welcome back</div>
        <div style="font-size:14px;opacity:.85;line-height:1.6;max-width:320px;">
            Private counselling with licensed therapists in Uganda, by video or in person.
        </div>
    </div>

    <div class="mw-auth-form-wrap">
        <div style="width:100%;max-width:340px;">
            <img src="{{ asset('images/mindwell-logo-horizontal.png') }}" alt="Mindwell Consultancy Ltd" style="height:46px;width:auto;display:block;margin-bottom:28px;">
            <h1 style="font-size:20px;font-weight:800;margin-bottom:22px;color:var(--ink-900);">Log in to your account</h1>

            @if ($errors->any())
                <div class="mw-alert danger">
                    {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}" style="display:flex;flex-direction:column;gap:16px;">
                @csrf
                <div>
                    <label class="mw-label" for="email">Email</label>
                    <input class="mw-field" type="email" id="email" name="email" value="{{ old('email') }}" required autofocus>
                </div>
                <div>
                    <div style="display:flex;justify-content:space-between;align-items:baseline;">
                        <label class="mw-label" for="password">Password</label>
                        {{-- Added 2026-10-04 — see PasswordResetController. --}}
                        <a href="{{ route('password.request') }}" style="font-size:12px;color:var(--teal-700);font-weight:600;text-decoration:none;">Forgot password?</a>
                    </div>
                    <input class="mw-field" type="password" id="password" name="password" required>
                </div>
                <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--ink-500);">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <button type="submit" class="btn primary block">Log in</button>
            </form>

            <div style="margin-top:22px;font-size:13px;color:var(--ink-500);text-align:center;">
                Don't have an account?
                <a href="{{ route('register') }}" style="color:var(--teal-700);font-weight:700;text-decoration:none;">Sign up</a>
            </div>
            @include('partials.urgent-help-link')
        </div>
    </div>
</div>
@endsection