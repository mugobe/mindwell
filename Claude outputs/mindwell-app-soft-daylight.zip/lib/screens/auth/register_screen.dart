import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../api/api_client.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/auth_header.dart';
import '../../widgets/common.dart';
import '../../widgets/consent_checks.dart';

/// Sign-up — same fields and rules as the website (Phase 0).
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  DateTime? _dob;
  String? _gender;
  bool _terms = false, _privacy = false, _emergency = false;
  bool _busy = false;
  bool _hide = true;
  ApiException? _error;

  @override
  void dispose() {
    for (final c in [_first, _last, _email, _phone, _password, _confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickDob() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _dob ?? DateTime(now.year - 25, now.month, now.day),
      firstDate: DateTime(1920),
      lastDate: now,
      helpText: 'Your date of birth',
    );
    if (picked != null) setState(() => _dob = picked);
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await context.read<AppState>().register({
        'first_name': _first.text.trim(),
        'last_name': _last.text.trim(),
        'date_of_birth': _dob == null ? '' : DateFormat('yyyy-MM-dd').format(_dob!),
        'gender': _gender,
        'email': _email.text.trim(),
        'phone': _phone.text.trim().isEmpty ? null : _phone.text.trim(),
        'password': _password.text,
        'password_confirmation': _confirm.text,
        'accept_terms': _terms,
        'accept_privacy': _privacy,
        'accept_emergency': _emergency,
      });
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } on ApiException catch (e) {
      if (mounted) {
        setState(() => _error = e);
        showSnack(context, e.errors.isEmpty ? e.message : 'Please check the highlighted fields.', error: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final genders = ((context.watch<AppState>().config?['genders'] as List?) ?? const [
      {'value': 'female', 'label': 'Female'},
      {'value': 'male', 'label': 'Male'},
      {'value': 'other', 'label': 'Other'},
      {'value': 'prefer_not_to_say', 'label': 'Prefer not to say'},
    ]).cast<Map>();
    String? err(String f) => _error?.fieldError(f);

    return Scaffold(
      appBar: AppBar(title: const Text('Create your account')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          children: [
            const MwAuthHeader(
              title: "Let's get you started.",
              text: 'It takes about a minute. Your details stay private.',
            ),
            if (_error != null && _error!.errors.isEmpty) NoticeBox(text: _error!.message),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _first,
                    textCapitalization: TextCapitalization.words,
                    decoration: InputDecoration(labelText: 'First name', errorText: err('first_name')),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _last,
                    textCapitalization: TextCapitalization.words,
                    decoration: InputDecoration(labelText: 'Last name', errorText: err('last_name')),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            InkWell(
              onTap: _pickDob,
              borderRadius: BorderRadius.circular(12),
              child: InputDecorator(
                decoration: InputDecoration(labelText: 'Date of birth', errorText: err('date_of_birth'), suffixIcon: const Icon(Icons.calendar_today_outlined, size: 20)),
                child: Text(_dob == null ? 'Choose a date' : DateFormat('d MMMM yyyy').format(_dob!),
                    style: TextStyle(color: _dob == null ? Mw.ink300 : Mw.ink900, fontSize: 15)),
              ),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: _gender,
              decoration: InputDecoration(labelText: 'Gender (optional)', errorText: err('gender')),
              items: [
                for (final g in genders)
                  DropdownMenuItem(value: '${g['value']}', child: Text('${g['label']}')),
              ],
              onChanged: (v) => setState(() => _gender = v),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              autocorrect: false,
              decoration: InputDecoration(labelText: 'Email', errorText: err('email')),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: 'Mobile number (optional)',
                helperText: 'For session reminders by SMS, e.g. 0772 123 456',
                errorText: err('phone'),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _password,
              obscureText: _hide,
              decoration: InputDecoration(
                labelText: 'Password (8+ characters)',
                errorText: err('password'),
                suffixIcon: IconButton(
                  icon: Icon(_hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _confirm,
              obscureText: _hide,
              decoration: const InputDecoration(labelText: 'Confirm password'),
            ),
            const SizedBox(height: 14),
            ConsentChecks(
              terms: _terms,
              privacy: _privacy,
              emergency: _emergency,
              errors: {
                'accept_terms': err('accept_terms'),
                'accept_privacy': err('accept_privacy'),
                'accept_emergency': err('accept_emergency'),
              },
              onChanged: (which, v) => setState(() {
                if (which == 'accept_terms') _terms = v;
                if (which == 'accept_privacy') _privacy = v;
                if (which == 'accept_emergency') _emergency = v;
              }),
            ),
            const SizedBox(height: 14),
            PrimaryButton(label: 'Create account', busy: _busy, color: Mw.orange, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
