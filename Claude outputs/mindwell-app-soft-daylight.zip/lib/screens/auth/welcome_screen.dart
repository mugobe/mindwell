import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/calm.dart';
import '../../widgets/common.dart';
import '../server_dialog.dart';
import '../urgent_help_screen.dart';
import 'login_screen.dart';
import 'register_screen.dart';

/// Welcome screen (Dr. Ntabade's CLIENT DRAFT item 1: logo, slogan, Log in / Create
/// account, and "I need urgent help" without registering).
/// 2026-11-07 (Collins chose option A, "Soft daylight"): the website's soft panel and
/// plant instead of the dark navy block. Green leads, navy is for text, orange for the
/// one main button, and urgent help stays red.
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(gradient: Mw.heroGradient),
              child: SafeArea(
                bottom: false,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    const Positioned(right: 4, top: 58, child: MwPlant(width: 170)),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(28, 24, 28, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onLongPress: () => showServerDialog(context), // developer setting
                            child: const MwLogo(size: 28),
                          ),
                          const Spacer(),
                          const Text(
                            'Someone to talk to,\nwhen you need it.',
                            style: TextStyle(color: Mw.tealDark, fontSize: 30, height: 1.2, fontWeight: FontWeight.w900, letterSpacing: -.4),
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'Private counselling with licensed therapists in Uganda, by video or in person.',
                            style: TextStyle(color: Mw.ink700, fontSize: 15.5, height: 1.45),
                          ),
                          const SizedBox(height: 18),
                          Row(
                            children: const [
                              Icon(Icons.verified_user_outlined, color: Mw.green, size: 18),
                              SizedBox(width: 8),
                              Expanded(
                                child: Text('Confidential. Only you and your therapist see your sessions.',
                                    style: TextStyle(color: Mw.ink700, fontSize: 13)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 22, 24, 12),
              child: Column(
                children: [
                  if (state.message != null) NoticeBox(text: state.message!),
                  PrimaryButton(
                    label: 'Create an account',
                    color: Mw.orange,
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
                      child: const Text('I already have an account'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextButton.icon(
                    style: TextButton.styleFrom(foregroundColor: Mw.danger),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UrgentHelpScreen())),
                    icon: const Icon(Icons.favorite_rounded, size: 18),
                    label: const Text('I need urgent help'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
