import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'auth/change_password_screen.dart';
import 'auth/consent_screen.dart';
import 'auth/welcome_screen.dart';
import 'home/home_shell.dart';

/// Shows the right first screen for where the client is (signed out, a gate, or home).
class RootGate extends StatelessWidget {
  const RootGate({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    switch (state.phase) {
      case Phase.loading:
        // 2026-11-07: same soft colours as the splash and welcome screens.
        return Scaffold(
          body: Container(
            decoration: const BoxDecoration(gradient: Mw.heroGradient),
            alignment: Alignment.center,
            child: Image.asset('assets/images/mindwell_mark.png', width: 96, semanticLabel: 'Mindwell'),
          ),
        );
      case Phase.offline:
        return Scaffold(
          body: SafeArea(
            child: ErrorView(
              message: state.message ?? "Can't reach Mindwell right now.",
              onRetry: () => state.boot(),
            ),
          ),
        );
      case Phase.signedOut:
      case Phase.suspended:
        return const WelcomeScreen();
      case Phase.needsPassword:
        return const ChangePasswordScreen(forced: true);
      case Phase.needsConsent:
        return const ConsentScreen();
      case Phase.ready:
        return const HomeShell();
    }
  }
}
