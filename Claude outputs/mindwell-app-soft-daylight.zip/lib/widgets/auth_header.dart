import 'package:flutter/material.dart';

import '../theme.dart';
import 'calm.dart';
import 'common.dart';

/// Soft header for the log-in and sign-up screens (2026-11-07, option A "Soft daylight"):
/// the website's soft panel, the colour logo and the plant.
class MwAuthHeader extends StatelessWidget {
  const MwAuthHeader({super.key, required this.title, required this.text});

  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.fromLTRB(18, 16, 8, 16),
      decoration: BoxDecoration(gradient: Mw.heroGradient, borderRadius: BorderRadius.circular(22)),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const MwLogo(size: 20),
                const SizedBox(height: 12),
                Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Mw.tealDark, letterSpacing: -.3)),
                const SizedBox(height: 4),
                Text(text, style: const TextStyle(color: Mw.ink700, fontSize: 13.5, height: 1.4)),
              ],
            ),
          ),
          const MwPlant(width: 96),
        ],
      ),
    );
  }
}
