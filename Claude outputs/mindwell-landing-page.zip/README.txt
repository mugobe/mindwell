Mindwell landing page (static website)

Upload everything in this folder to the web folder of the domain you want
(for example public_html on cPanel). No PHP, no database, nothing to install.

Edit before going live:
1. assets/js/site.js, at the top:
   - portal:    the Mindwell website address (sign up and log in links)
   - playStore: the Google Play link once the app is published (empty = "Coming soon")
   - appStore:  the iPhone app link, later
   - email:     the contact email for "Talk to us" and the footer
2. index.html:
   - Prices (search for "EDIT HERE"). Keep them the same as Admin > Plans & pricing.
   - Dr. Ntabade's title, bio and photo (search for "placeholder" and "dr-ntabade").
     Put her photo in assets/img/dr-ntabade.jpg and swap in the <img> line.
   - Phone number in the footer.
   - "People talk to us about": confirm the topics with Dr. Ntabade.
