/* Mindwell landing page.
 *
 * EDIT HERE: the few things that change. Everything else is plain HTML in index.html.
 *  - portal:    the Mindwell website people sign up and log in on. Every link marked
 *               data-portal="/register" etc. in index.html is pointed at this address.
 *  - playStore: paste the Google Play link once the app is published. While it is empty,
 *               the Android badge shows "Coming soon".
 *  - appStore:  same for the iPhone app, later.
 *  - email:     where "Talk to us" and the footer email go.
 */
var MINDWELL = {
    portal: 'https://mindwell.insight360apps.net',
    playStore: '',
    appStore: '',
    email: 'care@mindwell.com'
};

(function () {
    var base = MINDWELL.portal.replace(/\/+$/, '');

    // Point every portal link at the configured address.
    document.querySelectorAll('[data-portal]').forEach(function (a) {
        a.setAttribute('href', base + a.getAttribute('data-portal'));
    });

    // Contact links: email with a ready subject line.
    var subjects = { employers: 'Mindwell for our staff', general: 'Hello Mindwell' };
    document.querySelectorAll('[data-contact]').forEach(function (a) {
        var kind = a.getAttribute('data-contact');
        a.setAttribute('href', 'mailto:' + MINDWELL.email + '?subject=' + encodeURIComponent(subjects[kind] || 'Hello Mindwell'));
        if (kind === 'general') a.textContent = MINDWELL.email;
    });

    // App store badges: live link when set, otherwise "Coming soon".
    document.querySelectorAll('[data-store]').forEach(function (a) {
        var url = MINDWELL[a.getAttribute('data-store')];
        if (url) {
            a.setAttribute('href', url);
            a.classList.remove('soon');
            var tag = a.querySelector('.tag');
            if (tag) tag.remove();
            var small = a.querySelector('small');
            if (small) small.textContent = a.getAttribute('data-store') === 'playStore' ? 'Get it on' : 'Download on the';
        } else {
            a.addEventListener('click', function (e) { e.preventDefault(); });
            a.setAttribute('aria-disabled', 'true');
        }
    });

    // Year in the footer.
    var y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();

    // Header border once the page scrolls.
    var head = document.querySelector('.site-head');
    function onScroll() { head.classList.toggle('scrolled', window.scrollY > 8); }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    // Phone menu.
    var btn = document.querySelector('.menu-btn');
    var nav = document.getElementById('nav');
    if (btn && nav) {
        btn.addEventListener('click', function () {
            var open = nav.classList.toggle('open');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        nav.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', function () { nav.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); });
        });
    }

    // Gentle reveal as sections scroll into view (skipped for reduced motion).
    var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!calm && 'IntersectionObserver' in window) {
        document.documentElement.classList.add('js-motion');
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
            });
        }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
        document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
    }
})();
